--涅槃の超魔導剣士
function c692.initial_effect(c)
	c:EnableReviveLimit()
	--pendulum summon
	aux.EnablePendulumAttribute(c,false)
	Synchro.AddProcedure(c,nil,1,1,Synchro.NonTuner(nil),1,99)
	
	--synchro summon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(80896940,1))
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_SPSUMMON_PROC)
	e1:SetProperty(EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE)
	e1:SetRange(LOCATION_EXTRA)
	e1:SetCondition(c692.syncon)
	e1:SetTarget(c692.syntg)
	e1:SetOperation(c692.synop)
	e1:SetValue(SUMMON_TYPE_SYNCHRO)
	c:RegisterEffect(e1)	
	
	--indes
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_QUICK_O)
	e3:SetCode(EVENT_FREE_CHAIN)
	e3:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_CARD_TARGET) 
	e3:SetRange(LOCATION_PZONE)
	e3:SetTarget(c692.intg) 
	e3:SetOperation(c692.indop)
	c:RegisterEffect(e3)
	local ge2=Effect.CreateEffect(c)
	ge2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	ge2:SetCode(EVENT_PHASE+PHASE_END)
	ge2:SetCountLimit(1)
	ge2:SetLabelObject(e3)
	ge2:SetOperation(c692.clear)
	Duel.RegisterEffect(ge2,0)  
	
	--pendulum
	local e7=Effect.CreateEffect(c)
	e7:SetDescription(aux.Stringid(80896940,5))
	e7:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e7:SetCode(EVENT_DESTROYED)
	e7:SetProperty(EFFECT_FLAG_DELAY)
	e7:SetCondition(c692.pencon)
	e7:SetTarget(c692.pentg)
	e7:SetOperation(c692.penop)
	c:RegisterEffect(e7)
end

function c692.matfilter2(c,syncard)
	local tp=syncard:GetControler() 
	return c:IsType(TYPE_PENDULUM) and c:IsReleasable()
	and c:GetSummonType()==SUMMON_TYPE_PENDULUM 
	and c:IsFaceup() and Duel.IsExistingMatchingCard(c692.matfilter1,tp,LOCATION_MZONE,0,1,c,syncard)
end
function c692.matfilter1(c,syncard)
	return c:IsFaceup() and c:IsType(TYPE_SYNCHRO) and c:IsReleasable()
end
function c692.synfilter(c,syncard,lv,g2,minc,sc)
	local tlv=c:GetSynchroLevel(syncard)
	if lv-tlv<=0 then return false end
	local g=g2:Clone()
	g:RemoveCard(c)
	return g:CheckWithSumEqual(c692.synfilter00,lv-tlv,minc-1,98,syncard,c,sc)
end
function c692.synfilter00(c,lv,syncard,tc,sc)
	return c:GetSynchroLevel(syncard)==lv and Duel.GetLocationCountFromEx(c:GetControler(),c:GetControler(),Group.FromCards(c,tc),sc)>0
end
function c692.syncon(e,c,tuner,mg)
	if c==nil then return true end
	if c:IsType(TYPE_PENDULUM) and c:IsFaceup() then return false end
	local tp=c:GetControler()
	local minc=2
	local g1=nil
	local g2=nil
	--if mg then
		--g1=mg:Filter(c692.matfilter1,nil,c)
		--g2=mg:Filter(c692.matfilter2,nil,c)
	--else
	g1=Duel.GetMatchingGroup(c692.matfilter1,tp,LOCATION_MZONE,0,nil,c)
	g2=Duel.GetMatchingGroup(c692.matfilter2,tp,LOCATION_MZONE,0,nil,c)
	--end
	--local pe=Duel.IsPlayerAffectedByEffect(tp,EFFECT_MUST_BE_SMATERIAL)
	local lv=c:GetLevel()

	--if not pe then
	return g1:IsExists(c692.synfilter,1,nil,c,lv,g2,minc,c) 
	--else
		--return c692.synfilter(pe:GetOwner(),c,lv,g2,minc)
	--end
end
function c692.syntg(e,tp,eg,ep,ev,re,r,rp,chk,c,tuner,mg)
	local g=Group.CreateGroup()
	local g1=nil
	local g2=nil
	--if mg then
		--g1=mg:Filter(c692.matfilter1,nil,c)
		--g2=mg:Filter(c692.matfilter2,nil,c)
	--else
	g1=Duel.GetMatchingGroup(c692.matfilter1,tp,LOCATION_MZONE,0,nil,c)
	g2=Duel.GetMatchingGroup(c692.matfilter2,tp,LOCATION_MZONE,0,nil,c)
	--end
	local minc=2

	--local pe=Duel.IsPlayerAffectedByEffect(tp,EFFECT_MUST_BE_SMATERIAL)
	local lv=c:GetLevel()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local tuner=g1:Select(tp,1,1,nil):GetFirst()
	g:AddCard(tuner)
	g2:RemoveCard(tuner)
	local lv1=tuner:GetLevel()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local m2=g2:SelectWithSumEqual(tp,c692.synfilter00,lv-lv1,minc-1,98,c,tuner,c)
	g:Merge(m2)
	if g then
		g:KeepAlive()
		e:SetLabelObject(g)
		return true
	else return false end
end
function c692.synop(e,tp,eg,ep,ev,re,r,rp,c,tuner,mg)
	local g=e:GetLabelObject()
	Duel.Release(g,REASON_EFFECT)
	g:DeleteGroup()
end

function c692.infilter(c,lv,e)
	return c:IsFaceup() 
	and c:IsSummonType(SUMMON_TYPE_PENDULUM) and c:GetTurnID()==Duel.GetTurnCount() 
	and c:IsLevelAbove(lv+1) and c:IsCanBeEffectTarget(e)
	and c:GetFlagEffect(692)==0
end
function c692.intg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local ac=e:GetLabelObject()
	local lv=0
	if ac==nil then lv=0 end
	if ac~=nil and ac:GetLevel()<1 then lv=-1 end   
	if ac~=nil and ac:GetLevel()>0 then lv=ac:GetLevel() end	
	if chkc then return true end  
	if chk==0 then return not e:GetHandler():IsStatus(STATUS_CHAINING) and lv>-1
	and Duel.IsExistingTarget(c692.infilter,tp,LOCATION_MZONE,0,1,nil,lv,e) end
	local g=Duel.GetMatchingGroup(c692.infilter,tp,LOCATION_MZONE,0,nil,lv,e)   
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local tc=g:GetMinGroup(Card.GetLevel):Select(tp,1,1,nil):GetFirst()
	Duel.SetTargetCard(tc)
	tc:RegisterFlagEffect(692,RESET_EVENT+0x1fe0000+RESET_EVENT+EVENT_DAMAGE_STEP_END,0,1)
end
function c692.indop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsFacedown() or not tc:IsRelateToEffect(e) then return end 
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
	e1:SetValue(1)
	e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	tc:RegisterEffect(e1)
	local e2=Effect.CreateEffect(e:GetHandler())
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_AVOID_BATTLE_DAMAGE)
	e2:SetValue(1)
	e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	tc:RegisterEffect(e2)
	--atkdown
	local e4=Effect.CreateEffect(e:GetHandler())
	e4:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e4:SetCode(EVENT_DAMAGE_STEP_END)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCondition(c692.atkcon)
	e4:SetOperation(c692.atkop)
	e4:SetLabelObject(e)
	e4:SetReset(RESET_EVENT+0x1fe0000+RESET_EVENT+EVENT_DAMAGE_STEP_END)	
	tc:RegisterEffect(e4)   
end
function c692.atkcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	return c:IsRelateToBattle() 
end
function c692.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tp=c:GetControler()
	local tg=Duel.GetMatchingGroup(Card.IsFaceup,tp,0,LOCATION_MZONE,nil)
	local tc=tg:GetFirst()
	while tc do
		local atk=c:GetAttack()
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(-atk)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
		tc=tg:GetNext()
	end
	e:GetLabelObject():SetLabelObject(c)
end

function c692.clear(e,tp,eg,ep,ev,re,r,rp)
	e:GetLabelObject():SetLabelObject(nil)
end

function c692.pencon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	return bit.band(r,REASON_EFFECT+REASON_BATTLE)~=0 and c:IsPreviousLocation(LOCATION_MZONE) and c:IsFaceup()
end
function c692.pentg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.CheckLocation(tp,LOCATION_PZONE,0) or Duel.CheckLocation(tp,LOCATION_PZONE,1) end
end
function c692.penop(e,tp,eg,ep,ev,re,r,rp)
	if not Duel.CheckLocation(tp,LOCATION_PZONE,0) and not Duel.CheckLocation(tp,LOCATION_PZONE,1) then return false end
	local c=e:GetHandler()
	if c:IsRelateToEffect(e) then
		Duel.MoveToField(c,tp,tp,LOCATION_SZONE,POS_FACEUP,true)
	end
end