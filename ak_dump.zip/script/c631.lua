--
function c631.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET) 
	e1:SetCategory(CATEGORY_DESTROY+CATEGORY_DAMAGE)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c631.target)
	e1:SetOperation(c631.activate)
	c:RegisterEffect(e1)	
end

function c631.filter(c)
	return c:IsType(TYPE_FUSION) and c:IsFaceup()
	and Duel.IsExistingTarget(c631.filter1,tp,LOCATION_MZONE,LOCATION_MZONE,1,c,c:GetAttack())
end
function c631.filter1(c,atk2)
	local atk=c:GetAttack()+atk2
	return c:IsType(TYPE_FUSION) and c:IsFaceup() and atk>0
	and Duel.IsExistingMatchingCard(c631.filter2,tp,LOCATION_MZONE,LOCATION_MZONE,1,c,atk)
end
function c631.filter2(c,atk)
	return not c:IsType(TYPE_FUSION) and c:IsFaceup() and c:GetAttack()<=atk
	and bit.band(c:GetSummonType(),SUMMON_TYPE_SPECIAL)==SUMMON_TYPE_SPECIAL
end
function c631.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and c631.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c631.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g=Duel.SelectTarget(tp,c631.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,1,nil)  
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g2=Duel.SelectTarget(tp,c631.filter1,tp,LOCATION_MZONE,LOCATION_MZONE,1,1,g:GetFirst(),g:GetFirst():GetAttack())	
	local g3=Duel.GetMatchingGroup(c631.filter2,tp,LOCATION_MZONE,LOCATION_MZONE,nil,g:GetFirst():GetAttack()+g2:GetFirst():GetAttack())
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g3,g3:GetCount(),0,0)
end
function c631.activate(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
	if g:FilterCount(Card.IsFaceup,nil)==2 then
	local tc=g:GetFirst()
	local tatk=0
	while tc do
	local atk=tc:GetAttack()
	if atk<0 then atk=0 end
	tatk=tatk+atk
	tc=g:GetNext() end
	local g3=Duel.GetMatchingGroup(c631.filter2,tp,LOCATION_MZONE,LOCATION_MZONE,nil,tatk)
	if g3:GetCount()>0 then
		Duel.Destroy(g3,REASON_EFFECT)
		local sg=Duel.GetOperatedGroup()
		local sg1=sg:Filter(Card.IsControler,nil,tp)
		local sg2=sg:Filter(Card.IsControler,nil,1-tp)
		local tc2=sg1:GetFirst()
		local tatk2=0
		while tc2 do
			local atk2=tc2:GetTextAttack()
			if atk2<0 then atk2=0 end
			tatk2=tatk2+atk2
			tc2=sg1:GetNext() end

		local tc3=sg2:GetFirst()
		local tatk3=0
		while tc3 do
			local atk3=tc3:GetTextAttack()
			if atk3<0 then atk3=0 end
			tatk3=tatk3+atk3
			tc3=sg2:GetNext() end
	   Duel.BreakEffect()
	   Duel.Damage(tp,tatk2,REASON_EFFECT)
	   Duel.Damage(1-tp,tatk3,REASON_EFFECT)
	end end
end
