--クリアウィング・シンクロ・ドラゴン
function c84.initial_effect(c)
	--synchro summon
	aux.AddSynchroMixProcedure(c,nil,nil,nil,Synchro.NonTuner(nil),1,99,c84.matfilter)
	c:EnableReviveLimit()

	if not c84.global_check then
		c84.global_check=true
		--register
		local ge1=Effect.CreateEffect(c)
		ge1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
		ge1:SetCode(EVENT_CHAIN_SOLVED)
		ge1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
		ge1:SetOperation(c84.chop)
		Duel.RegisterEffect(ge1,0)
	end

	--negate
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(63746411,0))
	e1:SetCategory(CATEGORY_DISABLE+CATEGORY_DESTROY+CATEGORY_ATKCHANGE)
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_CARD_TARGET)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCountLimit(1)
	e1:SetCondition(c84.condition)
	e1:SetTarget(c84.target)
	e1:SetOperation(c84.operation)
	c:RegisterEffect(e1)

	--atk up
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(96864105,0))
	e2:SetCategory(CATEGORY_ATKCHANGE)
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetCode(EVENT_PRE_DAMAGE_CALCULATE)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCondition(c84.atkcon)
	e2:SetTarget(c84.atkcost)
	e2:SetOperation(c84.atkop)
	c:RegisterEffect(e2)
end

function c84.matfilter(g)
	return g:IsExists(c84.cfilter,1,nil)
end
function c84.cfilter(c)
	return c:IsLevelAbove(5) and c:IsType(TYPE_SYNCHRO) and not c:IsType(TYPE_TUNER)
end

function c84.chop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local rc=re:GetHandler()
	local loc=Duel.GetChainInfo(ev,CHAININFO_TRIGGERING_LOCATION)
	if re:IsActiveType(TYPE_MONSTER) and rc~=c and loc==LOCATION_MZONE then
		 rc:RegisterFlagEffect(84,RESET_EVENT+0x1fe0000,0,1) end  
end

function c84.condition(e,tp,eg,ep,ev,re,r,rp)
	return not e:GetHandler():IsStatus(STATUS_BATTLE_DESTROYED)
end
function c84.spfilter(c)
	return c:GetFlagEffect(84)~=0 and (aux.TRUE or not c:IsStatus(STATUS_DISABLED)) 
end
function c84.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return c84.spfilter(chkc) and chkc:IsLocation(LOCATION_MZONE) end
	if chk==0 then return Duel.IsExistingTarget(c84.spfilter,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_DESTROY)
	local g=Duel.SelectTarget(tp,c84.spfilter,tp,LOCATION_MZONE,LOCATION_MZONE,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_DISABLE,g,1,0,0)
	if g:GetFirst():IsDestructable() then
		Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,1,0,0)
	end
end
function c84.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if not tc or not tc:IsRelateToEffect(e) or tc:IsDisabled() then return end
	Duel.NegateRelatedChain(tc,RESET_TURN_SET)

		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
		e1:SetRange(LOCATION_MZONE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
		local e02=e1:Clone()		 
		e02:SetCode(EFFECT_DISABLE_EFFECT)
		e02:SetValue(RESET_TURN_SET)
		tc:RegisterEffect(e02)
		local e3=nil
		if tc:IsType(TYPE_TRAPMONSTER) then
		  e3=Effect.CreateEffect(c)
		  e3:SetType(EFFECT_TYPE_SINGLE)
		  e3:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
		  e3:SetCode(EFFECT_DISABLE_TRAPMONSTER)
		  e3:SetReset(RESET_EVENT+0x1fe0000)
		  tc:RegisterEffect(e3)
		end
		if Duel.Destroy(tc,REASON_EFFECT)>0 then
		local atk=tc:GetPreviousAttackOnField()
		if atk>0 then
		local e1=Effect.CreateEffect(c)
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(atk)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		c:RegisterEffect(e1) end end
end

function c84.atkcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local bc=c:GetBattleTarget()
	return bc and bc:IsLevelAbove(5) and bc:IsControler(1-tp)
end
function c84.atkcost(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return c:GetFlagEffect(96864105)==0 end
	c:RegisterFlagEffect(96864105,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_DAMAGE_CAL,0,1)
end
function c84.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local a=Duel.GetAttacker()
	local d=Duel.GetAttackTarget()
	if not a:IsRelateToBattle() or a:IsFacedown() or not d:IsRelateToBattle() or d:IsFacedown() then return end
	if a:IsControler(1-tp) then a,d=d,a end
	  if a~=c or not d:IsLevelAbove(5) then return end
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_UPDATE_ATTACK)
	e1:SetReset(RESET_PHASE+PHASE_DAMAGE_CAL)
	e1:SetValue(d:GetAttack())
	c:RegisterEffect(e1)
end
