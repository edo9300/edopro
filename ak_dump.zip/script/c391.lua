--我我我頭領 (K)
function c391.initial_effect(c)

	--summon with no tribute
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(340002,0))
	e1:SetProperty(EFFECT_FLAG_UNCOPYABLE)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_SUMMON_PROC)
	e1:SetCondition(c391.ntcon)
	c:RegisterEffect(e1)	

	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(12958919,0))
	e2:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e2:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e2:SetCode(EVENT_SUMMON_SUCCESS)
	e2:SetTarget(c391.sptg)
	e2:SetOperation(c391.spop)
	c:RegisterEffect(e2)

	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_DRAW)
	e3:SetType(EFFECT_TYPE_IGNITION)
      e3:SetRange(LOCATION_MZONE)
	e3:SetTarget(c391.target)
	e3:SetOperation(c391.activate)
	c:RegisterEffect(e3)

	--local e5=Effect.CreateEffect(c)
	--e5:SetDescription(aux.Stringid(1474910,0))
	--e5:SetCategory(CATEGORY_DRAW)
	--e5:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	--e5:SetCode(EVENT_BE_MATERIAL)
	--e5:SetCondition(c391.efcon)
	--e5:SetOperation(c391.efop)
	--c:RegisterEffect(e5)
end

function c391.cfilter(c)
	return c:IsFaceup() and c:IsType(TYPE_MONSTER)
end
function c391.ntcon(e,c,minc)
	if c==nil then return true end
	return minc==0 and c:GetLevel()>4 and Duel.GetLocationCount(c:GetControler(),LOCATION_MZONE)>0
		and Duel.IsExistingMatchingCard(c391.cfilter,c:GetControler(),LOCATION_GRAVE,0,2,nil)
end

function c391.filter(c,e,tp)
	return c:IsSetCard(0x54) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and c:IsType(TYPE_MONSTER) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
end
function c391.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and Duel.IsExistingMatchingCard(c391.filter,tp,LOCATION_GRAVE,0,1,nil,e,tp) end
	local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
	local g=Duel.GetMatchingGroup(c391.filter,tp,LOCATION_GRAVE,0,nil,e,tp)
      local count=g:GetCount()
	if count>ft then count=ft end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,count,0,0)
end
function c391.spop(e,tp,eg,ep,ev,re,r,rp)
	local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
	local g=Duel.GetMatchingGroup(c391.filter,tp,LOCATION_GRAVE,0,nil,e,tp)
      local count=g:GetCount()
	if count>ft then count=ft end
	if ft<1 then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(tp,c391.filter,tp,LOCATION_GRAVE,0,count,count,nil,e,tp)
	if g:GetCount()>0 then
      Duel.SpecialSummon(g,0,tp,tp,false,false,POS_FACEUP) end
end

function c391.xyzfilter(c)
	return c:IsFaceup() and c:IsSetCard(0x54) and not c:IsType(TYPE_XYZ) 
end
function c391.xyzfilter2(c,e,tp,mg)
      if not c:IsType(TYPE_XYZ)  or c.minxyzct==nil then return end
      local mg2=mg:Filter(c391.mfilter3,nil,c)
     return  mg2:GetCount()>0 and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,false,true) and c:IsSetCard(0x48)
     and mg2:GetCount()>=c.minxyzct 
end
function c391.mfilter3(c,mc)
	return c:IsCanBeXyzMaterial(mc) and (mc.xyz_filter==nil or (mc.xyz_filter and mc.xyz_filter(c)))
end
function c391.target(e,tp,eg,ep,ev,re,r,rp,chk)
	local mg=Duel.GetMatchingGroup(c391.xyzfilter,tp,LOCATION_MZONE,0,nil)
	if chk==0 then return mg:GetCount()>0
		and Duel.IsExistingMatchingCard(c391.xyzfilter2,tp,LOCATION_GRAVE,0,1,nil,e,tp,mg) end
      Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,0)
end
function c391.activate(e,tp,eg,ep,ev,re,r,rp)
	local mg=Duel.GetMatchingGroup(c391.xyzfilter,tp,LOCATION_MZONE,0,nil) 
      if mg:GetCount()<1 then return end
	local xyzg=Duel.GetMatchingGroup(c391.xyzfilter2,tp,LOCATION_GRAVE,0,nil,e,tp,mg) 
	if xyzg:GetCount()<1 then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
            local tc=Duel.SelectMatchingCard(tp,c391.xyzfilter2,tp,LOCATION_GRAVE,0,1,1,nil,e,tp,mg):GetFirst()
      Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
      local sg1=mg:FilterSelect(tp,c391.mfilter3,c.minxyzct,c.maxxyzct,nil,tc)
      if sg1:GetCount()<1 then return end
	tc:SetMaterial(sg1)
	Duel.Overlay(tc,sg1)
	if Duel.SpecialSummon(tc,SUMMON_TYPE_XYZ,tp,tp,false,true,POS_FACEUP)~=0 then
      tc:CompleteProcedure() 

      if tc:GetMaterial():IsExists(c391.xyzfilter,1,nil) and tc:GetMaterial():IsContains(e:GetHandler())
      and Duel.IsPlayerCanDraw(tp,sg1:GetCount()) and Duel.SelectYesNo(tp,aux.Stringid(1945387,0)) then
      Duel.Draw(tp,sg1:GetCount(),REASON_EFFECT) end 
end
end

function c391.efcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local rc=c:GetOverlayTarget()
      local g=rc:GetMaterial()
      local og=g:Filter(c391.xyzfilter,nil)
      local count=og:GetCount()
	return r==REASON_XYZ and count>0 
end
function c391.efop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local rc=c:GetOverlayTarget()
      local g=rc:GetMaterial()
      local og=g:Filter(c391.xyzfilter,nil)
      local count=og:GetCount()
      if rc==nil or  count==0 then return end
      Duel.Hint(HINT_CARD,0,391)
      local e1=Effect.CreateEffect(rc)
	e1:SetDescription(aux.Stringid(13582837,0))
	e1:SetCategory(CATEGORY_DRAW)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	--e1:SetCondition(c391.atkcon)
	--e1:SetTarget(c391.eftarget)
	--e1:SetOperation(c391.efop2)
      --e1:SetLabel(count)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	rc:RegisterEffect(e1,true)
	if not rc:IsType(TYPE_EFFECT) then
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_ADD_TYPE)
		e2:SetValue(TYPE_EFFECT)
		e2:SetReset(RESET_EVENT+0x1fe0000)
		rc:RegisterEffect(e2,true) 
	end
end
function c391.atkcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
      local g=c:GetMaterial()
      if g:GetCount()==0 then return end
      local count=g:FilterCount(c391.xyzfilter,nil)
	return c:GetSummonType()==SUMMON_TYPE_XYZ and count>0
end
function c391.eftarget(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
      local g=c:GetMaterial()
      if g:GetCount()==0 then return end
      local count=g:FilterCount(c391.xyzfilter,nil)
      if chk==0 then return count>0 and Duel.IsPlayerCanDraw(tp,count) end
      Duel.SetTargetPlayer(tp)
      Duel.SetTargetParam(count)	
      Duel.SetOperationInfo(0,CATEGORY_DRAW,nil,0,tp,count)
end
function c391.efop2(e,tp,eg,ep,ev,re,r,rp)
	local p,d=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER,CHAININFO_TARGET_PARAM)
	Duel.Draw(p,d,REASON_EFFECT)
end
