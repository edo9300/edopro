--Data Brain
function c140000087.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_EQUIP)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetTarget(c140000087.target)
	e1:SetOperation(c140000087.operation)
	c:RegisterEffect(e1)
	--Equip limit
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_EQUIP_LIMIT)
	e2:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e2:SetValue(c140000087.eqlimit)
	c:RegisterEffect(e2)
	--destroy
	local e4=Effect.CreateEffect(c)
	e4:SetDescription(aux.Stringid(140000087,0))
	e4:SetCategory(CATEGORY_DESTROY+CATEGORY_DAMAGE)
	e4:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_F)
	e4:SetCode(EVENT_LEAVE_FIELD)
	e4:SetCondition(c140000087.precon)
	e4:SetOperation(c140000087.preop)
	c:RegisterEffect(e4)
end
function c140000087.eqlimit(e,c)
	return c:IsCode(110000104)
end
function c140000087.filter(c)
	return c:IsFaceup() and c:IsRace(RACE_MACHINE)
end
function c140000087.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and c140000087.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c140000087.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_EQUIP)
	Duel.SelectTarget(tp,c140000087.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_EQUIP,e:GetHandler(),1,0,0)
end
function c140000087.operation(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if e:GetHandler():IsRelateToEffect(e) and tc:IsRelateToEffect(e) and tc:IsFaceup() then
		Duel.Equip(tp,e:GetHandler(),tc)
	end
end

function c140000087.precon(e,tp,eg,ep,ev,re,r,rp)
	local ec=e:GetHandler():GetPreviousEquipTarget()
	  local ed=ec:GetReasonCard()
	return e:GetHandler():IsReason(REASON_LOST_TARGET) and ec:IsLocation(LOCATION_GRAVE)
		--and bit.band(ec:GetReason(),0x41)==0x41 
			and ec:GetReasonPlayer()~=tp 
			and ed:IsType(TYPE_SPELL)
--or ed:IsCode(170000193) or ed:IsCode(170000194) or ed:IsCode(170000195) or ed:IsCode(170000196))
end
function c140000087.preop(e,tp,eg,ep,ev,re,r,rp)
	  local c=e:GetHandler()
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	  e1:SetRange(LOCATION_GRAVE)
	  e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	  e1:SetCode(EVENT_PHASE+PHASE_STANDBY)
	  e1:SetCountLimit(1)
	  e1:SetCondition(c140000087.descon)
	  e1:SetTarget(c140000087.destg)
	  e1:SetOperation(c140000087.desop)
	  e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_STANDBY+RESET_SELF_TURN)
	  c:RegisterEffect(e1)
end
function c140000087.destg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local ec=e:GetHandler():GetPreviousEquipTarget()
	local ed=ec:GetReasonCard()
	if ed==nil then return false end	
	local te,eg,ep,ev,re,r,rp=ed:CheckActivateEffect(false,false,true)  
	if not te then return false end
	local condition=te:GetCondition()
	local cost=te:GetCost()
	local target=te:GetTarget() 
	return ed:IsType(TYPE_SPELL) and ed:CheckActivateEffect(false,false,false)~=nil 
	and (not target or target(te,1-tp,eg,ep,ev,re,r,rp,0))  
end
function c140000087.descon(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetTurnPlayer()==tp
end
function c140000087.desop(e,tp,eg,ep,ev,re,r,rp)
	local ec=e:GetHandler():GetPreviousEquipTarget()
	local ed=ec:GetReasonCard()
	local c=e:GetHandler()
	if ed:IsType(TYPE_SPELL) then
	if c:IsRelateToEffect(e) and c:IsFaceup() then
	local code=ed:GetCode()
	local tpe=tc:GetType()
	local te,eg,ep,ev,re,r,rp=tc:CheckActivateEffect(false,true,true)
	local tep=ed:GetControler()
	local condition=te:GetCondition()
	local cost=te:GetCost()
	local target=te:GetTarget()
	local operation=te:GetOperation()
	Duel.ClearTargetCard()
	e:SetCategory(te:GetCategory())
	e:SetProperty(te:GetProperty())
	if bit.band(tpe,TYPE_FIELD)~=0 then
	   local of=Duel.GetFieldCard(tp,LOCATION_SZONE,5)
	   if of and Duel.Destroy(of,REASON_RULE)==0 then Duel.SendtoGrave(tc,REASON_RULE) end
	end

	if not Duel.MoveToField(tc,tp,tp,LOCATION_SZONE,POS_FACEUP,true) then return end
	Duel.Hint(HINT_CARD,0,tc:GetOriginalCode())
	tc:CreateEffectRelation(te)
	if cost then cost(te,tp,eg,ep,ev,re,r,rp,1) end
	if target then target(te,tp,eg,ep,ev,re,r,rp,1) end
	local gg=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS)
	if gg then
		local etc=gg:GetFirst()
		while etc do
			  etc:CreateEffectRelation(te)
			etc=gg:GetNext()
		end
	end
	Duel.BreakEffect()
	if operation then operation(te,tep,eg,ep,ev,re,r,rp) end
	ed:ReleaseEffectRelation(te)
	if etc then 
		etc=gg:GetFirst()
		while etc do
			etc:ReleaseEffectRelation(te)
			etc=gg:GetNext()
		end
	end		
    if not (bit.band(tpe,TYPE_EQUIP+TYPE_CONTINUOUS+TYPE_FIELD)~=0 or tc:IsHasEffect(EFFECT_REMAIN_FIELD)) then
    Duel.SendtoGrave(tc,REASON_RULE) end
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e1:SetRange(LOCATION_SZONE)
	e1:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE)
	e1:SetCode(EVENT_PHASE+PHASE_END)
	e1:SetCountLimit(1)
	e1:SetOperation(c140000087.desop2)
	e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	ed:RegisterEffect(e1)			
	end
	end
end 
function c140000087.desop2(e,tp,eg,ep,ev,re,r,rp)
	  Duel.SendtoGrave(e:GetHandler(),REASON_EFFECT)
end
