--クリボーを呼ぶ笛
function c182.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_TOHAND+CATEGORY_SEARCH+CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c182.target)
	e1:SetOperation(c182.activate)
	c:RegisterEffect(e1)
end

function c182.filter(c,ft,e,tp)
      local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
	local code=c:GetCode()
	return (code==40640057 or code==57116033 or code==2830693 or code==413)
		and (c:IsAbleToHand() or (ft>0 and c:IsCanBeSpecialSummoned(e,0,tp,false,false)))
end
function c182.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then
		local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
		return Duel.IsExistingMatchingCard(c182.filter,tp,LOCATION_DECK,0,1,nil,ft,e,tp)
	end
end
function c182.activate(e,tp,eg,ep,ev,re,r,rp)
	local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
	Duel.Hint(HINT_SELECTMSG,tp,0)
	local g=Duel.SelectMatchingCard(tp,c182.filter,tp,LOCATION_DECK,0,1,1,nil,ft,e,tp)
	if g:GetCount()>0 then
		local th=g:GetFirst():IsAbleToHand()
		local sp=ft>0 and g:GetFirst():IsCanBeSpecialSummoned(e,0,tp,false,false) and not Duel.IsPlayerAffectedByEffect(tp,59822133)
		local op=0
		if th and sp then op=Duel.SelectOption(tp,aux.Stringid(20065322,0),aux.Stringid(20065322,1))
		elseif th then op=0
		else op=1 end
		if op==0 then
			Duel.SendtoHand(g,nil,REASON_EFFECT)
			Duel.ConfirmCards(1-tp,g)
		else
			Duel.SpecialSummon(g,0,tp,tp,false,false,POS_FACEUP)
		end
	end

      if Duel.IsExistingMatchingCard(c182.filter,tp,LOCATION_DECK,0,1,nil,ft,e,tp) then
      ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
	Duel.Hint(HINT_SELECTMSG,tp,0)
	local g2=Duel.SelectMatchingCard(tp,c182.filter,tp,LOCATION_DECK,0,1,1,nil,ft,e,tp)
	if g2:GetCount()>0 then
		local th=g2:GetFirst():IsAbleToHand()
		local sp=ft>0 and g2:GetFirst():IsCanBeSpecialSummoned(e,0,tp,false,false)
		local op=0
		if th and sp then op=Duel.SelectOption(tp,aux.Stringid(20065322,0),aux.Stringid(20065322,1))
		elseif th then op=0
		else op=1 end
		if op==0 then
			Duel.SendtoHand(g2,nil,REASON_EFFECT)
			Duel.ConfirmCards(1-tp,g2)
		else
			Duel.SpecialSummon(g2,0,tp,tp,false,false,POS_FACEUP)
		end
	end end

      if Duel.IsExistingMatchingCard(c182.filter,tp,LOCATION_DECK,0,1,nil,ft,e,tp) then
      ft=Duel.GetLocationCount(tp,LOCATION_MZONE) 
	Duel.Hint(HINT_SELECTMSG,tp,0)
	local g3=Duel.SelectMatchingCard(tp,c182.filter,tp,LOCATION_DECK,0,1,1,nil,ft,e,tp)
	if g3:GetCount()>0 then
		local th=g3:GetFirst():IsAbleToHand()
		local sp=ft>0 and g3:GetFirst():IsCanBeSpecialSummoned(e,0,tp,false,false)
		local op=0
		if th and sp then op=Duel.SelectOption(tp,aux.Stringid(20065322,0),aux.Stringid(20065322,1))
		elseif th then op=0
		else op=1 end
		if op==0 then
			Duel.SendtoHand(g3,nil,REASON_EFFECT)
			Duel.ConfirmCards(1-tp,g3)
		else
			Duel.SpecialSummon(g3,0,tp,tp,false,false,POS_FACEUP)
		end
	end end

      if Duel.IsExistingMatchingCard(c182.filter,tp,LOCATION_DECK,0,1,nil,ft,e,tp) then
      ft=Duel.GetLocationCount(tp,LOCATION_MZONE) 
	Duel.Hint(HINT_SELECTMSG,tp,0)
	local g5=Duel.SelectMatchingCard(tp,c182.filter,tp,LOCATION_DECK,0,1,1,nil,ft,e,tp)
	if g5:GetCount()>0 then
		local th=g5:GetFirst():IsAbleToHand()
		local sp=ft>0 and g5:GetFirst():IsCanBeSpecialSummoned(e,0,tp,false,false)
		local op=0
		if th and sp then op=Duel.SelectOption(tp,aux.Stringid(20065322,0),aux.Stringid(20065322,1))
		elseif th then op=0
		else op=1 end
		if op==0 then
			Duel.SendtoHand(g5,nil,REASON_EFFECT)
			Duel.ConfirmCards(1-tp,g5)
		else
			Duel.SpecialSummon(g5,0,tp,tp,false,false,POS_FACEUP)
		end
	end end
end
