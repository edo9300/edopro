--No.39 Infinity Hope
function c211.initial_effect(c)
	--xyz summon
	c:EnableReviveLimit()
	--spsummon limit
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_SPSUMMON_CONDITION)
	e1:SetValue(aux.FALSE)
	c:RegisterEffect(e1)

	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_CANNOT_DISABLE_SPSUMMON)
	e2:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	c:RegisterEffect(e2)

	--cannot destroyed
	  local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_SINGLE)
	e3:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
	e3:SetValue(c211.indes)
	c:RegisterEffect(e3) 

	--negate effect
	local e4=Effect.CreateEffect(c)
	e4:SetDescription(aux.Stringid(20374351,1))
	e4:SetCategory(CATEGORY_NEGATE+CATEGORY_DESTROY)
	e4:SetType(EFFECT_TYPE_QUICK_O)
	e4:SetCode(EVENT_CHAINING)
	e4:SetProperty(0+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCondition(c211.discon)
	e4:SetCost(c211.discost)
	e4:SetTarget(c211.distg)
	e4:SetOperation(c211.disop)
	c:RegisterEffect(e4,false,1)

	--remove
	local e5=Effect.CreateEffect(c)
	e5:SetDescription(aux.Stringid(211,0))
	e5:SetCategory(CATEGORY_REMOVE)
	e5:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e5:SetProperty(0+EFFECT_FLAG_CARD_TARGET)
	e5:SetCode(EVENT_SPSUMMON_SUCCESS)
	e5:SetCondition(c211.recon)
	e5:SetCost(c211.recost)
	e5:SetTarget(c211.retg)
	e5:SetOperation(c211.reop)
	c:RegisterEffect(e5,false,1)

	--hope disable attack
	local e01=Effect.CreateEffect(c)
	e01:SetDescription(aux.Stringid(84013237,0))
	e01:SetProperty(0+EFFECT_FLAG_DAMAGE_STEP)
	e01:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_QUICK_O)
	e01:SetRange(LOCATION_MZONE)
	e01:SetCode(EVENT_FREE_CHAIN)
	e01:SetHintTiming(TIMING_BATTLE_PHASE)
	e01:SetCondition(c211.atkcon)
	e01:SetCost(c211.atkcost)
	e01:SetOperation(c211.atkop)
	c:RegisterEffect(e01,false,1)

	--hope ray attack up
	local e11=Effect.CreateEffect(c)
	e11:SetCategory(CATEGORY_ATKCHANGE)
	e11:SetProperty(0)  
	e11:SetDescription(aux.Stringid(56840427,0))
	e11:SetType(EFFECT_TYPE_IGNITION)
	e11:SetRange(LOCATION_MZONE)
	e11:SetCountLimit(1)
	e11:SetCondition(c211.atkcon2)
	e11:SetCost(c211.cost)
	e11:SetOperation(c211.operation)
	c:RegisterEffect(e11,false,1)

	--hope ray v destroy
	local e21=Effect.CreateEffect(c) 
	e21:SetCategory(CATEGORY_DESTROY+CATEGORY_DAMAGE) 
	e21:SetDescription(aux.Stringid(66970002,1)) 
	e21:SetType(EFFECT_TYPE_IGNITION) 
	e21:SetProperty(EFFECT_FLAG_CARD_TARGET) 
	e21:SetCountLimit(1) 
	e21:SetRange(LOCATION_MZONE) 
	e21:SetCondition(c211.atkcon3)
	e21:SetCost(c211.descost) 
	e21:SetTarget(c211.destg) 
	e21:SetOperation(c211.desop) 
	c:RegisterEffect(e21,false,1) 

	--victory actlimit
	local e31=Effect.CreateEffect(c)
	e31:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e31:SetCode(EVENT_ATTACK_ANNOUNCE)
	e31:SetCondition(c211.atkcon4)
	e31:SetOperation(c211.atkoperation)
	c:RegisterEffect(e31)
	--destroy
	local e32=Effect.CreateEffect(c)
	e32:SetDescription(aux.Stringid(87911394 ,0))
	e32:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_QUICK_O)
	e32:SetCode(EVENT_FREE_CHAIN)
	e32:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e32:SetHintTiming(TIMING_BATTLE_PHASE)
	e32:SetRange(LOCATION_MZONE)
	e32:SetCondition(c211.atkcon5)
	e32:SetCost(c211.atkcost2)
	e32:SetTarget(c211.atktg2)
	e32:SetOperation(c211.atkop2)
	c:RegisterEffect(e32,false,1)

	  --roots disable attack
	  local e41=Effect.CreateEffect(c)  
	  e41:SetDescription(aux.Stringid(84124261,0))  
	e41:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_QUICK_O)
	e41:SetCode(EVENT_FREE_CHAIN)
	e41:SetHintTiming(TIMING_BATTLE_PHASE)
	e41:SetRange(LOCATION_MZONE)
	  e41:SetCondition(c211.atkcon6)
	  e41:SetCost(c211.atkcost3)  
	  e41:SetTarget(c211.atktg3)  
	  e41:SetOperation(c211.atkop3)  
	  c:RegisterEffect(e41,false,1)

	--one remove
	local e51=Effect.CreateEffect(c)
	e51:SetProperty(0)  
	e51:SetCategory(CATEGORY_REMOVE+CATEGORY_DAMAGE)
	e51:SetDescription(aux.Stringid(86532744,0))
	e51:SetType(EFFECT_TYPE_IGNITION)
	e51:SetRange(LOCATION_MZONE)
	e51:SetCountLimit(1)
	  e51:SetCondition(c211.atkcon7)
	e51:SetCost(c211.cost2)
	e51:SetTarget(c211.target2)
	e51:SetOperation(c211.operation2)
	c:RegisterEffect(e51,false,1)

	--beyond immune
	local e81=Effect.CreateEffect(c)
	e81:SetType(EFFECT_TYPE_FIELD)
	e81:SetCode(EFFECT_IMMUNE_EFFECT)
	e81:SetProperty(EFFECT_FLAG_SET_AVAILABLE)
	e81:SetRange(LOCATION_MZONE)
	  e81:SetTargetRange(LOCATION_ONFIELD,0)
	  e81:SetCondition(c211.atkcon10)
	e81:SetValue(c211.efilter)
	c:RegisterEffect(e81)
	--ATK to 0
	local e82=Effect.CreateEffect(c)
	e82:SetType(EFFECT_TYPE_FIELD)
	e82:SetCode(EFFECT_SET_ATTACK_FINAL)
	e82:SetRange(LOCATION_MZONE)
	e82:SetTargetRange(0,LOCATION_MZONE)
	e82:SetCondition(c211.atkcon11)
	e82:SetValue(0)
	c:RegisterEffect(e82)
	local e83=Effect.CreateEffect(c)
	e83:SetDescription(aux.Stringid(21521304,1))
	e83:SetCategory(CATEGORY_REMOVE+CATEGORY_SPECIAL_SUMMON+CATEGORY_RECOVER)
	e83:SetType(EFFECT_TYPE_QUICK_O)
	e83:SetCode(EVENT_FREE_CHAIN)
	e83:SetRange(LOCATION_MZONE)
	e83:SetProperty(0+EFFECT_FLAG_CARD_TARGET)
	e83:SetCountLimit(1)
	  e83:SetCost(c211.cost5)
	e83:SetCondition(c211.atkcon12)
	e83:SetTarget(c211.target5)
	e83:SetOperation(c211.operation5)
	c:RegisterEffect(e83,false,1)

	--spsummon success
	local e91=Effect.CreateEffect(c)
	e91:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)   
	e91:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e91:SetCode(EVENT_SPSUMMON_SUCCESS)
	e91:SetCondition(c211.atkcon13)
	e91:SetOperation(c211.sno0sucop)
	c:RegisterEffect(e91)

	--atk
	local e92=Effect.CreateEffect(c)
	e92:SetType(EFFECT_TYPE_SINGLE)
	--e92:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	--e92:SetRange(LOCATION_MZONE)
	e92:SetCode(EFFECT_SET_ATTACK)
	e92:SetCondition(c211.atkcon142)
	e92:SetValue(c211.sno0atkval)
	c:RegisterEffect(e92)

	--negate
	local e101=Effect.CreateEffect(c)
	e101:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e101:SetCode(EVENT_ATTACK_ANNOUNCE)
	e101:SetCondition(c211.atkcon14)
	e101:SetOperation(c211.sno39negop1)
	c:RegisterEffect(e101)
	local e102=Effect.CreateEffect(c)
	e102:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e102:SetCode(EVENT_BE_BATTLE_TARGET)
	e102:SetCondition(c211.atkcon14)
	e102:SetOperation(c211.sno39negop2)
	c:RegisterEffect(e102)
end
c211.xyz_number=39

function c211.indes(e,c)
	return not e:GetHandler():GetBattleTarget():IsSetCard(0x48)
end
function c211.discon(e,tp,eg,ep,ev,re,r,rp)
	return not e:GetHandler():IsStatus(STATUS_BATTLE_DESTROYED) and Duel.IsChainNegatable(ev)
end
function c211.discost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():CheckRemoveOverlayCard(tp,1,REASON_COST) end
	e:GetHandler():RemoveOverlayCard(tp,1,1,REASON_COST)
end
function c211.distg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetOperationInfo(0,CATEGORY_NEGATE,eg,1,0,0)
	if re:GetHandler():IsDestructable() and re:GetHandler():IsRelateToEffect(re) then
		Duel.SetOperationInfo(0,CATEGORY_DESTROY,eg,1,0,0)
	end
end
function c211.disop(e,tp,eg,ep,ev,re,r,rp)
	Duel.NegateActivation(ev)
	if re:GetHandler():IsRelateToEffect(re) then
		Duel.Destroy(eg,REASON_EFFECT)
	end
end
function c211.recost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():CheckRemoveOverlayCard(tp,2,REASON_COST) end
	e:GetHandler():RemoveOverlayCard(tp,2,2,REASON_COST)
end
function c211.recon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler()
end
function c211.retg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsOnField() end
	if chk==0 then return Duel.GetFieldGroupCount(tp,0,LOCATION_HAND)>0 and Duel.IsExistingTarget(Card.IsAbleToRemove,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
	local count = Duel.GetFieldGroupCount(tp,0,LOCATION_HAND)
	local g=Duel.SelectTarget(tp,Card.IsAbleToRemove,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,1,count,nil)
	local tc=g:GetFirst()
	if tc and tc:IsAbleToRemove() then
		Duel.SetOperationInfo(0,CATEGORY_REMOVE,tc,count,0,0)
		Duel.SetChainLimit(c211.chlimit)
	end
end
function c211.chlimit(e,ep,tp)
	local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS)
	return tp==ep or not g:IsContains(e:GetHandler())
end
function c211.reop(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS)
	local sg=g:Filter(Card.IsRelateToEffect,nil,e)
		Duel.Remove(sg,POS_FACEUP,REASON_EFFECT)
end

--hope
function c211.atkcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	--local bc=c:GetBattleTarget()
	return c:GetOverlayGroup():IsExists(Card.IsCode,1,nil,84013237) and Duel.GetCurrentPhase()>=PHASE_BATTLE_START and Duel.GetCurrentPhase()<=PHASE_BATTLE
	  and not c:IsStatus(STATUS_CHAINING) and Duel.GetAttacker()~=nil and Duel.GetAttacker():IsAttackable()
end
function c211.atkcost(e,tp,eg,ep,ev,re,r,rp,chk)
	  if chk==0 then
	  local sel=0
	if Duel.CheckLPCost(tp,400)==true then sel=sel+1 end
	if e:GetHandler():GetOverlayGroup():IsExists(Card.IsCode,1,nil,84013237)==true then sel=sel+2 end
	e:SetLabel(sel)
	  return sel~=0
	end
	local sel=e:GetLabel()
	if sel==3 then
		Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(13718,0))
		sel=Duel.SelectOption(tp,aux.Stringid(13718,1),aux.Stringid(13718,2))+1
	end
	e:SetLabel(sel)
	if sel==1 then Duel.PayLPCost(tp,400) end
	if sel==2 then 
	  local o=e:GetHandler():GetOverlayGroup() 
	local g=o:FilterSelect(tp,Card.IsCode,1,1,e:GetHandler(),84013237)
	  Duel.SendtoGrave(g,REASON_COST) end
end
function c211.atkop(e,tp,eg,ep,ev,re,r,rp)
	Duel.Hint(HINT_CARD,tp,84013237)
	Duel.NegateAttack()
end

--hope ray
function c211.atkcon2(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetOverlayGroup():IsExists(Card.IsCode,1,nil,56840427)
end
function c211.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	  if chk==0 then
	  local sel=0
	if Duel.CheckLPCost(tp,400)==true then sel=sel+1 end
	if e:GetHandler():GetOverlayGroup():IsExists(Card.IsCode,1,nil,56840427)==true then sel=sel+2 end
	e:SetLabel(sel)
	  return sel~=0
	end
	local sel=e:GetLabel()
	if sel==3 then
		Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(211,2))
		sel=Duel.SelectOption(tp,aux.Stringid(211,3),aux.Stringid(211,4))+1
	end
	e:SetLabel(sel)
	if sel==1 then Duel.PayLPCost(tp,400) end
	if sel==2 then 
	  local o=e:GetHandler():GetOverlayGroup() 
	local g=o:FilterSelect(tp,Card.IsCode,1,1,e:GetHandler(),56840427)
	  Duel.SendtoGrave(g,REASON_COST) end
end
function c211.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	Duel.Hint(HINT_CARD,tp,56840427)
	if c:IsRelateToEffect(e) and c:IsFaceup() then
		local e1=Effect.CreateEffect(c)
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(500)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		c:RegisterEffect(e1)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
		local g=Duel.SelectMatchingCard(tp,Card.IsFaceup,tp,0,LOCATION_MZONE,1,1,nil)
		if g:GetCount()>0 then
			Duel.HintSelection(g)
			local e2=Effect.CreateEffect(c)
			e2:SetType(EFFECT_TYPE_SINGLE)
			e2:SetCode(EFFECT_UPDATE_ATTACK)
			e2:SetValue(-1000)
			e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
			g:GetFirst():RegisterEffect(e2)
		end
	end
end

--hope ray v
function c211.atkcon3(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetOverlayGroup():IsExists(Card.IsCode,1,nil,66970002)
end
function c211.descost(e,tp,eg,ep,ev,re,r,rp,chk)
	  if chk==0 then
	  local sel=0
	if Duel.CheckLPCost(tp,400)==true then sel=sel+1 end
	if e:GetHandler():GetOverlayGroup():IsExists(Card.IsCode,1,nil,66970002)==true then sel=sel+2 end
	e:SetLabel(sel)
	  return sel~=0
	end
	local sel=e:GetLabel()
	if sel==3 then
		Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(211,2))
		sel=Duel.SelectOption(tp,aux.Stringid(211,3),aux.Stringid(211,4))+1
	end
	e:SetLabel(sel)
	if sel==1 then Duel.PayLPCost(tp,400) end
	if sel==2 then 
	  local o=e:GetHandler():GetOverlayGroup() 
	local g=o:FilterSelect(tp,Card.IsCode,1,1,e:GetHandler(),66970002)
	  Duel.SendtoGrave(g,REASON_COST) end
end
function c211.filter(c)
	return aux.TRUE
end
function c211.destg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(1-tp) and c211.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c211.filter,tp,0,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_CARD,tp,66970002)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_DESTROY)
	local g=Duel.SelectTarget(tp,c211.filter,tp,0,LOCATION_MZONE,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,g:GetFirst():GetAttack())
end
function c211.desop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) and tc:IsControler(1-tp) then
		local atk=tc:GetAttack()
		if atk<0 or tc:IsFacedown() then atk=0 end
		if Duel.Destroy(tc,REASON_EFFECT)~=0 then
			Duel.Damage(1-tp,atk,REASON_EFFECT)
		end
	end
end

--hope ray victory
function c211.atkcon4(e,tp,eg,ep,ev,re,r,rp)
	  return e:GetHandler():GetOverlayGroup():IsExists(Card.IsCode,1,nil,87911394)
end
function c211.atkoperation(e,tp,eg,ep,ev,re,r,rp)
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetCode(EFFECT_CANNOT_ACTIVATE)
	e1:SetTargetRange(0,1)
	e1:SetValue(c211.aclimit)
	e1:SetReset(RESET_PHASE+PHASE_DAMAGE)
	Duel.RegisterEffect(e1,tp)
end
function c211.aclimit(e,re,tp)
	return re:IsHasType(EFFECT_TYPE_ACTIVATE)
end

function c211.atkcon5(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local at=c:GetBattleTarget()
	return at and at:IsFaceup() and e:GetHandler():GetOverlayGroup():IsExists(Card.IsCode,1,nil,87911394) and not e:GetHandler():IsStatus(STATUS_CHAINING)
end
function c211.atkcost2(e,tp,eg,ep,ev,re,r,rp,chk)
	  if chk==0 then
	  local sel=0
	if Duel.CheckLPCost(tp,400)==true then sel=sel+1 end
	if e:GetHandler():GetOverlayGroup():IsExists(Card.IsCode,1,nil,87911394)==true then sel=sel+2 end
	e:SetLabel(sel)
	  return sel~=0
	end
	local sel=e:GetLabel()
	if sel==3 then
		Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(13718,0))
		sel=Duel.SelectOption(tp,aux.Stringid(13718,1),aux.Stringid(13718,2))+1
	end
	e:SetLabel(sel)
	if sel==1 then Duel.PayLPCost(tp,400) end
	if sel==2 then 
	  local o=e:GetHandler():GetOverlayGroup() 
	local g=o:FilterSelect(tp,Card.IsCode,1,1,e:GetHandler(),87911394)
	  Duel.SendtoGrave(g,REASON_COST) end
end
function c211.atktg2(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return false end
	local c=e:GetHandler()
	local bc=c:GetBattleTarget()
	if chk==0 then return bc and bc:IsOnField() and bc:IsCanBeEffectTarget(e) end
	Duel.Hint(HINT_CARD,tp,87911394)
	Duel.SetTargetCard(bc)
end
function c211.atkop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if tc and tc:IsRelateToEffect(e) and tc:IsFaceup() then
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e1)
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE_EFFECT)
		e2:SetValue(RESET_TURN_SET)
		e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e2)
		Duel.AdjustInstantly(tc)
		local atk=tc:GetAttack()
		if c:IsFaceup() and c:IsRelateToEffect(e) then
			local e1=Effect.CreateEffect(c)
			e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetCode(EFFECT_UPDATE_ATTACK)
			e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
			e1:SetValue(atk)
			e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
			c:RegisterEffect(e1)
		end
	end
end

--hope root
function c211.atkfilter(c)
		return e:GetHandler():GetOverlayGroup()
end
function c211.atkcon6(e)
		local bt=e:GetHandler():GetBattleTarget()
		return bt~=nil and bt:IsType(TYPE_XYZ) and bt:IsFaceup() and e:GetHandler():GetOverlayGroup():IsExists(Card.IsCode,1,nil,84124261) and not e:GetHandler():IsStatus(STATUS_CHAINING)
end
function c211.atkcost3(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then
	local sel=0
	if Duel.CheckLPCost(tp,400)==true then sel=sel+1 end
	if e:GetHandler():GetOverlayGroup():IsExists(Card.IsCode,1,nil,84124261)==true then sel=sel+2 end
	e:SetLabel(sel)
	return sel~=0
	end
	local sel=e:GetLabel()
	if sel==3 then
	   Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(13718,0))
	   sel=Duel.SelectOption(tp,aux.Stringid(13718,1),aux.Stringid(13718,2))+1
	end
	e:SetLabel(sel)
	if sel==1 then Duel.PayLPCost(tp,400) end
	if sel==2 then 
	   local o=e:GetHandler():GetOverlayGroup() 
	   Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(47660516,0))	   
	   local g=o:FilterSelect(tp,Card.IsCode,1,1,e:GetHandler(),84124261)
	   Duel.Overlay(e:GetHandler():GetBattleTarget(),g)
	end
end
function c211.atktg3(e,tp,eg,ep,ev,re,r,rp,chk)
		if chk==0 then return e:GetHandler():CheckRemoveOverlayCard(tp,1,REASON_EFFECT) end
	Duel.Hint(HINT_CARD,tp,84124261)
end
function c211.atkop3(e,tp,eg,ep,ev,re,r,rp)
		if not e:GetHandler():CheckRemoveOverlayCard(tp,1,REASON_EFFECT) then return end
	  local c=e:GetHandler()
		local o=c:GetOverlayGroup() 
	  local bt=c:GetBattleTarget()
	  if tc==c then tc=Duel.GetAttackTarget() end
		if Duel.GetAttacker()==e:GetHandler() then
		Duel.NegateAttack() end
		if tc:IsType(TYPE_XYZ) and tc:IsFaceup()
				and c:IsRelateToEffect(e) and c:IsFaceup() then
		local diff=0
		if tc:GetRank()>=c:GetRank() then
		diff=(tc:GetRank()-c:GetRank())*100 end
		if tc:GetRank()<c:GetRank() then
		diff=(c:GetRank()-tc:GetRank())*100 end
		local val=diff*tc:GetOverlayCount() 
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_SET_ATTACK_FINAL)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		e1:SetValue(val)
		c:RegisterEffect(e1)
		end
end

--hope one
function c211.onefilter(c)
	return c:IsCode(65) or c:IsCode(86532744)
end
function c211.atkcon7(e,tp,eg,ep,ev,re,r,rp)
	  return e:GetHandler():GetOverlayGroup():IsExists(c211.onefilter,1,nil)
end
function c211.cost2(e,tp,eg,ep,ev,re,r,rp,chk)
	  if chk==0 then
	  local sel=0
	if Duel.CheckLPCost(tp,400)==true then sel=sel+1 end
	if e:GetHandler():GetOverlayGroup():IsExists(c211.onefilter,1,nil)==true then sel=sel+2 end
	e:SetLabel(sel)
	  return sel~=0 and Duel.GetLP(tp)>1
	end
	local sel=e:GetLabel()
	if sel==3 then
		Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(13718,0))
		sel=Duel.SelectOption(tp,aux.Stringid(13718,1),aux.Stringid(13718,2))+1
	end
	e:SetLabel(sel)
	if sel==1 then Duel.PayLPCost(tp,400) end
	if sel==2 then 
	  local o=e:GetHandler():GetOverlayGroup() 
	local g=o:FilterSelect(tp,c211.onefilter,1,1,e:GetHandler())
	  Duel.SendtoGrave(g,REASON_COST) end
	  Duel.SetLP(tp,1)  
end
function c211.target2(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(Card.IsAbleToRemove,tp,0,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_CARD,tp,65)
	local sg=Duel.GetMatchingGroup(Card.IsAbleToRemove,tp,0,LOCATION_MZONE,nil)
	local sg2=Duel.GetMatchingGroup(c211.ovfilter2,tp,0,LOCATION_MZONE,nil,e)
	  local dam=0
	  local tc=sg2:GetFirst()
	  while tc do
	  local atk=tc:GetAttack()
	  dam=dam+atk
	  tc=sg2:GetNext() end
	Duel.SetOperationInfo(0,CATEGORY_REMOVE,sg,sg:GetCount(),0,0)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,dam)
end
function c211.ovfilter2(c,e)
	return c:IsAbleToRemove() and not c:IsImmuneToEffect(e)
end
function c211.operation2(e,tp,eg,ep,ev,re,r,rp)
	  local sg=Duel.GetMatchingGroup(c211.ovfilter2,tp,0,LOCATION_MZONE,nil,e)
	  local dam=0
	  local tc=sg:GetFirst()
	  while tc do
	  local atk=tc:GetAttack()
	  dam=dam+atk
	  tc=sg:GetNext() end
	  if Duel.Remove(sg,POS_FACEUP,REASON_EFFECT)>0 then
	  Duel.Damage(1-tp,dam,REASON_EFFECT) end
end

--hope future
function c211.atkcon8(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetOverlayGroup():IsExists(c211.fno0filter,1,nil)
end
function c211.fno0filter(c)
	return c:IsCode(209) or c:IsCode(65305468)
end

function c211.atktg4(e,tp,eg,ep,ev,re,r,rp,chk)
	  local tc=e:GetHandler():GetBattleTarget()
	  local p=e:GetHandler():GetControler()
	if chk==0 then return Duel.GetLocationCount(p,LOCATION_MZONE)>0 and tc~=nil and tc:IsControler(1-p) end
	--Duel.SetTargetCard(tc)
end
function c211.atktg5(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0 end
	Duel.SetTargetCard(Duel.GetAttacker())
end
function c211.atkop4(e,tp,eg,ep,ev,re,r,rp)
	  local p=e:GetHandler():GetControler()
	  if Duel.GetLocationCount(p,LOCATION_MZONE)==0 then return end
	--local tc=Duel.GetFirstTarget()
	local tc=e:GetHandler():GetBattleTarget()
	--if tc:IsRelateToEffect(e) then
		Duel.GetControl(tc,p,EVENT_PHASE+PHASE_BATTLE,1)
	--end
end

function c211.cost3(e,tp,eg,ep,ev,re,r,rp,chk)
	  if chk==0 then
	  local sel=0
	if Duel.CheckLPCost(tp,400)==true then sel=sel+1 end
	if e:GetHandler():GetOverlayGroup():IsExists(c211.fno0filter,1,nil)==true then sel=sel+2 end
	e:SetLabel(sel)
	  return sel~=0 and not e:GetHandler():IsStatus(STATUS_CHAINING) 
	end
	local sel=e:GetLabel()
	if sel==3 then
		Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(13718,0))
		sel=Duel.SelectOption(tp,aux.Stringid(13718,1),aux.Stringid(13718,2))+1
	end
	e:SetLabel(sel)
	if sel==1 then Duel.PayLPCost(tp,400) end
	if sel==2 then 
	  local o=e:GetHandler():GetOverlayGroup() 
	local g=o:FilterSelect(tp,c211.fno0filter,1,1,e:GetHandler())
	  Duel.SendtoGrave(g,REASON_COST) end
end
function c211.operation3(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	Duel.Hint(HINT_CARD,tp,209)
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
	e1:SetTargetRange(LOCATION_MZONE,0)
	e1:SetTarget(c211.etarget)
	e1:SetValue(1)
	e1:SetReset(RESET_PHASE+PHASE_END)
	Duel.RegisterEffect(e1,tp)
	local e2=e1:Clone()
	e2:SetCode(EFFECT_INDESTRUCTABLE_EFFECT)
	Duel.RegisterEffect(e2,tp)
end
function c211.etarget(e,c)
	return c:IsFaceup() and c==e:GetHandler()
end
function c211.operation4(e,tp,eg,ep,ev,re,r,rp)
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_CHANGE_DAMAGE)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetTargetRange(1,0)
	e1:SetValue(c211.damval)
	e1:SetReset(RESET_PHASE+PHASE_END,1)
	Duel.RegisterEffect(e1,tp)
end
function c211.damval(e,re,val,r,rp,rc)
	if bit.band(r,REASON_EFFECT)~=0 then return 0
	else return val end
end

--hope dragon
function c211.atkcon9(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetOverlayGroup():IsExists(c211.no99filter,1,nil)
end
function c211.no99filter(c)
	return c:IsCode(210) or c:IsCode(51543904)
end
function c211.filter5(c,e,tp)
	return c:IsType(TYPE_XYZ) and (c:IsSetCard(0x48) or c:IsSetCard(0x1048) or c:IsSetCard(0x2048))
		and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
end
function c211.sptg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and Duel.IsExistingMatchingCard(c211.filter5,tp,LOCATION_GRAVE,0,1,nil,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_GRAVE)
end
function c211.spop(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0 then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(tp,c211.filter5,tp,LOCATION_GRAVE,0,1,1,nil,e,tp)
	if g:GetCount()>0 then
	local c=e:GetHandler()
	local tc=g:GetFirst()
	if tc then
		Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP)
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE_EFFECT)
		e2:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e2)
	end
	Duel.SpecialSummonComplete()
end
end
function c211.cost4(e,tp,eg,ep,ev,re,r,rp,chk)
	  if chk==0 then
	  local sel=0
	if Duel.CheckLPCost(tp,400)==true then sel=sel+1 end
	if e:GetHandler():GetOverlayGroup():IsExists(c211.no99filter,1,nil)==true then sel=sel+2 end
	e:SetLabel(sel)
	  return sel~=0
	end
	local sel=e:GetLabel()
	if sel==3 then
		Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(13718,0))
		sel=Duel.SelectOption(tp,aux.Stringid(13718,1),aux.Stringid(13718,2))+1
	end
	e:SetLabel(sel)
	if sel==1 then Duel.PayLPCost(tp,400) end
	if sel==2 then 
	  local o=e:GetHandler():GetOverlayGroup() 
	local g=o:FilterSelect(tp,c211.no99filter,1,1,e:GetHandler())
	  Duel.SendtoGrave(g,REASON_COST) end
end
function c211.filter51(c,e)
	return c==e:GetHandler()
end
function c211.descondition(e,tp,eg,ep,ev,re,r,rp)
	if not Duel.IsChainNegatable(ev) then return false end
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_DESTROY)
	return ex and tg~=nil and tc+tg:FilterCount(c211.filter51,nil,e)-tg:GetCount()>0 
	  and e:GetHandler():GetOverlayGroup():IsExists(c211.no99filter,1,nil)
end
function c211.target4(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.Hint(HINT_CARD,tp,210)
	Duel.SetOperationInfo(0,CATEGORY_NEGATE,eg,1,0,0)
	if re:GetHandler():IsRelateToEffect(re) then
		  local g=Duel.GetMatchingGroup(c211.filter590,tp,LOCATION_MZONE,LOCATION_MZONE,e:GetHandler())
		Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,g:GetCount(),0,0)
		  local tc=g:GetFirst()
		  local dam=0
		  while tc do
			 local atk=tc:GetAttack()
			 if atk<0 then atk=0 end
			 dam=dam+atk
			 tc=g:GetNext()
		  end
			Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,dam)
	end
end
function c211.filter590(c)
	return aux.TRUE
end
function c211.filter59(c,e)
	return aux.TRUE and not c:IsImmuneToEffect(e)
end
function c211.activate4(e,tp,eg,ep,ev,re,r,rp)
	local tc=re:GetHandler()
	if Duel.NegateActivation(ev) then
	local g=Duel.GetMatchingGroup(aux.TRUE,tp,LOCATION_MZONE,LOCATION_MZONE,e:GetHandler(),e)
	local tc=g:GetFirst()
	local dam=0
	while tc do
		local atk=tc:GetAttack()
		if atk<0 then atk=0 end
		dam=dam+atk
		tc=g:GetNext()
	end
	  if Duel.Destroy(g,REASON_EFFECT)>0 then
	Duel.Damage(1-tp,dam,REASON_EFFECT) end
	  end
end
function c211.handcondition(e,tp,eg,ep,ev,re,r,rp)
	if not Duel.IsChainNegatable(ev) then return false end
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_TOHAND)
	return ex and tg~=nil and tc+tg:FilterCount(c211.filter51,nil,e)-tg:GetCount()>0 
	  and e:GetHandler():GetOverlayGroup():IsExists(c211.no99filter,1,nil)
end
function c211.deckcondition(e,tp,eg,ep,ev,re,r,rp)
	if not Duel.IsChainNegatable(ev) then return false end
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_TODECK)
	return ex and tg~=nil and tc+tg:FilterCount(c211.filter51,nil,e)-tg:GetCount()>0 
	  and e:GetHandler():GetOverlayGroup():IsExists(c211.no99filter,1,nil)
end
function c211.rmcondition(e,tp,eg,ep,ev,re,r,rp)
	if not Duel.IsChainNegatable(ev) then return false end
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_REMOVE)
	return ex and tg~=nil and tc+tg:FilterCount(c211.filter51,nil,e)-tg:GetCount()>0 
	  and e:GetHandler():GetOverlayGroup():IsExists(c211.no99filter,1,nil)
end
function c211.ctcondition(e,tp,eg,ep,ev,re,r,rp)
	if not Duel.IsChainNegatable(ev) then return false end
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_CONTROL)
	return ex and tg~=nil and tc+tg:FilterCount(c211.filter51,nil,e)-tg:GetCount()>0 
	  and e:GetHandler():GetOverlayGroup():IsExists(c211.no99filter,1,nil)
end
function c211.togravecondition(e,tp,eg,ep,ev,re,r,rp)
	if not Duel.IsChainNegatable(ev) then return false end
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_TOGRAVE)
	return ex and tg~=nil and tc+tg:FilterCount(c211.filter51,nil,e)-tg:GetCount()>0 
	  and e:GetHandler():GetOverlayGroup():IsExists(c211.no99filter,1,nil)
end
function c211.releasecondition(e,tp,eg,ep,ev,re,r,rp)
	if not Duel.IsChainNegatable(ev) then return false end
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_RELEASE)
	return ex and tg~=nil and tc+tg:FilterCount(c211.filter51,nil,e)-tg:GetCount()>0 
	  and e:GetHandler():GetOverlayGroup():IsExists(c211.no99filter,1,nil)
end
function c211.spcondition(e,tp,eg,ep,ev,re,r,rp)
	return eg:IsContains(e:GetHandler())
end
function c211.spactivate(e,tp,eg,ep,ev,re,r,rp)   
	  Duel.NegateSummon(re:GetHandler())
	local g=Duel.GetMatchingGroup(aux.TRUE,tp,LOCATION_MZONE,LOCATION_MZONE,e:GetHandler())
	local tc=g:GetFirst()
	local dam=0
	while tc do
		local atk=tc:GetAttack()
		if atk<0 then atk=0 end
		dam=dam+atk
		tc=g:GetNext()
	end
	  if Duel.Destroy(g,REASON_EFFECT)>0 then
	Duel.Damage(1-tp,dam,REASON_EFFECT) end
end

--beyond hope
function c211.no39filter(c)
	return c:IsCode(13719) or c:IsCode(21521304)
end
function c211.atkcon10(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetOverlayGroup():IsExists(c211.no39filter,1,nil)
end
function c211.efilter(e,te)
	return te:GetOwnerPlayer()~=e:GetHandlerPlayer()
end

--ATK to 0
function c211.atkcon11(e)
	local ph=Duel.GetCurrentPhase()
	local tp=Duel.GetTurnPlayer()
	return tp==e:GetHandler():GetControler() 
and (ph>=PHASE_BATTLE_START and ph<=PHASE_BATTLE)
--and ph==PHASE_BATTLE
	  and e:GetHandler():GetOverlayGroup():IsExists(c211.no39filter,1,nil)
end

--Utopia
function c211.atkcon12(e,tp,eg,ep,ev,re,r,rp)
	  local ph=Duel.GetCurrentPhase()
	return 
(ph>=PHASE_BATTLE_START and ph<=PHASE_BATTLE)
--ph==PHASE_BATTLE
	  and e:GetHandler():GetOverlayGroup():IsExists(c211.no39filter,1,nil)
end
function c211.cost5(e,tp,eg,ep,ev,re,r,rp,chk)
	  if chk==0 then
	  local sel=0
	if Duel.CheckLPCost(tp,400)==true then sel=sel+1 end
	if e:GetHandler():GetOverlayGroup():IsExists(c211.no39filter,1,nil)==true then sel=sel+2 end
	e:SetLabel(sel)
	  return sel~=0
	end
	local sel=e:GetLabel()
	if sel==3 then
		Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(13718,0))
		sel=Duel.SelectOption(tp,aux.Stringid(13718,1),aux.Stringid(13718,2))+1
	end
	e:SetLabel(sel)
	if sel==1 then Duel.PayLPCost(tp,400) end
	if sel==2 then 
	  local o=e:GetHandler():GetOverlayGroup() 
	local g=o:FilterSelect(tp,c211.no39filter,1,1,e:GetHandler())
	  Duel.SendtoGrave(g,REASON_COST) end
end
function c211.rmfilter(c)
	return c:IsFaceup() and c:IsType(TYPE_XYZ) and c:IsAbleToRemove()
end
function c211.spfilter7(c,e,tp)
	return c:IsCode(84013237) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
end
function c211.target5(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return false end
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>-1
		and Duel.IsExistingTarget(c211.rmfilter,tp,LOCATION_MZONE,0,1,nil)
		and Duel.IsExistingTarget(c211.spfilter7,tp,LOCATION_GRAVE,0,1,nil,e,tp) end
	Duel.Hint(HINT_CARD,tp,13719)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
	local g1=Duel.SelectTarget(tp,c211.rmfilter,tp,LOCATION_MZONE,0,1,1,nil)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g2=Duel.SelectTarget(tp,c211.spfilter7,tp,LOCATION_GRAVE,0,1,1,nil,e,tp)
	Duel.SetOperationInfo(0,CATEGORY_REMOVE,g1,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,g2,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_RECOVER,0,0,tp,(g2:GetFirst():GetAttack())/2)
end
function c211.operation5(e,tp,eg,ep,ev,re,r,rp)
	local ex,g1=Duel.GetOperationInfo(0,CATEGORY_REMOVE)
	local ex,g2=Duel.GetOperationInfo(0,CATEGORY_SPECIAL_SUMMON)
	local tc1=g1:GetFirst()
	if not tc1:IsRelateToEffect(e) or Duel.Remove(tc1,POS_FACEUP,REASON_EFFECT)==0 then return end
	local tc2=g2:GetFirst()
	if not tc2:IsRelateToEffect(e) or Duel.SpecialSummon(tc2,0,tp,tp,false,false,POS_FACEUP)==0 then return end
	Duel.BreakEffect()
	Duel.Recover(tp,(tc2:GetAttack())/2,REASON_EFFECT)
end

--zexal
function c211.zexalfilter(c)
	return c:IsCode(364) or c:IsCode(52653092)
end
function c211.atkcon13(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetOverlayGroup():IsExists(c211.zexalfilter,1,nil)
end
function c211.sno0filter(c)
	return c:IsFaceup() and (c:IsLocation(LOCATION_SZONE) or c:IsType(TYPE_EFFECT))
end
function c211.sno0filter2(c)
	return c:IsFacedown() 
end
function c211.sno0aclimit(e,re,tp)
	local rc=re:GetHandler()
	return re:IsHasType(EFFECT_TYPE_ACTIVATE) and rc:IsLocation(LOCATION_SZONE) and rc:IsFacedown()
end
function c211.sno0sucop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Duel.GetMatchingGroup(c211.sno0filter,tp,0,LOCATION_ONFIELD,nil)
	local g2=Duel.GetMatchingGroup(c211.sno0filter2,tp,0,LOCATION_SZONE,nil)
	local tc=g:GetFirst()
	local tc2=g2:GetFirst()
	while tc do
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e1)
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE_EFFECT)
		e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e2)
		tc=g:GetNext()
	end
	while tc2 do
		  local e3=Effect.CreateEffect(c)
		  e3:SetType(EFFECT_TYPE_FIELD)
		  e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
		  e3:SetCode(EFFECT_CANNOT_ACTIVATE)
		  e3:SetRange(LOCATION_MZONE)
		  e3:SetTargetRange(0,1)
		  e3:SetValue(c211.sno0aclimit)
		e3:SetReset(RESET_PHASE+PHASE_END)
		  c:RegisterEffect(e3)
		tc2=g2:GetNext()
	end
end

--hope thunder
function c211.thunderfilter(c)
	return c:IsCode(326) or c:IsCode(56832966)
end
function c211.atkcon14(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetOverlayGroup():IsExists(c211.thunderfilter,1,nil)
end
function c211.atkcon142(e,tp,eg,ep,ev,re,r,rp)
	return (e:GetHandler():GetOverlayGroup():IsExists(c211.thunderfilter,1,nil) and e:GetHandler():GetOverlayGroup():IsExists(Card.IsSetCard,1,nil,0x7f))
	  or e:GetHandler():GetOverlayGroup():IsExists(c211.zexalfilter,1,nil) 
end
function c211.sno0atkval(e,c)
	  if e:GetHandler():GetOverlayGroup():IsExists(c211.zexalfilter,1,nil) 
		 and not e:GetHandler():GetOverlayGroup():IsExists(c211.thunderfilter,1,nil) then
	  return e:GetHandler():GetOverlayGroup():GetSum(Card.GetRank)*500 end
	  if (e:GetHandler():GetOverlayGroup():IsExists(c211.thunderfilter,1,nil) and e:GetHandler():GetOverlayGroup():IsExists(Card.IsSetCard,1,nil,0x7f))
		 and not e:GetHandler():GetOverlayGroup():IsExists(c211.zexalfilter,1,nil) then
	  return e:GetHandler():GetRank()*1000 end
	  if (e:GetHandler():GetOverlayGroup():IsExists(c211.thunderfilter,1,nil) and e:GetHandler():GetOverlayGroup():IsExists(Card.IsSetCard,1,nil,0x7f))
		 and e:GetHandler():GetOverlayGroup():IsExists(c211.zexalfilter,1,nil) then
	  local a=e:GetHandler():GetOverlayGroup():GetSum(Card.GetRank)*500
	  local b=e:GetHandler():GetRank()*1000
	  if a>=b then return a
	  else return b end end
end
function c211.sno39negop1(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local d=Duel.GetAttackTarget()
	if d and d:IsFaceup() and d:IsRelateToBattle() then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		d:RegisterEffect(e1)
		local e2=Effect.CreateEffect(e:GetHandler())
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE_EFFECT)
		e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		d:RegisterEffect(e2)
	end
end
function c211.sno39negop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local a=Duel.GetAttacker()
	if a and a:IsFaceup() and a:IsRelateToBattle() then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		a:RegisterEffect(e1)
		local e2=Effect.CreateEffect(e:GetHandler())
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE_EFFECT)
		e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		a:RegisterEffect(e2)
	end
end
