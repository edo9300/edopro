--極星將テュール
function c197.initial_effect(c)
	--self destroy
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCode(EFFECT_SELF_DESTROY)
	e1:SetCondition(c197.descon)
	c:RegisterEffect(e1)
	--effect target
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_IGNITION)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCost(c197.cost)
	e2:SetTarget(c197.tg)
	e2:SetOperation(c197.op)
	e2:SetValue(1)
	c:RegisterEffect(e2)
end
function c197.filter(c)
	return c:IsFaceup() and c:IsRace(0x200000)
end
function c197.descon(e)
	return not Duel.IsExistingMatchingCard(c197.filter,e:GetHandler():GetControler(),LOCATION_MZONE,0,1,nil)
end

function c197.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsReleasable() end
	Duel.Release(e:GetHandler(),REASON_COST)
end
function c197.tg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c197.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil) end
	Duel.SetOperationInfo(0,CATEGORY_REMOVE,e:GetHandler(),1,0,0)
end
function c197.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
      local e1=Effect.CreateEffect(c)
      e1:SetType(EFFECT_TYPE_FIELD)
      e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
      e1:SetCode(EFFECT_CANNOT_DISABLE)
      e1:SetRange(LOCATION_GRAVE+LOCATION_REMOVED+LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD)
      e1:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
      e1:SetReset(RESET_PHASE+PHASE_END)
	e1:SetTarget(c197.tg2)
	c:RegisterEffect(e1)
      local e2=e1:Clone()
      e2:SetCode(EFFECT_CANNOT_DISEFFECT)
	c:RegisterEffect(e2)
end
function c197.tg2(e,tp,eg,ep,ev,re,r,rp,chk)
	return Duel.GetMatchingGroup(c197.filter,tp,LOCATION_MZONE,LOCATION_MZONE,nil)
end
