--霸王眷龙 凶饿毒
function c720.initial_effect(c)
	--fusion
	c:EnableReviveLimit()
	aux.AddFusionProcFunRep(c,aux.FilterBoolFunction(Card.IsFusionAttribute,ATTRIBUTE_DARK),2,true) 
	
	--spsummon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(20170129,0))
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_DELAY)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_TOGRAVE)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetRange(LOCATION_EXTRA)
	e1:SetCondition(c720.condition)
	e1:SetTarget(c720.target)
	e1:SetOperation(c720.activate)
	
	--copy
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(20170129,1))
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetCode(EVENT_FREE_CHAIN)
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCountLimit(1)
	e2:SetCondition(c720.copycon)
	e2:SetTarget(c720.copytg)
	e2:SetOperation(c720.copyop)
	c:RegisterEffect(e2)
	
	--cannot be target
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CANNOT_SELECT_BATTLE_TARGET)
	e3:SetRange(LOCATION_MZONE)
	e3:SetTargetRange(0,LOCATION_MZONE)
	e3:SetValue(c720.atlimit)
	c:RegisterEffect(e3)
	
	--return extra
	local e4=Effect.CreateEffect(c)
	e4:SetDescription(aux.Stringid(20170129,3))
	e4:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_ATKCHANGE)  
	e4:SetType(EFFECT_TYPE_QUICK_O)
	e4:SetCode(EVENT_FREE_CHAIN)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCost(c720.cost)
	e4:SetTarget(c720.tg)
	e4:SetOperation(c720.op)
	c:RegisterEffect(e4)	
	
	--pierce
	local e5=Effect.CreateEffect(c)
	e5:SetType(EFFECT_TYPE_FIELD)
	e5:SetCode(EFFECT_PIERCE)
	e5:SetTargetRange(LOCATION_MZONE,0)
	e5:SetRange(LOCATION_MZONE)
	c:RegisterEffect(e5)
end

--COPY
function c720.copycon(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetTurnPlayer()==tp and ((Duel.GetCurrentPhase()>=PHASE_BATTLE_START and Duel.GetCurrentPhase()<=PHASE_BATTLE) or Duel.GetCurrentPhase()==PHASE_MAIN1 or Duel.GetCurrentPhase()==PHASE_MAIN2) 
	--and Duel.GetCurrentChain()==0
end
function c720.copyfilter(c)
	return c:IsFaceup() and not c:IsDisabled() and c:IsType(TYPE_MONSTER)
end
function c720.copytg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE+LOCATION_GRAVE) and c720.copyfilter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c720.copyfilter,tp,LOCATION_MZONE+LOCATION_GRAVE,LOCATION_MZONE+LOCATION_GRAVE,1,e:GetHandler()) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	Duel.SelectTarget(tp,c720.copyfilter,tp,LOCATION_MZONE+LOCATION_GRAVE,LOCATION_MZONE+LOCATION_GRAVE,1,1,e:GetHandler())
end
function c720.copyop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
	if g:GetCount()<1 then return end
	local tc=g:GetFirst()
	while tc do
	if tc and c:IsRelateToEffect(e) and tc:IsRelateToEffect(e) and tc:IsFaceup() then
		local code=tc:GetOriginalCode()
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e1)
		local e2=e1:Clone()
		e2:SetCode(EFFECT_DISABLE_EFFECT)	 
		tc:RegisterEffect(e2)
		c:CopyEffect(code,RESET_PHASE+PHASE_END)
		tc=g:GetNext() 
	end
	end
end 
---------------------
--Sp Summon
function c720.filter(c,tp)
	return c:IsType(TYPE_FUSION) and c:IsControler(tp) and bit.band(c:GetSummonType(),SUMMON_TYPE_FUSION)~=0
end
function c720.filter2(c)
	return c:IsFaceup() and c:IsCode(703)
end
function c720.filter5(c,fc,loopchk)
	local tp=c:GetControler()
	if loopchk and loopchk==0 and Duel.GetLocationCountFromEx(tp,tp,c,fc)<1 then return false end
	return c:IsFaceup() and c:IsSetCard(0x20f8) and c:IsReleasableByEffect()
	and Duel.IsExistingMatchingCard(c720.filter5,tp,LOCATION_MZONE,0,1,c,fc) 
end
function c720.condition(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()  
	if c:IsType(TYPE_PENDULUM) and c:IsFaceup() then return false end
	return eg:IsExists(c720.filter,1,nil,1-tp) and not c:IsStatus(STATUS_CHAINING)
	and Duel.IsExistingMatchingCard(c720.filter2,tp,LOCATION_MZONE,0,1,nil)
end
function c720.target(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()  
	local ft=Duel.GetLocationCount(c:GetControler(),LOCATION_MZONE)
	local ct=-ft
	if chk==0 then return Duel.IsExistingMatchingCard(c720.filter5,tp,LOCATION_MZONE,0,1,nil,c,0)  
		and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_FUSION,tp,false,false) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,c,1,0,LOCATION_EXTRA)
	Duel.SetOperationInfo(0,CATEGORY_TOGRAVE,nil,2,0,LOCATION_MZONE)
end
function c720.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()  
	if c:IsRelateToEffect(e) then
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RELEASE)
	local g=Duel.SelectMatchingCard(tp,c720.filter5,tp,LOCATION_MZONE,0,1,1,nil,c,0)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RELEASE)
	local g2=Duel.SelectMatchingCard(tp,c720.filter5,tp,LOCATION_MZONE,0,1,1,g:GetFirst(),c)
	g:Merge(g2)
	if g:GetCount()<2 then return end
	Duel.Release(g,REASON_EFFECT)   
	Duel.SpecialSummon(c,SUMMON_TYPE_FUSION,tp,tp,false,false,POS_FACEUP)
	end
end
---------------------
--RETURN TO EXTRA
function c720.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsAbleToExtraAsCost() end
	Duel.SendtoDeck(e:GetHandler(),nil,2,REASON_COST)
end
function c720.filter3(c,e,tp)
	return c:IsSetCard(0x20f8) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and c:IsType(TYPE_PENDULUM)
end
function c720.tg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()  
	if chk==0 then return Duel.IsExistingMatchingCard(c720.filter3,tp,LOCATION_EXTRA,0,2,nil,e,tp) 
		and not Duel.IsPlayerAffectedByEffect(tp,59822133) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,2,0,LOCATION_EXTRA)
end
function c720.fusion(c)
	return c:IsFaceup() and c:IsType(TYPE_FUSION) 
end
function c720.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not Duel.IsExistingMatchingCard(c720.filter3,tp,LOCATION_EXTRA,0,2,nil,e,tp) then return end
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then return end   
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(tp,c720.filter3,tp,LOCATION_EXTRA,0,2,2,nil,e,tp)
	Duel.SpecialSummon(g,0,tp,tp,false,false,POS_FACEUP)		
	local tg=Duel.GetMatchingGroup(c720.fusion,tp,0,LOCATION_MZONE,nil)
	local tc=tg:GetFirst()
	while tc do
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_SET_ATTACK_FINAL)
		e1:SetValue(0)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
		tc=tg:GetNext()
	end
end
-----------------
--attack target
function c720.atlimit(e,c)
	return c:IsFaceup() and c:IsType(TYPE_FUSION) and c~=e:GetHandler()
end