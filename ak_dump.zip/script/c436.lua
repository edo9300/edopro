--垃圾劍士 (K)
function c436.initial_effect(c)
	local e4=Effect.CreateEffect(c)
	e4:SetType(EFFECT_TYPE_SINGLE)
	e4:SetCode(EFFECT_UPDATE_ATTACK)
	e4:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e4:SetRange(LOCATION_MZONE)
	e4:SetValue(c436.adval)
	c:RegisterEffect(e4)	
end

function c436.setfilter(c) 
      return c:IsSetCard(0x43) and c:IsFaceup()
end
function c436.adval(e,c)
      local g=Duel.GetMatchingGroup(c436.setfilter,tp,LOCATION_GRAVE,0,nil)
      if g:GetCount()>0 then
	return 400 end
end