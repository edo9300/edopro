--Rescuer from the Grave
function c118.initial_effect(c)
      --negate attack and end battle phase
      local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_ATTACK_ANNOUNCE)
	e1:SetRange(LOCATION_GRAVE)
      e1:SetCondition(c118.con)
      e1:SetCost(c118.cost)
      e1:SetOperation(c118.op)
      c:RegisterEffect(e1)
end
c118[0]=true
c118[1]=true

function c118.con(e,tp,eg,ep,ev,re,r,rp)
	  return tp~=Duel.GetTurnPlayer() and Duel.IsExistingMatchingCard(c118.filter,tp,LOCATION_GRAVE,0,5,nil)
            and c118[tp]==true 
end
function c118.filter(c)
        return c:IsAbleToRemoveAsCost()
end
function c118.cost(e,tp,eg,ep,ev,re,r,rp,chk)
        if chk==0 then return Duel.IsExistingMatchingCard(c118.filter,tp,LOCATION_GRAVE,0,5,nil) end
        Duel.Hint(HINT_SELECTMSG,HINTMSG_REMOVE)
        local g=Duel.SelectMatchingCard(tp,c118.filter,tp,LOCATION_GRAVE,0,5,5,nil)
        Duel.Remove(g,POS_FACEUP,REASON_COST)
        c118[tp]=false
end
function c118.op(e,tp,eg,ep,ev,re,r,rp)
        local sk=Duel.GetTurnPlayer()
        Duel.BreakEffect()
	Duel.SkipPhase(sk,PHASE_BATTLE,RESET_PHASE+PHASE_BATTLE,1)
end

