--地縛囚人 掃石者 (K)
function c632.initial_effect(c)
	--special summon
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_SPSUMMON_PROC)
	e1:SetProperty(EFFECT_FLAG_UNCOPYABLE)
	e1:SetRange(LOCATION_HAND)
	e1:SetCondition(c632.spcon)
	c:RegisterEffect(e1)	
end


function c632.spcon(e,c)
	if c==nil then return true end
	local oppfield=Duel.GetFieldCard(0,LOCATION_SZONE,5)
	local myfield=Duel.GetFieldCard(1,LOCATION_SZONE,5)
	return myfield~=nil or oppfield~=nil
end