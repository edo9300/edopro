--ルーンアイズ・ペンデュラム・ドラゴン
function c37.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	Fusion.AddProcFun2(c,aux.FilterBoolFunction(Card.IsFusionSetCard,0x10f2),aux.FilterBoolFunction(Card.IsRace,RACE_SPELLCASTER),false)
	--multi attack
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetCondition(c37.condition)
	e1:SetOperation(c37.operation)
	c:RegisterEffect(e1)

	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_MATERIAL_CHECK)
	e2:SetValue(c37.valcheck)
	e2:SetLabelObject(e1)
	c:RegisterEffect(e2)
end

function c37.ffilter(c)
	return c:IsSetCard(0x10f2)
end

function c37.condition(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetSummonType()==SUMMON_TYPE_FUSION
end
function c37.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local flag=e:GetLabel()
	if flag~=0 then
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_EXTRA_ATTACK_MONSTER)
		e1:SetProperty(EFFECT_FLAG_CLIENT_HINT)
		if flag==1 then
			e1:SetDescription(aux.Stringid(1516510,0))
			e1:SetValue(1)
		elseif flag==2 then
			e1:SetDescription(aux.Stringid(1516510,1))
			e1:SetValue(2)
		elseif flag==3 then
			e1:SetDescription(aux.Stringid(60992364,2))
			e1:SetValue(4)
		end
		e1:SetReset(RESET_EVENT+0x1fe0000)
		c:RegisterEffect(e1)
	end
	if flag==4 then
		local e4=Effect.CreateEffect(c)
		e4:SetType(EFFECT_TYPE_SINGLE)
		e4:SetCode(EFFECT_IMMUNE_EFFECT)
		e4:SetValue(c37.efilter)
		e4:SetOwnerPlayer(tp)
		e4:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		c:RegisterEffect(e4)
	end
end
function c37.dircon(e)
	return e:GetHandler():GetAttackAnnouncedCount()>0
end
function c37.atkcon(e)
	return e:GetHandler():IsDirectAttacked()
end
function c37.efilter(e,re)
	return e:GetOwnerPlayer()~=re:GetOwnerPlayer()
end

function c37.lvfilter(c)
	return c:IsSetCard(0x10f2) or c:IsHasEffect(EFFECT_FUSION_SUBSTITUTE)
end
function c37.imfilter(c)
	return c:IsLocation(LOCATION_MZONE) and c:GetSummonType()==SUMMON_TYPE_PENDULUM
end
function c37.valcheck(e,c)
	local g=c:GetMaterial()
	local flag=0
	if g:GetCount()>0 then
		local lv=0
		local lg2=g:Filter(Card.IsRace,nil,RACE_SPELLCASTER)
			lv=lg2:GetFirst():GetOriginalLevel()
		if lg2:GetCount()>1 then
			lv=lg2:GetSum(Card.GetOriginalLevel()) end
		if lv>6 then
			flag=3
		elseif lv>4 then
			flag=2
		elseif lv>0 then
			flag=1
		end
	end
	if g:IsExists(c37.imfilter,1,nil) then
		flag=4
	end
	e:GetLabelObject():SetLabel(flag)
end
