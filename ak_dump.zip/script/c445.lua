--超越同步 (K)
function c445.initial_effect(c)
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetTarget(c445.target)
	e1:SetOperation(c445.operation)
	c:RegisterEffect(e1)
end

function c445.filter(c,e,tp)
	return c:GetControler()==1-tp and c:GetSummonType()==SUMMON_TYPE_SYNCHRO
      and Duel.IsExistingMatchingCard(c445.spfilter,tp,LOCATION_EXTRA,0,1,nil,e,tp,c)
end
function c445.spfilter(c,e,tp,tc)
	return c:IsType(TYPE_SYNCHRO) and c:GetLevel()==tc:GetLevel()+1
		and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_SYNCHRO,tp,false,false)
end
function c445.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and eg:IsExists(c445.filter,1,nil,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
end
function c445.operation(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0 then return end
      local tc=eg:Filter(c445.filter,nil,e,tp):GetFirst()
      if tc==nil then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local sg=Duel.SelectMatchingCard(tp,c445.spfilter,tp,LOCATION_EXTRA,0,1,1,nil,e,tp,tc)
	if sg:GetCount()>0 then
		Duel.SpecialSummon(sg,SUMMON_TYPE_SYNCHRO,tp,tp,false,false,POS_FACEUP)
	end
end
