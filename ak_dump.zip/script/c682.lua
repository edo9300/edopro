--地縛戒隸 地妖 (K)
function c682.initial_effect(c)
	 --fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcFun2(c,aux.FilterBoolFunction(c682.spfilter1),aux.FilterBoolFunction(c682.spfilter2),false)

	local e5=Effect.CreateEffect(c)
	e5:SetCategory(CATEGORY_ATKCHANGE)
	e5:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_F)
	e5:SetCode(EVENT_ATTACK_ANNOUNCE)
	e5:SetCondition(c682.descon)
	e5:SetOperation(c682.negop1)
	c:RegisterEffect(e5)
	local e6=Effect.CreateEffect(c)
	e6:SetCategory(CATEGORY_ATKCHANGE)
	e6:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_F)
	e6:SetCode(EVENT_BE_BATTLE_TARGET)
	e6:SetCondition(c682.descon2)
	e6:SetOperation(c682.negop2)
	c:RegisterEffect(e6)
end

function c682.spfilter1(c)
	return c:IsFusionSetCard(0x151a) and c:IsType(TYPE_FUSION)
end
function c682.spfilter2(c)
	return c:IsFusionSetCard(0x151a) and c:IsType(TYPE_SYNCHRO)
end

function c682.descon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local d=Duel.GetAttackTarget()
	local myfield=Duel.GetFieldCard(tp,LOCATION_SZONE,5)
	local oppfield=Duel.GetFieldCard(1-tp,LOCATION_SZONE,5)
	return ((myfield~=nil and myfield:IsFaceup())
	or (oppfield~=nil and oppfield:IsFaceup()))
	and d~=nil and d:IsFaceup() and (d:IsType(TYPE_FUSION) or d:IsType(TYPE_SYNCHRO))
end
function c682.negop1(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local d=Duel.GetAttackTarget()
	if d~=nil then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_SET_ATTACK_FINAL)
		e1:SetValue(0)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		d:RegisterEffect(e1)
	end
end

function c682.descon2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local d=Duel.GetAttacker()
	local myfield=Duel.GetFieldCard(tp,LOCATION_SZONE,5)
	local oppfield=Duel.GetFieldCard(1-tp,LOCATION_SZONE,5)
	return ((myfield~=nil and myfield:IsFaceup())
	or (oppfield~=nil and oppfield:IsFaceup()))
	and d~=nil and d:IsFaceup() and (d:IsType(TYPE_FUSION) or d:IsType(TYPE_SYNCHRO))
end
function c682.negop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local a=Duel.GetAttacker()
	if a~=nil then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_SET_ATTACK_FINAL)
		e1:SetValue(0)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		a:RegisterEffect(e1)
	end
end