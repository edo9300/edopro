--Scripted by Eerie Code
--Raidraptor - Satellite Cannon Falcon
function c497.initial_effect(c)
	--xyz summon
	Xyz.AddProcedure(c,aux.FilterBoolFunction(Card.IsRace,RACE_WINDBEAST),8,2)
	c:EnableReviveLimit()

	--destroy
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(1781310,1))
	e2:SetCategory(CATEGORY_DESTROY)
	e2:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e2:SetCode(EVENT_SPSUMMON_SUCCESS)
	e2:SetProperty(EFFECT_FLAG_DELAY)
	e2:SetCondition(c497.descon)
	e2:SetTarget(c497.destg)
	e2:SetOperation(c497.desop)
	c:RegisterEffect(e2)
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_SINGLE)
	e3:SetCode(EFFECT_MATERIAL_CHECK)
	e3:SetValue(c497.valcheck)
	e3:SetLabelObject(e2)
	c:RegisterEffect(e3)

	--Reduce ATK
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(32995007,0))
	--e1:SetProperty(0)   
	e1:SetCategory(CATEGORY_ATKCHANGE)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCost(c497.atkcost)
	e1:SetTarget(c497.atktg)
	e1:SetOperation(c497.atkop)
	e1:SetCountLimit(1)
	c:RegisterEffect(e1,false,1)
end

function c497.descon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetSummonType()==SUMMON_TYPE_XYZ and e:GetLabel()==1
end
function c497.destg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetChainLimit(c497.chlimit)
	local g=Duel.GetMatchingGroup(aux.TRUE,tp,0,LOCATION_SZONE,nil)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,g:GetCount(),0,0)
end
function c497.chlimit(e,ep,tp)
	return tp==ep
end
function c497.desop(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetMatchingGroup(aux.TRUE,tp,0,LOCATION_SZONE,nil)
	local ct=Duel.Destroy(g,REASON_EFFECT)
end
function c497.valcheck(e,c)
	local g=c:GetMaterial()
	if g:IsExists(Card.IsSetCard,1,nil,0xba) then
		e:GetLabelObject():SetLabel(1)
	else
		e:GetLabelObject():SetLabel(0)
	end
end

function c497.atkcost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():CheckRemoveOverlayCard(tp,1,REASON_COST) end
	e:GetHandler():RemoveOverlayCard(tp,1,1,REASON_COST)
end
function c497.atkfil(c)
	return c:IsType(TYPE_MONSTER) and c:IsSetCard(0xba)
end
function c497.atktg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(aux.nzatk,tp,0,LOCATION_MZONE,1,nil) and Duel.IsExistingMatchingCard(c497.atkfil,tp,LOCATION_GRAVE,0,1,nil) end
	local gc=Duel.GetMatchingGroupCount(c497.atkfil,tp,LOCATION_GRAVE,0,nil)
	  e:SetLabel(gc)
	Duel.SetOperationInfo(0,CATEGORY_ATKCHANGE,nil,1,0,800)
end
function c497.atkop(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.SelectMatchingCard(tp,aux.nzatk,tp,0,LOCATION_MZONE,1,1,nil)
	local gc=Duel.GetMatchingGroupCount(c497.atkfil,tp,LOCATION_GRAVE,0,nil)
	if g:GetCount()>0 then
		   local tc=g:GetFirst()
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(-800)
		e1:SetReset(RESET_EVENT+0x1ff0000)
		tc:RegisterEffect(e1)
	  Duel.BreakEffect() 
	  e:SetLabel(e:GetLabel()-1)
	  if e:GetLabel()>0 and Duel.IsExistingMatchingCard(aux.nzatk,tp,0,LOCATION_MZONE,1,nil) and Duel.SelectYesNo(tp,aux.Stringid(32995007,0))==true then
	local operation=e:GetOperation()
	  if operation then operation(e,tp,eg,ep,ev,re,r,rp) end end end	  
end
