--ダブルフィン・シャーク
function c268.initial_effect(c)
	--xyz
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(511001225)
	e2:SetOperation(c268.tgval)
	e2:SetValue(1)
	c:RegisterEffect(e2,false,4)
end

function c268.tgval(e,c)
	return c:IsAttribute(ATTRIBUTE_WATER)
end
