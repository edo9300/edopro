--
function c717.initial_effect(c)
	--pendulum summon
	Pendulum.AddProcedure(c)
	
	--spsummon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(80208158,0))
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_DELAY)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetRange(LOCATION_EXTRA+LOCATION_HAND+LOCATION_DECK)
	e1:SetCondition(c717.condition)
	e1:SetTarget(c717.target)
	e1:SetOperation(c717.activate)
	c:RegisterEffect(e1)

  --double
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e2:SetCode(EVENT_PRE_BATTLE_DAMAGE)
	e2:SetRange(LOCATION_MZONE) 
	e2:SetCondition(c717.damcon)
	e2:SetOperation(c717.damop)
	c:RegisterEffect(e2)

	--cannot be target
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CANNOT_SELECT_BATTLE_TARGET)
	e3:SetRange(LOCATION_MZONE)
	e3:SetTargetRange(0,LOCATION_MZONE)
	e3:SetValue(c717.atlimit)
	c:RegisterEffect(e3)	
	
	local e6=Effect.CreateEffect(c)
	e6:SetType(EFFECT_TYPE_FIELD)
	e6:SetRange(LOCATION_MZONE)
	e6:SetTargetRange(LOCATION_ONFIELD,LOCATION_ONFIELD)	
	e6:SetCode(EFFECT_INDESTRUCTABLE_COUNT)
	e6:SetTarget(c717.atlimit2)
	e6:SetValue(c717.indct)
	c:RegisterEffect(e6)		
	
	local e4=Effect.CreateEffect(c)
	e4:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_ATKCHANGE)  
	e4:SetType(EFFECT_TYPE_QUICK_O)
	e4:SetCode(EVENT_FREE_CHAIN)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCost(c717.cost)
	e4:SetTarget(c717.tg)
	e4:SetOperation(c717.op)
	c:RegisterEffect(e4)

	local e8=Effect.CreateEffect(c)
	e8:SetType(EFFECT_TYPE_IGNITION)
	e8:SetRange(LOCATION_PZONE)
	e8:SetCost(c717.cost2)
	e8:SetTarget(c717.tg2)
	e8:SetOperation(c717.op2)
	c:RegisterEffect(e8)	
end

--Sp Summon
function c717.filter(c,tp)
	return c:IsType(TYPE_PENDULUM) and c:IsControler(tp) and c:GetSummonType()==SUMMON_TYPE_PENDULUM	
end
function c717.filter2(c)
	return c:IsFaceup() and c:IsCode(703)
end
function c717.filter5(c)
	return c:IsFaceup() and c:IsSetCard(0x20f8) and c:IsReleasableByEffect()
end
function c717.condition(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()  
	if c:IsLocation(LOCATION_EXTRA) and c:IsFacedown() then return false end
	return eg:IsExists(c717.filter,1,nil,1-tp) and not c:IsStatus(STATUS_CHAINING)
	and Duel.IsExistingMatchingCard(c717.filter2,tp,LOCATION_MZONE,0,1,nil)
end
function c717.target(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()  
	local ft=Duel.GetLocationCount(c:GetControler(),LOCATION_MZONE)
	local ct=-ft
	if chk==0 then return ct<2 and Duel.IsExistingMatchingCard(c717.filter5,tp,LOCATION_MZONE,0,2,nil)  
		and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_PENDULUM,tp,false,false) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RELEASE)
	local g=Duel.SelectMatchingCard(tp,c717.filter5,tp,LOCATION_MZONE,0,2,2,nil)
	if g:GetCount()<2 then return end
	Duel.Release(g,REASON_EFFECT)	  
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,c,1,0,LOCATION_EXTRA)
end
function c717.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()  
	if c:IsRelateToEffect(e) then
		Duel.SpecialSummon(c,SUMMON_TYPE_PENDULUM,tp,tp,false,false,POS_FACEUP)
	end
end

function c717.damcon(e,tp,eg,ep,ev,re,r,rp)
	local atker=Duel.GetAttacker()
	local atked=Duel.GetAttackTarget()  
	if atked and atked:IsControler(tp) then 
	local a=atker
	atker=atked atked=a end
	return ep~=tp and atker:IsType(TYPE_PENDULUM)
end
function c717.damop(e,tp,eg,ep,ev,re,r,rp)
	Duel.ChangeBattleDamage(ep,ev*2)
end

function c717.atlimit(e,c)
	return c:IsFaceup() and c:IsType(TYPE_PENDULUM) and c~=e:GetHandler()
end

function c717.atlimit2(e,c)
	return c:IsFaceup() and c:IsType(TYPE_PENDULUM)
end
function c717.indct(e,re,r,rp)
	if bit.band(r,REASON_BATTLE+REASON_EFFECT)~=0 then
	return 1
	else return 0 end
end

function c717.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsAbleToDeckOrExtraAsCost() end
	Duel.SendtoExtraP(e:GetHandler(),tp,REASON_COST)
end
function c717.filter3(c,e,tp)
	return c:IsSetCard(0x20f8) and c~=e:GetHandler() and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and c:IsType(TYPE_PENDULUM)
end
function c717.tg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()  
	if chk==0 then return Duel.IsExistingMatchingCard(c717.filter3,tp,LOCATION_EXTRA,0,2,nil,e,tp) 
	    and not Duel.IsPlayerAffectedByEffect(tp,59822133) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,2,0,LOCATION_EXTRA)
end
function c717.xyz(c)
	return c:IsFaceup() 
end
function c717.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not Duel.IsExistingMatchingCard(c717.filter3,tp,LOCATION_EXTRA,0,2,nil,e,tp) then return end
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then return end	
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(tp,c717.filter3,tp,LOCATION_EXTRA,0,2,2,nil,e,tp)
	Duel.SpecialSummon(g,0,tp,tp,false,false,POS_FACEUP)		
	local tg=Duel.GetMatchingGroup(c717.xyz,tp,0,LOCATION_MZONE,nil)
	local tc=tg:GetFirst()
	while tc do
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_SET_ATTACK_FINAL)
		e1:SetValue(0)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
		tc=tg:GetNext()
	end
end

function c717.cost2(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c717.filter30,tp,LOCATION_MZONE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RELEASE)
	local g=Duel.SelectMatchingCard(tp,c717.filter30,tp,LOCATION_MZONE,0,1,1,nil)
	if g:GetCount()<1 then return end
	Duel.Release(g,REASON_COST) 
	Duel.SendtoExtraP(e:GetHandler(),tp,REASON_COST)
end
function c717.filter30(c)
	return c:IsFaceup() and c:IsSetCard(0xf8) and c:IsReleasable()
end
function c717.tg2(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()  
	if chk==0 then return e:GetHandler():IsAbleToExtra() end
end
function c717.op2(e,tp,eg,ep,ev,re,r,rp)
	Duel.SendtoExtraP(e:GetHandler(),tp,REASON_EFFECT)
end