--Kuribabylon
function c183.initial_effect(c)
	--aux.AddFusionProcCode3(c,40640057,57116033,2830693,false,false)

	--Activate
	local e1=Effect.CreateEffect(c)
	  e1:SetDescription(aux.Stringid(13715,10))
	  e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	  e1:SetCode(EVENT_FREE_CHAIN)
	  e1:SetRange(LOCATION_MZONE)
	  e1:SetCountLimit(1)
	e1:SetCost(c183.cost)
	e1:SetTarget(c183.target)
	e1:SetOperation(c183.activate)
	c:RegisterEffect(e1)

	--cannot special summon
	local e2=Effect.CreateEffect(c)
	e2:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_SPSUMMON_CONDITION)
	e2:SetValue(aux.FALSE)
	c:RegisterEffect(e2)

	  local e3=Effect.CreateEffect(c)
	  e3:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE) 
	  e3:SetType(EFFECT_TYPE_SINGLE)
	  e3:SetCode(EFFECT_SET_ATTACK)
	  e3:SetValue(c183.atkvalue)
	  c:RegisterEffect(e3)

	 --special summon
	 local e4=Effect.CreateEffect(c)
	 e4:SetType(EFFECT_TYPE_FIELD)
	 e4:SetCode(EFFECT_SPSUMMON_PROC)
	 e4:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	 e4:SetRange(LOCATION_EXTRA)
	 e4:SetCondition(c183.spcon)
	 e4:SetOperation(c183.spop)
	 e4:SetValue(SUMMON_TYPE_FUSION)
	 c:RegisterEffect(e4)

	 local e5=Effect.CreateEffect(c)
	 e5:SetDescription(aux.Stringid(13715,11))
	 e5:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	 e5:SetCategory(CATEGORY_EQUIP)
	 e5:SetType(EFFECT_TYPE_IGNITION)
	 e5:SetRange(LOCATION_MZONE)
	 e5:SetTarget(c183.target2)
	 e5:SetOperation(c183.activate2)
	 c:RegisterEffect(e5)
end

function c183.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsAbleToExtraAsCost() end
	  Duel.SendtoDeck(e:GetHandler(),nil,2,REASON_COST+REASON_EFFECT)
end
function c183.spfilter(c,code,e,tp)
	return c:IsCode(code) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
end
function c183.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>=3
			and Duel.IsExistingMatchingCard(c183.spfilter,tp,LOCATION_GRAVE,0,1,nil,40640057,e,tp)
			and Duel.IsExistingMatchingCard(c183.spfilter,tp,LOCATION_GRAVE,0,1,nil,57116033,e,tp)
			and Duel.IsExistingMatchingCard(c183.spfilter,tp,LOCATION_GRAVE,0,1,nil,2830693,e,tp) 
			and Duel.IsExistingMatchingCard(c183.spfilter,tp,LOCATION_GRAVE,0,1,nil,413,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,4,tp,LOCATION_GRAVE)
end
function c183.activate(e,tp,eg,ep,ev,re,r,rp)
	  if Duel.GetLocationCount(tp,LOCATION_MZONE)<=2 then return end
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g1=Duel.SelectMatchingCard(tp,c183.spfilter,tp,LOCATION_GRAVE,0,1,1,nil,40640057,e,tp)
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g2=Duel.SelectMatchingCard(tp,c183.spfilter,tp,LOCATION_GRAVE,0,1,1,nil,57116033,e,tp)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g5=Duel.SelectMatchingCard(tp,c183.spfilter,tp,LOCATION_GRAVE,0,1,1,nil,413,e,tp)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g3=Duel.SelectMatchingCard(tp,c183.spfilter,tp,LOCATION_GRAVE,0,1,1,nil,2830693,e,tp)
	  g1:Merge(g2)
	  g1:Merge(g3)
	  g1:Merge(g5)
	  local tc=g1:GetFirst()
	  while tc do
		  Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP)
		  tc=g1:GetNext()
	  end
	  Duel.SpecialSummonComplete()
end

function c183.atkvalue(e)
	  local g=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,40640057)
	  local g1=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,57116033)
	  local g2=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,2830693)
	  local g3=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,183)
	  local g4=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,170000160)
	  local g5=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,170000161)
	  local g6=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,170000162)
	  local g7=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,170000163)
	  local g8=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,170000164)
	  local g9=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,16404809)
	  local g10=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,33776734)
	  local g11=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,40817915)
	  local g12=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,47432275)
	  local g13=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,98585345)
	  local g14=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,24694698)
	  local g15=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,35112613)
	  local g16=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,413)
	  g:Merge(g1)
	  g:Merge(g2)
	  g:Merge(g3)
	  g:Merge(g4)
	  g:Merge(g5)
	  g:Merge(g6)
	  g:Merge(g7)
	  g:Merge(g8)
	  g:Merge(g9)
	  g:Merge(g10)
	  g:Merge(g11)
	  g:Merge(g12)
	  g:Merge(g13)
	  g:Merge(g14)
	  g:Merge(g15)
	  g:Merge(g16)
	  local tatk=0
	  local tc=g:GetFirst()
	  while tc do
	  local atk=tc:GetAttack()
	  if atk<0 then atk=0 end
	  tatk=tatk+atk
	  tc=g:GetNext() end
	  return tatk	 
end

function c183.afilter(c)
	return c:IsCode(40640057) or c:IsCode(57116033) or c:IsCode(2830693) or c:IsCode(413)
end
function c183.spcon(e,c)
		if c==nil then return true end
		return (Duel.GetLocationCountFromEx(c:GetControler())>0 and Duel.IsExistingMatchingCard(c183.afilter,c:GetControler(),LOCATION_MZONE,0,1,nil)
			   and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_HAND+LOCATION_ONFIELD,0,1,nil,40640057)
				and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_HAND+LOCATION_ONFIELD,0,1,nil,57116033)
				and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_HAND+LOCATION_ONFIELD,0,1,nil,2830693)
				and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_HAND+LOCATION_ONFIELD,0,1,nil,413))
				or (Duel.GetLocationCount(c:GetControler(),LOCATION_MZONE)>0
				and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_HAND+LOCATION_ONFIELD,0,1,nil,40640057)
				and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_HAND+LOCATION_ONFIELD,0,1,nil,57116033)
				and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_HAND+LOCATION_ONFIELD,0,1,nil,2830693)
				and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_HAND+LOCATION_ONFIELD,0,1,nil,413))
end
function c183.spop(e,tp,eg,ep,ev,re,r,rp,c)
		local c=e:GetHandler()
		local tg1=Group.CreateGroup()
		local tg2=Group.CreateGroup()
		local tg3=Group.CreateGroup()
		local tg4=Group.CreateGroup()
		if Duel.GetLocationCountFromEx(tp)>0 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg1=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,40640057)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg2=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,57116033)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg4=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,413) 
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,2830693) 

		elseif Duel.GetLocationCount(c:GetControler(),LOCATION_MZONE)<=0 then
		if Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,40640057) 
		and not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,57116033)
		and not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,2830693) 
		and not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,413) then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg1=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_MZONE,0,1,1,nil,40640057)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg2=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,57116033)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg4=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,413) 
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,2830693) 

		elseif not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,40640057) 
		and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,57116033)
		and not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,2830693)
		and not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,413) then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg1=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,40640057)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg2=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_MZONE,0,1,1,nil,57116033)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg4=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,413) 
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,2830693) 

		elseif not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,40640057) 
		and not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,57116033)
		and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,2830693)
		and not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,413) then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg1=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,40640057)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg2=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,57116033)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg4=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,413)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_MZONE,0,1,1,nil,2830693) 

		elseif not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,40640057) 
		and not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,57116033)
		and not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,2830693)
		and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,413) then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg1=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,40640057)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg2=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,57116033)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg4=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_MZONE,0,1,1,nil,413)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,2830693) 

		--elseif (Duel.IsExistingMatchingCard(c183.afilter,c:GetControler(),LOCATION_MZONE,0,2,nil) 
		--or Duel.IsExistingMatchingCard(c183.afilter,c:GetControler(),LOCATION_MZONE,0,3,nil))
		--and not Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,2830693) then
		--tg1=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,40640057)
		--tg2=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_MZONE,0,1,1,nil,57116033)
		--tg3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,2830693)
	 
		--elseif (Duel.IsExistingMatchingCard(c183.afilter,c:GetControler(),LOCATION_MZONE,0,2,nil) 
		--or Duel.IsExistingMatchingCard(c183.afilter,c:GetControler(),LOCATION_MZONE,0,3,nil))
		--and Duel.IsExistingMatchingCard(Card.IsCode,c:GetControler(),LOCATION_MZONE,0,1,nil,2830693) then
		--tg1=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,40640057)
		--tg2=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,57116033)
		--tg3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_MZONE,0,1,1,nil,2830693)

		else
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg1=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,40640057)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg2=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,57116033)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg4=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,413)
		if not tg1:GetFirst():IsLocation(LOCATION_MZONE) and not tg2:GetFirst():IsLocation(LOCATION_MZONE) and not tg4:GetFirst():IsLocation(LOCATION_MZONE) then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_MZONE,0,1,1,nil,2830693) 
		else
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
		tg3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND+LOCATION_ONFIELD,0,1,1,nil,2830693) end
		end end
   
		tg1:Merge(tg2) tg1:Merge(tg3) tg1:Merge(tg4)
		c:SetMaterial(tg1)
		Duel.SendtoGrave(tg1,REASON_FUSION+REASON_MATERIAL)
		Duel.SendtoGrave(tg2,REASON_FUSION+REASON_MATERIAL)
		Duel.SendtoGrave(tg3,REASON_FUSION+REASON_MATERIAL)
		Duel.SendtoGrave(tg4,REASON_FUSION+REASON_MATERIAL)
end

function c183.filter(c,code)
	return c:IsCode(code) and c:IsFaceup()
end
function c183.target2(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsCode(159) end
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_SZONE)>0 
							and Duel.IsExistingMatchingCard(c183.filter,tp,LOCATION_MZONE,0,1,nil,159) end
	  local g=Duel.SelectTarget(tp,c183.filter,tp,LOCATION_MZONE,0,1,1,nil,159)
	Duel.SetOperationInfo(0,CATEGORY_EQUIP,g,1,tp,LOCATION_MZONE)
end
function c183.activate2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	  local atk=c:GetAttack()
	  if Duel.GetLocationCount(tp,LOCATION_SZONE)<=0 or tc:IsFacedown() then return end
	Duel.Equip(tp,c,tc,true)
	--Add Equip limit
	local e1=Effect.CreateEffect(tc)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_EQUIP_LIMIT)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	e1:SetValue(c183.eqlimit)
	c:RegisterEffect(e1)
	  local e2=e1:Clone()
	  e2:SetCode(EFFECT_UPDATE_ATTACK)
	  e2:SetValue(atk)
	c:RegisterEffect(e2)
	 local e5=Effect.CreateEffect(c)
	 e5:SetDescription(aux.Stringid(57116033,0))
	 e5:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_CANNOT_DISABLE)
	 e5:SetType(EFFECT_TYPE_QUICK_O+EFFECT_TYPE_FIELD)
	 e5:SetCode(EVENT_PRE_BATTLE_DAMAGE)
	 e5:SetRange(LOCATION_SZONE)
	 e5:SetCondition(c183.rmcon)
	 e5:SetCost(c183.rmcost)
	 e5:SetOperation(c183.rmactivate)
	 c:RegisterEffect(e5)
end
function c183.eqlimit(e,c)
	return e:GetOwner()==c
end

function c183.rmcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g1=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_GRAVE,0,nil,40640057)
	  local g2=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_GRAVE,0,nil,57116033)
	  local g3=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_GRAVE,0,nil,2830693)
	  local g4=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_GRAVE,0,nil,413)
	  return g1:GetCount()~=0 and g2:GetCount()~=0 and g3:GetCount()~=0 and g4:GetCount()~=0 and ep==tp
end
function c183.rmcost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_GRAVE,0,1,nil,40640057) 
					 and Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_GRAVE,0,1,nil,57116033) 
					 and Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_GRAVE,0,1,nil,2830693) 
					 and Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_GRAVE,0,1,nil,413)end
	  local g1=Duel.SelectMatchingCard(tp,c183.afilter,tp,LOCATION_GRAVE,0,1,1,nil)
	Duel.Remove(g1,0,REASON_COST+REASON_EFFECT)
end
function c183.rmactivate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	Duel.ChangeBattleDamage(ep,0)
end 
