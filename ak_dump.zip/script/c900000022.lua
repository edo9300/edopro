--斯芬克斯·安德鲁吉尼斯
function c900000022.initial_effect(c)
	c:EnableReviveLimit()
	
	--不能通常召唤
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e1:SetCode(EFFECT_SPSUMMON_CONDITION)
	c:RegisterEffect(e1)
	
	--特殊召唤方式
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(900000022,2))
	e2:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e2:SetRange(LOCATION_DECK+LOCATION_HAND)
	e2:SetCode(EVENT_LEAVE_FIELD)
	e2:SetCondition(c900000022.spcon)
	e2:SetTarget(c900000022.sptg)
	e2:SetOperation(c900000022.spop)
	c:RegisterEffect(e2)
	
	--攻击力为墓地怪兽攻击力之和
	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_ATKCHANGE)
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_F)
	e3:SetCode(EVENT_SPSUMMON_SUCCESS)
	e3:SetTarget(c900000022.atktg)
	e3:SetOperation(c900000022.atkop)
	c:RegisterEffect(e3)
end
-------------------------------------------------------------------------------------------------------------------------------------------
function c900000022.cfilter(c,tp,code)
	return c:IsCode(code) and c:GetPreviousControler()==tp and c:IsReason(REASON_DESTROY)
end

function c900000022.spcon(e,tp,eg,ep,ev,re,r,rp)
	return eg:IsExists(c900000022.cfilter,1,nil,tp,15013468)
		and eg:IsExists(c900000022.cfilter,1,nil,tp,51402177)
end

function c900000022.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and e:GetHandler():IsCanBeSpecialSummoned(e,0,tp,true,false) end
	if e:GetHandler():IsLocation(LOCATION_DECK+LOCATION_HAND) then
		Duel.ConfirmCards(1-tp,e:GetHandler())
	end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,e:GetHandler(),1,0,0)
end

function c900000022.spop(e,tp,eg,ep,ev,re,r,rp)
	if e:GetHandler():IsRelateToEffect(e) then
		Duel.SpecialSummon(e:GetHandler(),0,tp,tp,true,false,POS_FACEUP)
	end
end
-------------------------------------------------------------------------------------------------------------------------------------------
function c900000022.filter(c)
	return c:IsType(TYPE_MONSTER)
end

function c900000022.atktg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c900000022.filter,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,nil) end
end

function c900000022.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if c:IsFaceup() and c:IsRelateToEffect(e) then
		local g=Duel.GetMatchingGroup(c900000022.filter,tp,LOCATION_GRAVE,LOCATION_GRAVE,nil)
		local atk=g:GetSum(Card.GetAttack)
		if atk>0 then
			local e1=Effect.CreateEffect(c)
			e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetCode(EFFECT_SET_ATTACK)
			e1:SetValue(atk)
			c:RegisterEffect(e1)
		end
	end
end
