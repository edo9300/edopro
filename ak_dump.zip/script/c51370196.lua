--DDD 雙曉王 無盡末世神 (K)
function c51370196.initial_effect(c)
	--xyz summon
	Xyz.AddProcedure(c,nil,8,2)
	c:EnableReviveLimit()

	local e4=Effect.CreateEffect(c)
	e4:SetType(EFFECT_TYPE_SINGLE)
	e4:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e4:SetRange(LOCATION_SZONE)
	e4:SetCode(EFFECT_CANNOT_DISABLE)
	e4:SetValue(1)
	c:RegisterEffect(e4)

	--spsummon success
	local e3=Effect.CreateEffect(c)
	e3:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)      
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e3:SetCode(EVENT_SPSUMMON_SUCCESS)
	e3:SetOperation(c51370196.sucop)
	c:RegisterEffect(e3)

	--destroy
	local e2=Effect.CreateEffect(c)
	e2:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e2:SetDescription(aux.Stringid(34945480,0))
	e2:SetCategory(CATEGORY_DESTROY)
	e2:SetType(EFFECT_TYPE_QUICK_O)
      e2:SetCode(EVENT_FREE_CHAIN)
	e2:SetHintTiming(0,TIMING_END_PHASE)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCost(c51370196.cost)
	e2:SetTarget(c51370196.target)
	e2:SetOperation(c51370196.operation)
	c:RegisterEffect(e2,false,1)

	local e5=Effect.CreateEffect(c)
	e5:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e5:SetDescription(aux.Stringid(34945480,0))
	e5:SetType(EFFECT_TYPE_QUICK_O)
      e5:SetCode(EVENT_FREE_CHAIN)
	e5:SetRange(LOCATION_MZONE)
	e5:SetHintTiming(0,TIMING_END_PHASE)
            e5:SetLabelObject(e2)
	e5:SetCost(c51370196.cost)
	e5:SetTarget(c51370196.target2)
	e5:SetOperation(c51370196.operation2)
	c:RegisterEffect(e5,false,1)
end

function c51370196.aclimit(e,re,tp)
	return re:GetHandler():IsOnField() and e:GetHandler()~=re:GetHandler()
end
function c51370196.disable(e,c)
	return c~=e:GetHandler() and (not c:IsType(TYPE_MONSTER) or (c:IsType(TYPE_EFFECT) or bit.band(c:GetOriginalType(),TYPE_EFFECT)==TYPE_EFFECT))
end
function c51370196.sucop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Duel.GetMatchingGroup(Card.IsFaceup,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,nil)
	local g2=Duel.GetMatchingGroup(Card.IsFacedown,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,nil)
	local tc=g:GetFirst()
	local tc2=g2:GetFirst()
	while tc do
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e1)
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE_EFFECT)
		e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e2)
		if tc:IsType(TYPE_TRAPMONSTER) then
			local e3=Effect.CreateEffect(c)
			e3:SetType(EFFECT_TYPE_SINGLE)
			e3:SetCode(EFFECT_DISABLE_TRAPMONSTER)
			e3:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
			tc:RegisterEffect(e3)
		end
		tc=g:GetNext()
	end
	while tc2 do
		local e5=Effect.CreateEffect(c)
		e5:SetType(EFFECT_TYPE_SINGLE)
		e5:SetCode(EFFECT_CANNOT_ACTIVATE)
		e5:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc2:RegisterEffect(e5)
		local e6=Effect.CreateEffect(c)
		e6:SetType(EFFECT_TYPE_SINGLE)
		e6:SetCode6(EFFECT_CANNOT_TRIGGER)
		e6:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e6)
		tc2=g2:GetNext()
             end
end

function c51370196.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():CheckRemoveOverlayCard(tp,1,REASON_COST) end
	e:GetHandler():RemoveOverlayCard(tp,1,1,REASON_COST)
end
function c51370196.desfilter(c)
	return c:IsType(TYPE_SPELL+TYPE_TRAP) and aux.TRUE
end
function c51370196.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c51370196.desfilter,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,1,nil) and not e:GetHandler():IsStatus(STATUS_CHAINING) end
	local g=Duel.GetMatchingGroup(c51370196.desfilter,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,nil)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,g:GetCount(),0,0)
end
function c51370196.operation(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetMatchingGroup(c51370196.desfilter,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,nil)
	Duel.Destroy(g,REASON_EFFECT)
      --local g2=Duel.GetOperatedGroup()
      --if g2:GetCount()==0 then return end
      --local tc=g2:GetFirst()
      --while tc do
      --tc:RegisterFlagEffect(51370196,RESET_EVENT+0x1ff0000,0,1)
      --tc=g2:GetNext() end
end

function c51370196.setfilter(c,te,tp)
	return c:GetReasonEffect()==te and c:GetPreviousControler()==tp
end
function c51370196.target2(e,tp,eg,ep,ev,re,r,rp,chk)
            local te=e:GetLabelObject()
	if chk==0 then return Duel.IsExistingMatchingCard(c51370196.setfilter,tp,LOCATION_GRAVE+LOCATION_REMOVED+LOCATION_DECK+LOCATION_HAND+LOCATION_EXTRA,LOCATION_GRAVE+LOCATION_REMOVED+LOCATION_DECK+LOCATION_HAND+LOCATION_EXTRA,1,nil,te,tp) 
      and not e:GetHandler():IsStatus(STATUS_CHAINING) end
end
function c51370196.operation2(e,tp,eg,ep,ev,re,r,rp)
            local te=e:GetLabelObject()
	local g=Duel.GetMatchingGroup(c51370196.setfilter,tp,LOCATION_GRAVE+LOCATION_REMOVED+LOCATION_DECK+LOCATION_HAND+LOCATION_EXTRA,LOCATION_GRAVE+LOCATION_REMOVED+LOCATION_DECK+LOCATION_HAND+LOCATION_EXTRA,nil,te,tp)
	if g:GetCount()>0 then
            local tc=g:GetFirst()
            while tc do
            if tc:GetPreviousPosition()==POS_FACEUP then
            Duel.MoveToField(tc,tp,tp,LOCATION_SZONE,POS_FACEUP,true)
		else Duel.SSet(tp,tc) end
	      --Trap activate in set turn
	     local e2=Effect.CreateEffect(e:GetHandler())
	     e2:SetType(EFFECT_TYPE_SINGLE)
	     e2:SetCode(EFFECT_TRAP_ACT_IN_SET_TURN)
	     e2:SetProperty(EFFECT_FLAG_SET_AVAILABLE)
	     --e2:SetRange(LOCATION_SZONE)
	     --e2:SetTargetRange(LOCATION_SZONE,0)
	     tc:RegisterEffect(e2)
           tc=g:GetNext() end
	end      
end

