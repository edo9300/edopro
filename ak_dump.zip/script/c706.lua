--アストログラフ・マジシャン
--Astrograph Sorcerer
function c706.initial_effect(c)
	Pendulum.AddProcedure(c)

	--Special Summon
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(76794549,3))
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET) 
	e2:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e2:SetCode(EVENT_DESTROYED)
	e2:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DELAY)
	e2:SetRange(LOCATION_HAND)
	e2:SetCondition(c706.spcon)
	e2:SetTarget(c706.sptg)
	e2:SetOperation(c706.spop)
	c:RegisterEffect(e2) 
	
	--special summon
	local e3=Effect.CreateEffect(c)
	e3:SetDescription(aux.Stringid(76794549,5))
	e3:SetType(EFFECT_TYPE_IGNITION)
	e3:SetRange(LOCATION_MZONE)
	e3:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_REMOVE)
	e3:SetCost(c706.hncost)
	e3:SetTarget(c706.hntg)
	e3:SetOperation(c706.hnop)
	c:RegisterEffect(e3)
end

function c706.spcfilter(c,tp)
	return c:IsReason(REASON_BATTLE+REASON_EFFECT)
		and c:GetPreviousControler()==tp and c:IsPreviousLocation(LOCATION_ONFIELD)
end
function c706.spcfilter2(c,e,tp)
	return c:IsReason(REASON_BATTLE+REASON_EFFECT)
		and c:GetPreviousControler()==tp and c:IsPreviousLocation(LOCATION_ONFIELD)
		and c:IsPreviousPosition(POS_FACEUP) and c:IsCanBeEffectTarget(e)
end
function c706.spcon(e,tp,eg,ep,ev,re,r,rp)
	return eg and eg:IsExists(c706.spcfilter,1,nil,tp)
end
function c706.sptg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local c=e:GetHandler()
	if chkc then return true end	
	if chk==0 then return Duel.GetLocationCountFromEx(tp)>0
		and c:IsCanBeSpecialSummoned(e,0,tp,false,false) 
		and eg:FilterCount(c706.spcfilter2,nil,e,tp)>0 end
	Duel.SetTargetCard(eg:Filter(c706.spcfilter,nil,tp))
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,c,1,0,0)
	local g=eg:Filter(c706.spcfilter2,nil,e,tp)
	if g:GetCount()<1 then return end
	local tc=g:GetFirst()
	while tc do
	tc:RegisterFlagEffect(706,RESET_PHASE+PHASE_END,0,1,c:GetFieldID())
	tc=g:GetNext() end
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_DELAY+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetLabel(c:GetFieldID())
	e1:SetTarget(c706.erastg)
	e1:SetOperation(c706.erasop)
	c:RegisterEffect(e1)
end
function c706.spop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not c:IsRelateToEffect(e) or eg:FilterCount(Card.IsCanBeEffectTarget,nil,e)<1 or Duel.GetLocationCountFromEx(tp)<1 then return end
	Duel.SpecialSummon(c,0,tp,tp,false,false,POS_FACEUP)
end

function c706.erasfilter(c,label)
	return c:GetFlagEffect(706)~=0 and c:GetFlagEffectLabel(706)==label
end
function c706.erastg(e,tp,eg,ep,ev,re,r,rp,chk)
	local g=Duel.GetMatchingGroup(c706.erasfilter,tp,0xff,0xff,nil,e:GetLabel())
	if g:GetCount()<1 then return end
	local ag=g:Filter(Card.IsPreviousLocation,nil,LOCATION_MZONE)
	local bg=g:Filter(Card.IsPreviousLocation,nil,LOCATION_SZONE)
	if chk==0 then return re and re:GetHandler()==e:GetHandler() and (ag:GetCount()>0 and Duel.GetLocationCount(tp,LOCATION_MZONE)>0)
	or (bg:GetCount()>0 and Duel.GetLocationCount(tp,LOCATION_SZONE)>0) end
end
function c706.erasop(e,tp,eg,ep,ev,re,r,rp)
	local sg=Duel.GetMatchingGroup(c706.erasfilter,tp,0xff,0xff,nil,e:GetLabel())
	if sg:GetCount()<1 then return end  
	local tc=sg:GetFirst()
	while tc do
	   Duel.MoveToField(tc,tp,tp,tc:GetPreviousLocation(),tc:GetPreviousPosition(),true)
	   tc:ResetFlagEffect(706)
	   tc=sg:GetNext()
	end
end

function c706.hncfilter(c)
	return c:IsAbleToRemoveAsCost() and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
	and (c:IsCode(16178681) or c:IsCode(16195942) or c:IsCode(82044279) or c:IsCode(41209827)) 
end
function c706.hncost(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return c:IsReleasable() end
	Duel.Release(c,REASON_COST)
end
function c706.hnfilter(c,e,tp)
	return c:IsCode(703) and c:IsCanBeSpecialSummoned(e,0,tp,true,false)
end
function c706.clfilter(c,tp)
	return Duel.GetLocationCountFromEx(tp,tp,c)>0
end
function c706.hntg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	local ft=Duel.GetLocationCountFromEx(tp)
	local g=Duel.GetMatchingGroup(c706.hncfilter,tp,LOCATION_DECK+LOCATION_EXTRA+LOCATION_ONFIELD+LOCATION_GRAVE,0,nil)
	if chk==0 then return Duel.IsExistingMatchingCard(c706.hnfilter,tp,LOCATION_EXTRA,0,1,nil,e,tp) 
		and g:IsExists(Card.IsCode,1,nil,16178681)
		and g:IsExists(Card.IsCode,1,nil,16195942)
		and g:IsExists(Card.IsCode,1,nil,82044279)
		and g:IsExists(Card.IsCode,1,nil,41209827)
		and (ft>0 or g:IsExists(c706.clfilter,1,nil,tp))
	end
	Duel.SetOperationInfo(0,CATEGORY_REMOVE,nil,4,0,0)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
end
function c706.hnop(e,tp,eg,ep,ev,re,r,rp)
   local c=e:GetHandler()
   local g=Duel.GetMatchingGroup(c706.hncfilter,tp,LOCATION_DECK+LOCATION_EXTRA+LOCATION_ONFIELD+LOCATION_GRAVE,0,nil)
   if Duel.GetLocationCountFromEx(tp)<1 and not g:IsExists(c706.clfilter,1,nil,tp) then return end
   local rg=Group.CreateGroup()
   for i=1,4 do
		local tc=nil
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
		if Duel.GetLocationCountFromEx(tp)<1 then
			tc=g:FilterSelect(tp,c706.clfilter,1,1,nil,tp):GetFirst()
		else
			tc=g:Select(tp,1,1,nil):GetFirst()
		end
		if tc then
			rg:AddCard(tc)
			local sc=0
			if tc:IsCode(16178681) then sc=16178681
			elseif tc:IsCode(16195942) then sc=16195942
			elseif tc:IsCode(82044279) then sc=82044279
			else sc=41209827 end
			g:Remove(Card.IsCode,nil,sc)
	   end
   end
   if Duel.Remove(rg,POS_FACEUP,REASON_EFFECT)==4 then
   if Duel.GetLocationCountFromEx(tp)<1 then return end
   Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
   local g=Duel.SelectMatchingCard(tp,c706.hnfilter,tp,LOCATION_EXTRA,0,1,1,nil,e,tp)
   if g:GetCount()>0 then
	   Duel.SpecialSummon(g,0,tp,tp,true,false,POS_FACEUP)
   end end
end