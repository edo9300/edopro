--盔甲代幣 (K)
function c110000118.initial_effect(c)
	local e0=Effect.CreateEffect(c)
	e0:SetType(EFFECT_TYPE_SINGLE)
	e0:SetCode(EFFECT_ADD_TYPE)
	e0:SetValue(0x10000000)
	c:RegisterEffect(e0)
end
