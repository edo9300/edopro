--Cross Draw of Destiny
function c11370071.initial_effect(c)
	local e1=Effect.CreateEffect(c)
      e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_DRAW+CATEGORY_RECOVER)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c11370071.target)
	e1:SetOperation(c11370071.spop)
	c:RegisterEffect(e1)
end

function c11370071.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsPlayerCanDraw(tp,1) and Duel.IsPlayerCanDraw(1-tp,1) end
	Duel.SetOperationInfo(0,CATEGORY_DRAW,nil,0,PLAYER_ALL,1)
end
function c11370071.spop(e,tp,eg,ep,ev,re,r,rp)
	if Duel.Draw(tp,1,REASON_EFFECT)==0 then return end
	local tc=Duel.GetOperatedGroup():GetFirst()
	Duel.ConfirmCards(1-ep,tc2)
	Duel.ShuffleHand(ep)
	Duel.BreakEffect()
	if tc:IsType(TYPE_MONSTER) then
		if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0 then return end
			if Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP) then
			Duel.Recover(tp,tc:GetAttack(),REASON_EFFECT) end
	else
end
	if Duel.Draw(1-tp,1,REASON_EFFECT)==0 then return end
	local tc2=Duel.GetOperatedGroup():GetFirst()
	Duel.ConfirmCards(ep,tc2)
	Duel.ShuffleHand(ep)
	Duel.BreakEffect()
	if tc2:IsType(TYPE_MONSTER) then
		if Duel.GetLocationCount(1-tp,LOCATION_MZONE)<=0 then return end
			if Duel.SpecialSummon(tc2,0,1-tp,1-tp,false,false,POS_FACEUP) then
			Duel.Recover(1-tp,tc2:GetAttack(),REASON_EFFECT) end
	else
end
end
