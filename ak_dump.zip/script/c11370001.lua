--Revenge Attack
function c11370001.initial_effect(c)
	local e3=Effect.CreateEffect(c)
	e3:SetDescription(aux.Stringid(11370001,1))
	e3:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_ACTIVATE)
	e3:SetCode(EVENT_DAMAGE_STEP_END)
	e3:SetCondition(c11370001.atkcon)
	e3:SetOperation(c11370001.atkop)
	c:RegisterEffect(e3)
end
function c11370001.atkcon(e,tp,eg,ep,ev,re,r,rp)
	local a=Duel.GetAttacker()
	local at=Duel.GetAttackTarget()
	return at  and tp==Duel.GetTurnPlayer() and at:IsRelateToBattle() and a:IsChainAttackable()
end
function c11370001.atkop(e,tp,eg,ep,ev,re,r,rp)
	local a=Duel.GetAttacker()
	if not a:IsImmuneToEffect(e) then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(1000)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		a:RegisterEffect(e1)
		Duel.ChainAttack()
	end
end
