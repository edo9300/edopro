--無限地獄 Zero (K)
function c317.initial_effect(c)
	c:EnableCounterPermit(0x86)

	local e02=Effect.CreateEffect(c)
	e02:SetType(EFFECT_TYPE_SINGLE)
	e02:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e02:SetRange(LOCATION_MZONE)
	e02:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
	e02:SetValue(1)
	c:RegisterEffect(e02)

	local e00=Effect.CreateEffect(c) 
	e00:SetType(EFFECT_TYPE_SINGLE) 
	e00:SetCode(EFFECT_CANNOT_SUMMON) 
	c:RegisterEffect(e00) 
	local e01=e00:Clone() 
	e01:SetCode(EFFECT_CANNOT_MSET) 
	c:RegisterEffect(e01) 

	--cannot special summon
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_SPSUMMON_CONDITION)
	e1:SetValue(aux.FALSE)
	c:RegisterEffect(e1)


	local e18=Effect.CreateEffect(c)
	e18:SetType(EFFECT_TYPE_FIELD)
	e18:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e18:SetCode(EFFECT_CANNOT_LOSE_KOISHI)
	e18:SetRange(LOCATION_HAND)
	e18:SetCondition(c317.actcondition)
	e18:SetTargetRange(1,0)
	e18:SetValue(1)
	c:RegisterEffect(e18)

	local e2=Effect.CreateEffect(c)
	e2:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e2:SetCode(317)
	e2:SetLabelObject(e18)
	e2:SetRange(LOCATION_HAND)
	e2:SetCondition(c317.condition3)
	e2:SetCost(c317.spcost)
	e2:SetTarget(c317.target)
	e2:SetOperation(c317.activate)
	c:RegisterEffect(e2)
end

function c317.actcondition(e,c)
	local c=e:GetHandler()
	local a,aeg,aep,aev,are,ar,arp=Duel.CheckEvent(317,true)
	return (a and c317.condition3(e,e:GetHandlerPlayer(),aeg,aep,aev,are,ar,arp) and c317.spcost(e,e:GetHandlerPlayer(),aeg,aep,aev,are,ar,arp,0) and c317.target(e,e:GetHandlerPlayer(),aeg,aep,aev,are,ar,arp,0)
	and (c:IsLocation(LOCATION_HAND) or (c:IsLocation(LOCATION_ONFIELD) and c:GetReason()==c)))
	or (c:GetFlagEffect(317)~=0)
end

function c317.condition(e,tp,eg,ep,ev,re,r,rp)
	if re:GetHandler():IsDisabled() then return end
	local e1=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_DAMAGE)
	local e2=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_RECOVER)
	local rd=e1 and not e2
	local rr=not e1 and e2
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if ex and (cp==tp or cp==PLAYER_ALL) and not rd and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) then 
		return true 
	end
	ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_RECOVER)
	return ex and (cp==tp or cp==PLAYER_ALL) and rr and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) 
end
function c317.condition3(e,tp,eg,ep,ev,re,r,rp)
	return ep==tp
end
function c317.spcost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetMatchingGroupCount(Card.IsDiscardable,tp,LOCATION_HAND,0,e:GetHandler())>0 end
	local g=Duel.GetMatchingGroup(Card.IsDiscardable,tp,LOCATION_HAND,0,e:GetHandler())   
	Duel.SendtoGrave(g,REASON_EFFECT+REASON_DISCARD)
end
function c317.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsCanBeSpecialSummoned(e,0,tp,true,false) 
			and Duel.GetLocationCount(tp,LOCATION_MZONE)>0 end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_HAND)
	e:GetHandler():RegisterFlagEffect(317,RESET_CHAIN,0,1)
end
function c317.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if Duel.GetLocationCount(tp,LOCATION_MZONE)==0 then return end
	if Duel.SpecialSummon(c,0,tp,tp,true,false,POS_FACEUP)>0 then
	local e18=Effect.CreateEffect(c)
	e18:SetType(EFFECT_TYPE_FIELD)
	e18:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e18:SetCode(EFFECT_CANNOT_LOSE_LP)
	e18:SetRange(LOCATION_MZONE)
	e18:SetTargetRange(1,0)
	e18:SetValue(1)
	c:RegisterEffect(e18)
	local e19=e18:Clone()
	e19:SetCode(EFFECT_CANNOT_LOSE_DECK)
	c:RegisterEffect(e19)
	local e20=e18:Clone()
	e20:SetCode(EFFECT_CANNOT_LOSE_EFFECT)
	c:RegisterEffect(e20)

	local e1=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_DAMAGE)
	local e2=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_RECOVER)
	local rd=e1 and not e2
	local rr=not e1 and e2
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if ex and (cp==tp or cp==PLAYER_ALL) and not rd and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) then 
	--local e3=Effect.CreateEffect(c)
	--e3:SetType(EFFECT_TYPE_FIELD)
	--e3:SetCode(EFFECT_CHANGE_DAMAGE)
	--e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	--e3:SetTargetRange(1,0)
	--e3:SetValue(Duel.GetLP(tp)-1)
	--e3:SetReset(RESET_EVENT+EVENT_CHAIN_SOLVED)
	--Duel.RegisterEffect(e3,tp) 
	end
	ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_RECOVER)
	if ex and (cp==tp or cp==PLAYER_ALL) and rr and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) then
	--local e3=Effect.CreateEffect(c)
	--e3:SetType(EFFECT_TYPE_FIELD)
	--e3:SetCode(EFFECT_CHANGE_DAMAGE)
	--e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	--e3:SetTargetRange(1,0)
	--e3:SetValue(Duel.GetLP(tp)-1)
	--e3:SetReset(RESET_CHAIN)
	--Duel.RegisterEffect(e3,tp) 
	end 

	--Duel.SetLP(tp,4)
	local e3=Effect.CreateEffect(c)
	e3:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_PLAYER_TARGET)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CHANGE_DAMAGE)
	e3:SetTargetRange(1,0)
	e3:SetValue(0)
	--Duel.RegisterEffect(e3,tp) 

	local e004=Effect.GlobalEffect()  
	e004:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_PLAYER_TARGET)
	e004:SetType(EFFECT_TYPE_CONTINUOUS+EFFECT_TYPE_FIELD)
	e004:SetCode(EVENT_ADJUST)
	e004:SetCondition(c317.lpcon)
	e004:SetOperation(c317.lpop)
	e004:SetTargetRange(1,0)
	--Duel.RegisterEffect(e004,tp) 
	local e0043=e004:Clone()
	e0043:SetCode(EVENT_CHAIN_SOLVED)
	--Duel.RegisterEffect(e0043,tp)


			local e102=Effect.CreateEffect(c)
			e102:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
			e102:SetCode(EVENT_PRE_DAMAGE_CALCULATE)
			e102:SetOperation(c317.rdop)
			--Duel.RegisterEffect(e102,tp)
			local e103=e102:Clone()
			e103:SetCode(EVENT_CHAINING)
			e103:SetCondition(c317.rdcon)
			e103:SetOperation(c317.rdop2)
			--Duel.RegisterEffect(e103,tp)
			local e02=Effect.CreateEffect(c)
			e02:SetType(EFFECT_TYPE_FIELD)
			e02:SetCode(EFFECT_DRAW_COUNT)
			e02:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
			e02:SetTargetRange(1,0)
			e02:SetRange(LOCATION_MZONE)
			e02:SetCondition(c317.dc)
			e02:SetValue(0)
			--c:RegisterEffect(e02,true)

	   local e115=Effect.CreateEffect(c)
	   e115:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	   e115:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	   e115:SetCode(EVENT_LEAVE_FIELD)
	   e115:SetOperation(c317.lose)
	   c:RegisterEffect(e115,true) end
end

function c317.lpcon(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetLP(e:GetHandlerPlayer())~=4
end
function c317.lpop(e,tp,eg,ep,ev,re,r,rp) 
	Duel.SetLP(e:GetHandlerPlayer(),4)
end 

function c317.rdop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local ttp=c:GetControler()
	if Duel.GetBattleDamage(ttp)>=Duel.GetLP(ttp) then
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CHANGE_DAMAGE)
	e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e3:SetTargetRange(1,0)
	e3:SetValue(Duel.GetLP(ttp)-1)
	e3:SetReset(RESET_PHASE+PHASE_DAMAGE)
	--Duel.RegisterEffect(e3,ttp) 
	end

	local value=math.floor(Duel.GetBattleDamage(ttp)/500)
	if value>0 then 
	c:AddCounter(0x86,value) 
	if c:GetCounter(0x86)>=3 then 
	Duel.Destroy(c,REASON_RULE) end end
end
function c317.rdcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tp=c:GetControler()
	local e1=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_DAMAGE)
	local e2=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_RECOVER)
	local rd=e1 and not e2
	local rr=not e1 and e2
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if ex and (cp==tp or cp==PLAYER_ALL) and not rd and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) then
--and cv>=Duel.GetLP(tp) then 
		return true 
	end
	ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_RECOVER)
	return ex and (cp==tp or cp==PLAYER_ALL) and rr and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) 
--and cv>=Duel.GetLP(tp) 
end
function c317.rdop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tp=c:GetControler()
	local e1=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_DAMAGE)
	local e2=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_RECOVER)
	local rd=e1 and not e2
	local rr=not e1 and e2
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if ex and (cp==tp or cp==PLAYER_ALL) and not rd and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) then 
	if cv>=Duel.GetLP(tp) then
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CHANGE_DAMAGE)
	e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e3:SetTargetRange(1,0)
	e3:SetValue(Duel.GetLP(tp)-1)
	e3:SetReset(RESET_EVENT+EVENT_CHAIN_SOLVED)
	--Duel.RegisterEffect(e3,tp) 
	end

	local value=math.floor(cv/500)
	if value>0 then 
	c:AddCounter(0x86,value) 
	if c:GetCounter(0x86)>=3 then 
	Duel.Destroy(c,REASON_RULE) end end
	end

	ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_RECOVER)
	if ex and (cp==tp or cp==PLAYER_ALL) and rr and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) then
	if cv>=Duel.GetLP(tp) then
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CHANGE_DAMAGE)
	e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e3:SetTargetRange(1,0)
	e3:SetValue(Duel.GetLP(tp)-1)
	e3:SetReset(RESET_CHAIN)
	Duel.RegisterEffect(e3,tp) end

	local value=math.floor(cv/500)
	if value>0 then 
	c:AddCounter(0x86,value) 
	if c:GetCounter(0x86)>=3 then 
	Duel.Destroy(c,REASON_RULE) end end
	end 
end
function c317.dc(e)
local tp=e:GetOwner():GetControler()
return Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)<1
end
function c317.losecon(e,tp,eg,ep,ev,re,r,rp)
	  local tc=e:GetHandler() 
	  local ttp=tc:GetControler() 
	return tc:IsFacedown()  or tc:IsDisabled() 
end
function c317.lose(e,tp,eg,ep,ev,re,r,rp)
	local WIN_REASON_ZERO=0x105
	Duel.Win(1-tp,WIN_REASON_ZERO)
end
function c317.damcon(e,tp,eg,ep,ev,re,r,rp)
	return ep==tp
end
function c317.damcon2(e,tp,eg,ep,ev,re,r,rp)
	  if re:GetHandler():IsDisabled()  then return end
	local e1=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_DAMAGE)
	local e2=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_RECOVER)
	local rd=e1 and not e2
	local rr=not e1 and e2
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if ex and (cp==tp or cp==PLAYER_ALL) and not rd and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) then 
		return true 
	end
	ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_RECOVER)
	return ex and (cp==tp or cp==PLAYER_ALL) and rr and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE)
end
function c317.dam(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local dam=Duel.GetBattleDamage(tp)
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_CHANGE_DAMAGE)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetRange(LOCATION_MZONE) 
	e1:SetTargetRange(1,0)
	e1:SetValue(0)
	e1:SetReset(RESET_PHASE+PHASE_DAMAGE)
	c:RegisterEffect(e1)
	local value=math.floor(dam/500)
	if value>0 then 
	c:AddCounter(0x86,value) 
	if c:GetCounter(0x86)>=3 then 
	Duel.Destroy(c,REASON_RULE) end end
end
function c317.dam2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if re:GetHandler():IsDisabled() then return end
	local e1=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_DAMAGE)
	local e2=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_RECOVER)
	local rd=e1 and not e2
	local rr=not e1 and e2
	local value=0
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if ex and (cp==tp or cp==PLAYER_ALL) and not rd and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=500 then 
		value=math.floor(cv/500)
	 end
	 ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_RECOVER)
	 if ex and (cp==tp or cp==PLAYER_ALL) and rr and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=500 then
			value=math.floor(cv/500)
	 end
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CHANGE_DAMAGE)
	e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e3:SetRange(LOCATION_MZONE) 
	e3:SetTargetRange(1,0)
	e3:SetValue(0)
	e3:SetReset(RESET_CHAIN)
	c:RegisterEffect(e3)
	if value>0 then 
	c:AddCounter(0x86,value) 
	if c:GetCounter(0x86)>=3 then 
	Duel.Destroy(c,REASON_RULE) end end
end
