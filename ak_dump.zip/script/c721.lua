--霸王之逆鳞
function c721.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_DESTROY+CATEGORY_DISABLE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(0x20,0x20)
	e1:SetCondition(c721.condition)
	e1:SetTarget(c721.target)
	e1:SetOperation(c721.operation)
	c:RegisterEffect(e1)

	if not c721.global_check then
		c721.global_check=true
		c721[0]=0
		c721[1]=0
		local ge1=Effect.CreateEffect(c)
		ge1:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE)	
		ge1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
		ge1:SetCode(EVENT_BATTLE_DAMAGE)
		ge1:SetOperation(c721.checkop)
		Duel.RegisterEffect(ge1,0)
		local ge2=Effect.CreateEffect(c)
		ge2:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE)	
		ge2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
		ge2:SetCode(EVENT_TURN_END)
		ge2:SetCountLimit(1)
		ge2:SetOperation(c721.clear)
		Duel.RegisterEffect(ge2,0)
	end
end
--------------------------
--damage check
function c721.checkop(e,tp,eg,ep,ev,re,r,rp)
	local dam = c721[ep]+ev
	c721[ep]=dam
end
function c721.clear(e,tp,eg,ep,ev,re,r,rp)
	c721[0] = 0
	c721[1] = 0
end
--------------------------------
--activate
function c721.zarcfilter(c)
	return c:IsFaceup() and c:IsCode(703) 
end
function c721.spfilter(c,e,tp,code)
	return c:IsCode(code) and c:IsCanBeSpecialSummoned(e,0,tp,true,false)
end
function c721.relfilter(c)
	return c:IsFaceup() and c:IsCode(712)
end
function c721.drvfilter(c)
	return c:IsFaceup() and c:IsCode(702)
end
function c721.desfilter(c)
	return not (c:IsFaceup() and c:IsCode(703)) and c:IsDestructable() 
end
function c721.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.IsExistingMatchingCard(c721.zarcfilter,tp,LOCATION_ONFIELD,0,1,nil) and Duel.GetCurrentPhase()==PHASE_END
	and c721[tp]>=2000
end
function c721.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c721.desfilter,tp,LOCATION_MZONE,0,1,nil) 
	and Duel.IsExistingMatchingCard(c721.spfilter,tp,LOCATION_EXTRA+LOCATION_GRAVE,0,1,nil,e,tp,720) 
	and Duel.IsExistingMatchingCard(c721.spfilter,tp,LOCATION_EXTRA+LOCATION_GRAVE,0,1,nil,e,tp,714) 
	and Duel.IsExistingMatchingCard(c721.spfilter,tp,LOCATION_EXTRA+LOCATION_GRAVE,0,1,nil,e,tp,712) 
	and Duel.IsExistingMatchingCard(c721.spfilter,tp,LOCATION_EXTRA+LOCATION_GRAVE,0,1,nil,e,tp,717) end
	local sg=Duel.GetMatchingGroup(c721.desfilter,tp,LOCATION_MZONE,0,nil)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,sg,sg:GetCount(),0,0)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,4,0,LOCATION_EXTRA+LOCATION_GRAVE)	
end
function c721.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local d = false
	local s = false	
	local sg=Duel.GetMatchingGroup(c721.desfilter,tp,LOCATION_MZONE,0,nil)
	d=Duel.Destroy(sg,REASON_EFFECT)
	if d >=0 then
	    local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
	    if ft<4 or Duel.IsPlayerAffectedByEffect(tp,59822133) then return end
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local g=Duel.SelectMatchingCard(tp,c721.spfilter,tp,LOCATION_EXTRA+LOCATION_GRAVE,0,1,1,nil,e,tp,720)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local g2=Duel.SelectMatchingCard(tp,c721.spfilter,tp,LOCATION_EXTRA+LOCATION_GRAVE,0,1,1,nil,e,tp,714)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local g3=Duel.SelectMatchingCard(tp,c721.spfilter,tp,LOCATION_EXTRA+LOCATION_GRAVE,0,1,1,nil,e,tp,712)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local g4=Duel.SelectMatchingCard(tp,c721.spfilter,tp,LOCATION_EXTRA+LOCATION_GRAVE,0,1,1,nil,e,tp,717)
		g:Merge(g2)
		g:Merge(g3)
		g:Merge(g4)		
		if g:GetCount()~=4 then return end
		local tc=g:GetFirst()
		local a=nil
		while tc do
			if Duel.SpecialSummonStep(tc,0,tp,tp,true,false,POS_FACEUP) then
				local e1=Effect.CreateEffect(c)
				e1:SetType(EFFECT_TYPE_SINGLE)
				e1:SetCode(EFFECT_DISABLE)
				e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
				tc:RegisterEffect(e1,true)
				local e2=Effect.CreateEffect(c)
				e2:SetType(EFFECT_TYPE_SINGLE)
				e2:SetCode(EFFECT_DISABLE_EFFECT)
				e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
				tc:RegisterEffect(e2,true)
				if c721.relfilter(tc) then a=tc end
			end
			tc=g:GetNext()
		end
		Duel.SpecialSummonComplete()
		s = true
	if s == true and a~=nil and c721.relfilter(a) and Duel.IsExistingMatchingCard(c721.drvfilter,tp,LOCATION_GRAVE+LOCATION_EXTRA,0,2,nil) and Duel.SelectYesNo(tp,aux.Stringid(32559361,0)) then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
		local mat=Duel.SelectMatchingCard(tp,c721.drvfilter,tp,LOCATION_GRAVE+LOCATION_EXTRA,0,2,2,nil)
		Duel.Overlay(a,mat)
	end end
end