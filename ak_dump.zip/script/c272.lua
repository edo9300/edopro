--阶级控制
function c272.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	c:RegisterEffect(e1)

	  --atkup
	local e2=Effect.CreateEffect(c)
	e2:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	--e2:SetCategory(CATEGORY_ATKCHANGE)
	e2:SetType(EFFECT_TYPE_CONTINUOUS)
	e2:SetRange(LOCATION_SZONE)
	e2:SetCode(EVENT_PRE_DAMAGE_CALCULATE)
	--e2:SetHintTiming(TIMING_DAMAGE_CAL)
	e2:SetCondition(c272.con)
	e2:SetOperation(c272.atkop)
	c:RegisterEffect(e2)

	--cannot attack
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CANNOT_ATTACK_ANNOUNCE)
	e3:SetRange(LOCATION_SZONE)
	e3:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
	e3:SetTarget(c272.atktarget)
	c:RegisterEffect(e3)
end

function c272.con(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	return c:GetFlagEffect(272)==0 and Duel.GetAttacker()~=nil and Duel.GetAttackTarget()~=nil 
	  and (Duel.GetAttacker():GetRank()>Duel.GetAttackTarget():GetRank() or Duel.GetAttacker():GetRank()<Duel.GetAttackTarget():GetRank())
end
function c272.atkop(e,tp,eg,ep,ev,re,r,rp)
	  e:GetHandler():RegisterFlagEffect(272,RESET_PHASE+PHASE_DAMAGE_CAL,0,1)
	  if Duel.GetAttacker():GetRank()==Duel.GetAttackTarget():GetRank() then return end	
	  local tc=Duel.GetAttacker()
	  local rank=0
	  if Duel.GetAttacker():GetRank()>Duel.GetAttackTarget():GetRank() then
	  tc=Duel.GetAttackTarget() 
	  rank=Duel.GetAttacker():GetRank()-Duel.GetAttackTarget():GetRank() end
	  if Duel.GetAttacker():GetRank()<Duel.GetAttackTarget():GetRank() then
	  rank=Duel.GetAttackTarget():GetRank()-Duel.GetAttacker():GetRank() end
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_UPDATE_ATTACK)
	e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_DAMAGE_CAL)
	e1:SetValue(-rank*1000)
	tc:RegisterEffect(e1)
end

function c272.atkfilter(c,rank)
	return c:GetRank()<rank and c:GetAttackAnnouncedCount()==0 and c:IsAttackable() and c:IsType(TYPE_XYZ) 
end
function c272.atktarget(e,c)
	return not (c:IsType(TYPE_XYZ) or c:GetRank()>1) or ((c:IsType(TYPE_XYZ) or c:GetRank()>1) and Duel.IsExistingMatchingCard(c272.atkfilter,c:GetControler(),LOCATION_MZONE,0,1,c,c:GetRank()))
end
