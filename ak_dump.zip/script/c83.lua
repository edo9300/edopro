--古代機械混沌巨人 (K)
function c83.initial_effect(c)
      aux.AddFusionProcCode4(c,42878636,511001540,511001544,511001726,true,true)
	c:EnableReviveLimit()

	--unaffectable
	local e4=Effect.CreateEffect(c)
	e4:SetType(EFFECT_TYPE_SINGLE)
	e4:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCode(EFFECT_CANNOT_BE_EFFECT_TARGET)
	e4:SetValue(c83.tgoval)
	c:RegisterEffect(e4)
	local e5=e4:Clone()
	e5:SetCode(EFFECT_IMMUNE_EFFECT)
	e5:SetValue(c83.efilter)
	c:RegisterEffect(e5)	

	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_ATTACK_ALL)
	e1:SetValue(1)
	c:RegisterEffect(e1)

	local e5=Effect.CreateEffect(c)
	e5:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e5:SetCode(EVENT_ATTACK_ANNOUNCE)
	e5:SetOperation(c83.negop1)
	c:RegisterEffect(e5)
end

function c83.tgoval(e,re,rp)
	return rp~=e:GetHandlerPlayer() and not re:GetHandler():IsImmuneToEffect(e) and (re:IsActiveType(TYPE_SPELL) or re:IsActiveType(TYPE_TRAP))
end

function c83.efilter(e,te)
	return te:GetOwnerPlayer()~=e:GetHandlerPlayer() and (te:IsActiveType(TYPE_SPELL) or te:IsActiveType(TYPE_TRAP))
end

function c83.negop1(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Duel.GetMatchingGroup(Card.IsFaceup,tp,0,LOCATION_MZONE,nil)
      local tc=g:GetFirst()
	while tc do
		local e5=Effect.CreateEffect(c)
		e5:SetType(EFFECT_TYPE_SINGLE)
		e5:SetCode(EFFECT_DISABLE)
		e5:SetReset(RESET_EVENT+0x1fe0000+RESET_EVENT+EVENT_DAMAGE_STEP_END+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e5)
		local e6=Effect.CreateEffect(c)
		e6:SetType(EFFECT_TYPE_SINGLE)
		e6:SetCode(EFFECT_DISABLE_EFFECT)
		e6:SetReset(RESET_EVENT+0x1fe0000+RESET_EVENT+EVENT_DAMAGE_STEP_END+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e6)
            tc=g:GetNext()
	end
end
