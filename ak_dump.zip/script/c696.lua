--破滅之花 (K)
function c696.initial_effect(c)
    --Activate
    local e1=Effect.CreateEffect(c)
    e1:SetType(EFFECT_TYPE_ACTIVATE)
    e1:SetCode(EVENT_FREE_CHAIN)
    e1:SetCost(c696.cost)
    c:RegisterEffect(e1) 	

	local e2=Effect.CreateEffect(c)
	e2:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DELAY+EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_PLAYER_TARGET)
	e2:SetCategory(CATEGORY_DAMAGE+CATEGORY_ATKCHANGE)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e2:SetRange(LOCATION_SZONE)
	e2:SetCode(EVENT_SPSUMMON_SUCCESS)
    e2:SetTargetRange(LOCATION_MZONE,0)
	e2:SetTarget(c696.tktg)
	e2:SetOperation(c696.tkop)
	c:RegisterEffect(e2)

	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_DAMAGE+CATEGORY_TOGRAVE)
	e3:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e3:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e3:SetRange(LOCATION_SZONE)
	e3:SetCode(EVENT_PHASE+PHASE_STANDBY)
	e3:SetCountLimit(1)
	e3:SetCondition(c696.con)
	e3:SetTarget(c696.target)
	e3:SetOperation(c696.operation)
	c:RegisterEffect(e3)	
end

function c696.filter(c)
    return c:IsType(TYPE_SPELL) and c:IsType(TYPE_CONTINUOUS) and c:IsAbleToGraveAsCost()
end
function c696.cost(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then return Duel.IsExistingMatchingCard(c696.filter,tp,LOCATION_SZONE,LOCATION_SZONE,1,e:GetHandler()) end
    Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TOGRAVE)
	local g=Duel.SelectMatchingCard(tp,c696.filter,tp,LOCATION_SZONE,LOCATION_SZONE,1,1,e:GetHandler())
	Duel.SendtoGrave(g,REASON_COST)
end

function c696.spfilter(c,e,tp)
	return c:GetAttack()<c:GetBaseAttack() and c:IsFaceup()
end
function c696.tktg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingTarget(c696.spfilter,tp,LOCATION_MZONE,0,1,nil)
    and Duel.IsExistingTarget(Card.IsFaceup,1-tp,LOCATION_MZONE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g=Duel.SelectTarget(tp,c696.spfilter,tp,LOCATION_MZONE,0,1,1,nil):GetFirst()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g2=Duel.SelectTarget(tp,Card.IsFaceup,tp,0,LOCATION_MZONE,1,1,nil):GetFirst()
	Duel.SetTargetPlayer(1-tp)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,g:GetBaseAttack()-g:GetAttack())
end
function c696.tkop(e,tp,eg,ep,ev,re,r,rp)
	local p=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER)
	local ag=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)	
	if ag:GetCount()<2 then return end
	local g=ag:Filter(Card.IsControler,nil,tp):GetFirst()
	local g2=ag:Filter(Card.IsControler,nil,1-tp):GetFirst()	
	local d=g:GetBaseAttack()-g:GetAttack()
	Duel.Damage(p,d,REASON_EFFECT)
	local e1=Effect.CreateEffect(e:GetHandler())
    e1:SetType(EFFECT_TYPE_SINGLE)
    e1:SetCode(EFFECT_UPDATE_ATTACK)
	e1:SetValue(-d)
	e1:SetReset(RESET_EVENT+0x1ff0000)
	g2:RegisterEffect(e1)
end

function c696.con(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetTurnPlayer()==tp
end
function c696.filter2(c)
	return c:IsType(TYPE_SPELL) and c:IsType(TYPE_CONTINUOUS) and c:IsAbleToGrave()
end
function c696.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsControler(tp) and chkc:IsLocation(LOCATION_SZONE) and c696.filter2(chkc) and chkc~=e:GetHandler()	end
	if chk==0 then return true end
	local op=1
	if Duel.IsExistingTarget(c696.filter2,tp,LOCATION_SZONE,0,1,e:GetHandler()) then
	op=Duel.SelectOption(tp,aux.Stringid(12174035,0),aux.Stringid(37209439,1)) end
	if op==0 then
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TOGRAVE)
	local g=Duel.SelectTarget(tp,c696.filter2,tp,LOCATION_SZONE,0,1,1,e:GetHandler())
	Duel.SetOperationInfo(0,CATEGORY_TOGRAVE,g,1,0,0)
	else
	Duel.SetTargetPlayer(tp)
	Duel.SetTargetParam(1000)	
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,tp,1000) end	
	e:SetLabel(op)
end
function c696.operation(e,tp,eg,ep,ev,re,r,rp)
	local op=e:GetLabel()
	if op==0 then
	local tc=Duel.GetFirstTarget()
    Duel.SendtoGrave(tc,REASON_EFFECT)
	else
	local p,d=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER,CHAININFO_TARGET_PARAM)
	Duel.Damage(p,d,REASON_EFFECT)
    end	
end
