--Shining Horizon
function c365.initial_effect(c)
      --Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_DRAW)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_BATTLE_DESTROYED)
      e1:SetCondition(c365.condition)
	e1:SetTarget(c365.target)
	e1:SetOperation(c365.activate)
	c:RegisterEffect(e1)
end

function c365.condition(e,tp,eg,ep,ev,re,r,rp)
      return eg:GetFirst():GetBattleTarget():IsControler(tp) and eg:GetFirst():IsControler(1-tp)
end
function c365.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsPlayerCanDraw(tp,1) end
	Duel.SetOperationInfo(0,CATEGORY_DRAW,nil,1,tp,1)
end
function c365.filter(c)
      local te,eg,ep,ev,re,r,rp=c:CheckActivateEffect(false,true,true)
	return c:IsType(TYPE_SPELL) and c:IsAbleToGraveAsCost() and c:CheckActivateEffect(false,true,false)~=nil
      and c:IsCode(72302403)
end
function c365.activate(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetDecktopGroup(tp,1)
	local tc=g:GetFirst()
	if Duel.Draw(tp,1,REASON_EFFECT)==0 then return end
	if tc then
		Duel.ConfirmCards(1-tp,tc)
		Duel.BreakEffect()
            if tc:IsType(TYPE_SPELL) 
            and not tc:IsType(TYPE_CONTINUOUS) and not tc:IsType(TYPE_QUICKPLAY) and not tc:IsType(TYPE_FIELD) and not tc:IsType(TYPE_EQUIP) then
	      local tpe=tc:GetType()
		local te,eg,ep,ev,re,r,rp=tc:CheckActivateEffect(false,true,true)
		local condition=te:GetCondition()
		local cost=te:GetCost()
            Duel.ClearTargetCard()
		local target=te:GetTarget()
		local operation=te:GetOperation()
            e:SetCategory(te:GetCategory())
		e:SetProperty(te:GetProperty())
		if bit.band(tp,TYPE_EQUIP+TYPE_CONTINUOUS+TYPE_FIELD)==0 and not tc:IsCode(58775978) and not tc:IsCode(72302403) then
		Duel.MoveToField(tc,tp,tp,LOCATION_SZONE,POS_FACEUP,true)
            Duel.Hint(HINT_CARD,0,tc:GetCode())
		tc:CreateEffectRelation(te)
		if cost then cost(e,tp,eg,ep,ev,re,r,rp,1) end
		if target then target(e,tp,eg,ep,ev,re,r,rp,1) end
		local gg=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS)
		if gg then
			local etc=gg:GetFirst()
			while etc do
				etc:CreateEffectRelation(te)
				etc=gg:GetNext()
			end
		end
		Duel.BreakEffect()
		if operation then operation(e,tp,eg,ep,ev,re,r,rp) end
		tc:ReleaseEffectRelation(te) 
		if etc then	
			etc=gg:GetFirst()
			while etc do
				etc:ReleaseEffectRelation(te)
				etc=gg:GetNext()
			end
		end
            Duel.SendtoGrave(tc,REASON_RULE) end

            if tc:IsCode(58775978) or tc:IsCode(72302403) then
            Duel.MoveToField(tc,tp,tp,LOCATION_SZONE,POS_FACEUP,true) 
            Duel.Hint(HINT_CARD,0,tc:GetCode())
      if tc:IsCode(72302403) then
	--cannot attack
	local e2=Effect.CreateEffect(tc)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetCode(EFFECT_CANNOT_ATTACK_ANNOUNCE)
	e2:SetRange(LOCATION_SZONE)
	e2:SetTargetRange(0,LOCATION_MZONE)
	tc:RegisterEffect(e2)
      tc:SetTurnCounter(0)
	--destroy
	local e1=Effect.CreateEffect(tc)
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e1:SetCode(EVENT_PHASE+PHASE_END)
	e1:SetCountLimit(1)
	e1:SetRange(LOCATION_SZONE)
	e1:SetCondition(c365.descon)
	e1:SetOperation(c365.desop)
	e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END+RESET_OPPO_TURN,3)
	tc:RegisterEffect(e1)
	tc:RegisterFlagEffect(1082946,RESET_PHASE+PHASE_END+RESET_OPPO_TURN,0,3)
	c72302403[tc]=e1 end

      if tc:IsCode(58775978) then
	--cannot attack
	local e2=Effect.CreateEffect(tc)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetCode(EFFECT_CANNOT_ATTACK_ANNOUNCE)
	e2:SetRange(LOCATION_SZONE)
	e2:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
	tc:RegisterEffect(e2)
      tc:SetTurnCounter(0)
	--destroy
	local e1=Effect.CreateEffect(tc)
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e1:SetCode(EVENT_PHASE+PHASE_END)
	e1:SetCountLimit(1)
	e1:SetRange(LOCATION_SZONE)
	e1:SetCondition(c365.descon)
	e1:SetOperation(c365.desop2)
	e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END+RESET_OPPO_TURN,2)
	tc:RegisterEffect(e1)
	tc:RegisterFlagEffect(1082946,RESET_PHASE+PHASE_END+RESET_OPPO_TURN,0,2)
	c58775978[tc]=e1 end end 
		end
		Duel.ShuffleHand(tp)
	end
end
function c365.descon(e,tp,eg,ep,ev,re,r,rp)
	return tp~=Duel.GetTurnPlayer()
end
function c365.desop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local ct=c:GetTurnCounter()
	ct=ct+1
	c:SetTurnCounter(ct)
	if ct==3 then
		Duel.Destroy(c,REASON_RULE)
		c:ResetFlagEffect(1082946)
	end
end
function c365.desop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local ct=c:GetTurnCounter()
	ct=ct+1
	c:SetTurnCounter(ct)
	if ct==2 then
		Duel.Destroy(c,REASON_RULE)
		c:ResetFlagEffect(1082946)
	end
end
