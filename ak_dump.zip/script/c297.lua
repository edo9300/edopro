--中古回收箱 (K)
function c297.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetCondition(c297.condition)
	e1:SetTarget(c297.target)
	e1:SetOperation(c297.activate)
	c:RegisterEffect(e1)
end

function c297.condition(e,tp,eg,ep,ev,re,r,rp)
	return rp==1-tp and eg:FilterCount(c297.filter,nil,e,tp)>0
end
function c297.filter(c,e,tp)
      local mg=c:GetMaterial()
	return c:GetSummonType()==SUMMON_TYPE_FUSION and mg:GetCount()>0 and Duel.IsExistingMatchingCard(c297.filter3,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,nil,e,tp,mg)
end
function c297.filter3(c,e,tp,mg)
	return mg:IsContains(c) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
end
function c297.target(e,tp,eg,ep,ev,re,r,rp,chk)
      local mg3=Group.CreateGroup()
      if eg:FilterCount(c297.filter,nil,e,tp)>0 then
      local tc=eg:GetFirst()
      while tc do
      local mg=tc:GetMaterial()
      local mg2=mg:Filter(c297.filter3,nil,e,tp,mg)
      mg3:Merge(mg2)
      tc=eg:GetNext() end end
	if chk==0 then return eg:FilterCount(c297.filter,nil,e,tp)>0 and mg3:GetCount()>0
		and not Duel.IsPlayerAffectedByEffect(tp,59822133)
		and Duel.GetLocationCount(tp,LOCATION_MZONE)>=mg3:GetCount() end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,mg3,mg3:GetCount(),tp,LOCATION_DECK)
end
function c297.activate(e,tp,eg,ep,ev,re,r,rp)
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then return end
      local mg3=Group.CreateGroup()
      if eg:FilterCount(c297.filter,nil,e,tp)>0 then
      local tc=eg:GetFirst()
      while tc do
      local mg=tc:GetMaterial()
      local mg2=mg:Filter(c297.filter3,nil,e,tp,mg)
      mg3:Merge(mg2)
      tc=eg:GetNext() end end
	if Duel.GetLocationCount(tp,LOCATION_MZONE)>=mg3:GetCount() then
      Duel.SpecialSummon(mg3,0,tp,tp,false,false,POS_FACEUP) end
end

