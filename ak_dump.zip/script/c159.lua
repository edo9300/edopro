function c159.initial_effect(c)
	  --c:SetUniqueOnField(1,1,159)
	c:EnableCounterPermit(0x81)
	  c:EnableCounterPermit(0x82)
	  c:EnableCounterPermit(0x83)
	  c:EnableCounterPermit(0x84)
	  c:EnableReviveLimit()

	-- Level/Rank
	local e000=Effect.CreateEffect(c)
	e000:SetType(EFFECT_TYPE_SINGLE)
	e000:SetCode(EFFECT_RANK_LEVEL)
	c:RegisterEffect(e000)
	
	  local e00=Effect.CreateEffect(c)
	  e00:SetType(EFFECT_TYPE_SINGLE)
	  e00:SetCode(EFFECT_SET_ATTACK)
	  e00:SetValue(c159.atkvalue)
	  c:RegisterEffect(e00)
	  local e01=e00:Clone()
	  e01:SetCode(EFFECT_SET_DEFENSE)
	  e01:SetValue(c159.defvalue)
	  c:RegisterEffect(e01)

	--cannot destroyed
	  local e0=Effect.CreateEffect(c)
	  e0:SetType(EFFECT_TYPE_SINGLE)
	e0:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
	  e0:SetValue(c159.indes)
	c:RegisterEffect(e0)

	--special summon
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e1:SetCode(EFFECT_FUSION_MATERIAL)
	  e1:SetCondition(c159.fscondition)
	e1:SetOperation(c159.fsoperation)
	c:RegisterEffect(e1)
	local e11=Effect.CreateEffect(c)
	  e11:SetDescription(aux.Stringid(13715,2))
	e11:SetType(EFFECT_TYPE_FIELD)
	e11:SetCode(EFFECT_SPSUMMON_PROC)
	e11:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e11:SetRange(LOCATION_EXTRA)
	  e11:SetValue(SUMMON_TYPE_SYNCHRO)
	e11:SetCondition(c159.spcon)
	e11:SetOperation(c159.spop)
	c:RegisterEffect(e11)
	local e12=e11:Clone()
	  e12:SetDescription(aux.Stringid(13715,3))
	  e12:SetValue(SUMMON_TYPE_XYZ)
	e12:SetCondition(c159.spcon3)
	e12:SetOperation(c159.spop3)
	c:RegisterEffect(e12)

	  --spson
	  local e2=Effect.CreateEffect(c)
	  e2:SetType(EFFECT_TYPE_SINGLE)
	  e2:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	  e2:SetCode(EFFECT_SPSUMMON_CONDITION)
	  e2:SetValue(c159.splimit)
	  c:RegisterEffect(e2)

	--spsummon
	local e30=Effect.CreateEffect(c)
	e30:SetType(EFFECT_TYPE_SINGLE)
	e30:SetCode(EFFECT_CANNOT_DISABLE_SPSUMMON)
	e30:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	c:RegisterEffect(e30)
	local e31=e30:Clone()
	e31:SetCode(EFFECT_CANNOT_DISABLE_FLIP_SUMMON)
	c:RegisterEffect(e31)

	--counter
	local e4=Effect.CreateEffect(c)
	e4:SetCategory(CATEGORY_REMOVE+CATEGORY_TOHAND+CATEGORY_TODECK)
	e4:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e4:SetDescription(aux.Stringid(13715,9))
	e4:SetType(EFFECT_TYPE_IGNITION)
	e4:SetCountLimit(1)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCondition(c159.cocondition)
	e4:SetTarget(c159.cotarget)
	e4:SetOperation(c159.cooperation)
	c:RegisterEffect(e4)
	local e42=e4:Clone()
	e42:SetCategory(CATEGORY_TODECK)
	e42:SetCondition(c159.cocondition2)
	e42:SetOperation(c159.cooperation2)
	c:RegisterEffect(e42)

	--可以无效对方陷阱
	local e53=Effect.CreateEffect(c)
	e53:SetDescription(aux.Stringid(900000020,2))
	e53:SetCategory(CATEGORY_NEGATE)
	e53:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_QUICK_O)
	e53:SetCode(EVENT_CHAINING)
	e53:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e53:SetRange(LOCATION_MZONE)
	e53:SetCondition(c159.discon)
	e53:SetTarget(c159.distg)
	e53:SetOperation(c159.disop)
	c:RegisterEffect(e53)
	--战斗时对方怪兽攻守下降墓地魔法师族怪兽数量
	local e54=Effect.CreateEffect(c)
	e54:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e54:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e54:SetCode(EVENT_ATTACK_ANNOUNCE)
	e54:SetCondition(c159.atcon)
	e54:SetOperation(c159.atop1)
	c:RegisterEffect(e4)
	local e55=Effect.CreateEffect(c)
	e55:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e55:SetCode(EVENT_BE_BATTLE_TARGET)
	e55:SetOperation(c159.atop2)
	c:RegisterEffect(e55)

	  local e6=Effect.CreateEffect(c)
	  e6:SetDescription(aux.Stringid(13715,5))
	e6:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	  e6:SetCategory(CATEGORY_TOHAND)
	  e6:SetType(EFFECT_TYPE_IGNITION)
	  e6:SetRange(LOCATION_MZONE)
	  e6:SetCountLimit(1)
	  e6:SetCondition(c159.fuscon)
	e6:SetTarget(c159.fustarget)
	  e6:SetOperation(c159.fusoperation)
	  c:RegisterEffect(e6)

	--multi attack
	local e7=Effect.CreateEffect(c)
	e7:SetDescription(aux.Stringid(24696097,0))
	e7:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e7:SetType(EFFECT_TYPE_IGNITION)
	e7:SetCountLimit(1)
	e7:SetRange(LOCATION_MZONE)
	e7:SetCondition(c159.mtcon)
	e7:SetOperation(c159.mtop)
	c:RegisterEffect(e7)
	--negate
	local e72=Effect.CreateEffect(c)
	e72:SetDescription(aux.Stringid(24696097,1))
	e72:SetCategory(CATEGORY_DISABLE+CATEGORY_DESTROY)
	e72:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_QUICK_O)
	e72:SetCode(EVENT_CHAINING)
	e72:SetCountLimit(1) 
	e72:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e72:SetRange(LOCATION_MZONE)
	e72:SetCondition(c159.negdiscon)
	e72:SetTarget(c159.negdistg)
	e72:SetOperation(c159.negdisop)
	c:RegisterEffect(e72)

	  local e8=Effect.CreateEffect(c)
	  e8:SetDescription(aux.Stringid(13715,7))
	e8:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	  e8:SetCategory(CATEGORY_SPECIAL_SUMMON)
	  e8:SetType(EFFECT_TYPE_IGNITION)
	  e8:SetRange(LOCATION_MZONE)
	  e8:SetCountLimit(1)
	  e8:SetCondition(c159.xyzcon)
	e8:SetTarget(c159.xyztg)
	  e8:SetOperation(c159.xyzop)
	  c:RegisterEffect(e8)
	  local e81=Effect.CreateEffect(c)
	  e81:SetDescription(aux.Stringid(13715,8))
	e81:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	  e81:SetCategory(CATEGORY_DAMAGE)
	  e81:SetType(EFFECT_TYPE_IGNITION)
	  e81:SetRange(LOCATION_MZONE)
	  e81:SetCountLimit(1)
	  e81:SetCondition(c159.xyzcon)
	e81:SetTarget(c159.xyzdamtg)
	  e81:SetOperation(c159.xyzdamop)
	  c:RegisterEffect(e81)

	--不会被卡的效果破坏、除外、返回手牌和卡组、送入墓地、无效化、改变控制权、变为里侧表示、成为特殊召唤素材
	local e100=Effect.CreateEffect(c)
	e100:SetType(EFFECT_TYPE_SINGLE)
	e100:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e100:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e100:SetRange(LOCATION_MZONE)
	e100:SetCode(EFFECT_CANNOT_DISABLE)
	e100:SetValue(1)
	c:RegisterEffect(e100)
	local e106=e100:Clone()
	e106:SetCode(EFFECT_CANNOT_CHANGE_CONTROL)
	c:RegisterEffect(e106)
end
c159.counter=0

function c159.atkvalue(e)
	  local g=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,46986414)
	  local g1=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,89943723)
	  local g2=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,44508094)
	  local g3=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,84013237)
	  g:Merge(g1)
	  g:Merge(g2)
	  g:Merge(g3) 
	  local tatk=0
	  local tc=g:GetFirst()
	  while tc do
	  local atk=tc:GetAttack()
	  tatk=tatk+atk
	  tc=g:GetNext() end
	  return tatk   
end
function c159.defvalue(e)
	  local g=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,46986414)
	  local g1=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,89943723)
	  local g2=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,44508094)
	  local g3=Duel.GetMatchingGroup(Card.IsCode,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,84013237)
	  g:Merge(g1)
	  g:Merge(g2)
	  g:Merge(g3) 
	  local tdef=0
	  local tc=g:GetFirst()
	  while tc do
	  local def=tc:GetDefense()
	  tdef=tdef+def
	  tc=g:GetNext() end
	  return tdef   
end

function c159.indes(e,c)
	return not e:GetHandler():GetBattleTarget():IsSetCard(0x48) 
	  and not e:GetHandler():GetBattleTarget():IsSetCard(0x1048) and not e:GetHandler():GetBattleTarget():IsSetCard(0x2048)
end

function c159.fscondition(e,mg,gc)
	if mg==nil then return false end
	if gc then return false end
	  local c=e:GetHandler()	
	local tp=c:GetControler()
	return mg~=nil and Duel.IsExistingMatchingCard(c159.fsfilter1,tp,LOCATION_MZONE,0,1,nil,e,tp) 
					 and Duel.IsExistingMatchingCard(c159.fsfilter2,tp,LOCATION_MZONE,0,1,nil,e,tp) 
					 and Duel.IsExistingMatchingCard(c159.fsfilter3,tp,LOCATION_MZONE,0,1,nil,e,tp) 
					 and Duel.IsExistingMatchingCard(c159.fsfilter4,tp,LOCATION_MZONE,0,1,nil,e,tp)  
end
function c159.fsfilter1(c,e,tp)
		return c:IsCanBeFusionMaterial() and not c:IsImmuneToEffect(e) and c:IsCode(46986414)
end
function c159.fsfilter2(c,e,tp)
		return c:IsCanBeFusionMaterial() and not c:IsImmuneToEffect(e) and c:IsCode(89943723)
end
function c159.fsfilter3(c,e,tp)
		return c:IsCanBeFusionMaterial() and not c:IsImmuneToEffect(e) and c:IsCode(44508094)
end
function c159.fsfilter4(c,e,tp)
		return c:IsCanBeFusionMaterial() and not c:IsImmuneToEffect(e) and c:IsCode(84013237)
end
function c159.fsoperation(e,tp,eg,ep,ev,re,r,rp,gc)
	  local c=e:GetHandler()	
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
	local g1=eg:FilterSelect(tp,c159.fsfilter1,1,1,nil,e,tp)
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
	local g2=eg:FilterSelect(tp,c159.fsfilter2,1,1,nil,e,tp)
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
	local g3=eg:FilterSelect(tp,c159.fsfilter3,1,1,nil,e,tp)
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FMATERIAL)
	local g4=eg:FilterSelect(tp,c159.fsfilter4,1,1,nil,e,tp)
	  g1:GetFirst():RegisterFlagEffect(159,0,0,0)
	  g2:GetFirst():RegisterFlagEffect(159,0,0,0)
	  g3:GetFirst():RegisterFlagEffect(159,0,0,0)
	  g4:GetFirst():RegisterFlagEffect(159,0,0,0)
	  g1:Merge(g2)
	  g1:Merge(g3)
	  g1:Merge(g4)
	Duel.SetFusionMaterial(g1)
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	  e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	  e1:SetRange(LOCATION_MZONE)
	  e1:SetOperation(c159.sumsucop3)
	  c:RegisterEffect(e1)
end
function c159.sumsucop3(e,tp,eg,ep,ev,re,r,rp)
	  local c=e:GetHandler()	
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_SINGLE)
	  e1:SetCode(EFFECT_REMOVE_TYPE)
	  e1:SetValue(TYPE_RITUAL+TYPE_SYNCHRO+TYPE_XYZ)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	  c:RegisterEffect(e1)
	  if not Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_SZONE,0,1,nil,161) and not c:GetFlagEffect(159)~=0 then
	  c:AddCounter(0x82,4) end
end

function c159.zsfilter(c,code)
		return c:IsCanBeXyzMaterial(nil) and c:IsCode(code)
end
function c159.spcon(e,c,tuner)
	if c==nil then return true end
	local tp=c:GetControler()
	  local g=Duel.GetMatchingGroup(c159.zsfilter,tp,LOCATION_MZONE,0,nil,46986414)
	  local g1=Duel.GetMatchingGroup(c159.zsfilter,tp,LOCATION_MZONE,0,nil,89943723)
	  local g2=Duel.GetMatchingGroup(c159.zsfilter,tp,LOCATION_MZONE,0,nil,44508094)
	  local g3=Duel.GetMatchingGroup(c159.zsfilter,tp,LOCATION_MZONE,0,nil,84013237)
	  local gt=Duel.GetMatchingGroup(c159.zsfilter,tp,LOCATION_MZONE,0,nil,21159309)
	return gt:GetCount()~=0 and g:GetCount()~=0  and g1:GetCount()~=0  and g2:GetCount()~=0  and g3:GetCount()~=0 and Duel.GetLocationCountFromEx(tp)>0
end
function c159.spop(e,tp,eg,ep,ev,re,r,rp,c,tuner)
	  local c=e:GetHandler()	
	  if Duel.GetLocationCountFromEx(tp)<1 then return end
	  local g=Duel.GetMatchingGroup(c159.zsfilter,tp,LOCATION_MZONE,0,nil,46986414)
	  local g1=Duel.GetMatchingGroup(c159.zsfilter,tp,LOCATION_MZONE,0,nil,89943723)
	  local g2=Duel.GetMatchingGroup(c159.zsfilter,tp,LOCATION_MZONE,0,nil,44508094)
	  local g3=Duel.GetMatchingGroup(c159.zsfilter,tp,LOCATION_MZONE,0,nil,84013237)
	  local gt=Duel.GetMatchingGroup(c159.zsfilter,tp,LOCATION_MZONE,0,nil,21159309)
	  if gt:GetCount()==0 or g:GetCount()==0 or g1:GetCount()==0 or g2:GetCount()==0 or g3:GetCount()==0 then return end 
	  local tt=gt:FilterSelect(tp,Card.IsCode,1,1,nil,21159309)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	  local t=g:FilterSelect(tp,Card.IsCode,1,1,nil,46986414)
	  local t1=g1:FilterSelect(tp,Card.IsCode,1,1,nil,89943723)
	  local t2=g2:FilterSelect(tp,Card.IsCode,1,1,nil,44508094)
	  local t3=g3:FilterSelect(tp,Card.IsCode,1,1,nil,84013237)
	  t1:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t2:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t3:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t:Merge(t1)
	  t:Merge(t2)
	  t:Merge(t3)
	  t:Merge(tt)
	c:SetMaterial(t)
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	  e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	  e1:SetRange(LOCATION_MZONE)
	  e1:SetOperation(c159.sumsucop)
	  c:RegisterEffect(e1)
	Duel.SendtoGrave(t,REASON_MATERIAL+REASON_SYNCHRO)
end
function c159.sumsucop(e,tp,eg,ep,ev,re,r,rp)
	  local c=e:GetHandler()	
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_SINGLE)
	  e1:SetCode(EFFECT_REMOVE_TYPE)
	  e1:SetValue(TYPE_RITUAL+TYPE_FUSION+TYPE_XYZ)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	  c:RegisterEffect(e1)
	  if not Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_SZONE,0,1,nil,161) and not c:GetFlagEffect(159)~=0 then
	  c:AddCounter(0x83,4) end
end

function c159.spcon3(e,c,tuner)
	if c==nil then return true end
	local tp=c:GetControler()
	  local g=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE,0,nil,46986414)
	  local g1=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE,0,nil,89943723)
	  local g2=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE,0,nil,44508094)
	  local g3=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE,0,nil,84013237)
	return g:GetCount()~=0  and g1:GetCount()~=0  and g2:GetCount()~=0  and g3:GetCount()~=0 and Duel.GetLocationCountFromEx(tp)>0
end
function c159.spop3(e,tp,eg,ep,ev,re,r,rp,c,tuner)  
	  if Duel.GetLocationCountFromEx(tp)<1 then return end
	  local g=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE,0,nil,46986414)
	  local g1=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE,0,nil,89943723)
	  local g2=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE,0,nil,44508094)
	  local g3=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE,0,nil,84013237)
	  if g:GetCount()==0 or g1:GetCount()==0 or g2:GetCount()==0 or g3:GetCount()==0 then return end 
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
	  local t=g:FilterSelect(tp,Card.IsCode,1,1,nil,46986414)
	  local t1=g1:FilterSelect(tp,Card.IsCode,1,1,nil,89943723)
	  local t2=g2:FilterSelect(tp,Card.IsCode,1,1,nil,44508094)
	  local t3=g3:FilterSelect(tp,Card.IsCode,1,1,nil,84013237)
	  t1:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t2:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t3:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t:Merge(t1)
	  t:Merge(t2)
	  t:Merge(t3)
	  local tc=t:GetFirst()
	  while tc do
	  local ttc=tc:GetOverlayGroup()
	  if ttc~=nil then
	  local btc=ttc:GetFirst()
	  while btc do
	  Duel.Overlay(e:GetHandler(),btc)
	  btc=ttc:GetNext() end end
	  tc=t:GetNext() end
	  tc=t:GetFirst()
	  while tc do
	  Duel.Overlay(e:GetHandler(),tc)
	  tc=t:GetNext() end
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	  e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	  e1:SetRange(LOCATION_MZONE)
	  e1:SetOperation(c159.sumsucop2)
	  c:RegisterEffect(e1)
end
function c159.sumsucop2(e,tp,eg,ep,ev,re,r,rp)
	  local c=e:GetHandler()	
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_SINGLE)
	  e1:SetCode(EFFECT_REMOVE_TYPE)
	  e1:SetValue(TYPE_RITUAL+TYPE_SYNCHRO+TYPE_FUSION)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	  c:RegisterEffect(e1)
	  if not Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_SZONE,0,1,nil,161) and not c:GetFlagEffect(159)~=0 then
	  c:AddCounter(0x84,4) end
end

function c159.splimit(e,se,sp,st)
	return st==SUMMON_TYPE_FUSION+0x11
end

function c159.cocondition(e,tp,eg,ep,ev,re,r,rp)
	  local g=Duel.GetMatchingGroup(c159.cofilter,tp,LOCATION_GRAVE,0,nil)
	return (e:GetHandler():GetCounter(0x81)~=0 or e:GetHandler():GetCounter(0x82)~=0 
		  or e:GetHandler():GetCounter(0x83)~=0) and g:GetCount()~=0 
end
function c159.cofilter(c)
	return c:GetFlagEffect(159)~=0 
end
function c159.cotarget(e,tp,eg,ep,ev,re,r,rp,chk)
	  local c=e:GetHandler()
	if chk==0 then return c:IsCanRemoveCounter(tp,0x81,1,REASON_RULE) or c:IsCanRemoveCounter(tp,0x82,1,REASON_RULE)
						   or c:IsCanRemoveCounter(tp,0x83,1,REASON_RULE) or c:IsCanRemoveCounter(tp,0x84,1,REASON_RULE) end
	  if c:GetCounter(0x81)~=0 and c:IsCanRemoveCounter(tp,0x81,1,REASON_RULE) then
	  Duel.SetOperationInfo(0,CATEGORY_REMOVE,nil,0,0,0) end
	  if c:GetCounter(0x82)~=0 and c:IsCanRemoveCounter(tp,0x82,1,REASON_RULE) then
	  Duel.SetOperationInfo(0,CATEGORY_TOHAND,nil,0,0,0) end
	  if (c:GetCounter(0x83)~=0 and c:IsCanRemoveCounter(tp,0x83,1,REASON_RULE)) or (c:GetCounter(0x84)~=0 and c:IsCanRemoveCounter(tp,0x84,1,REASON_RULE)) then
	  Duel.SetOperationInfo(0,CATEGORY_TODECK,nil,0,0,0) end
end
function c159.cooperation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler() 
	if c:IsRelateToEffect(e) and c:IsFaceup() then
			if c:GetCounter(0x84)~=0 then
			e:GetHandler():RemoveOverlayCard(tp,1,1,REASON_RULE)
			c:RemoveCounter(tp,0x84,1,REASON_RULE) 
			tc:GetFirst():ResetFlagEffect(159) end end  
	  local g=Duel.GetMatchingGroup(c159.cofilter,tp,LOCATION_GRAVE,0,nil)
	  local tc=g:FilterSelect(tp,c159.cofilter,1,1,nil)
	  if g:GetCount()==0 then return end
	if c:IsRelateToEffect(e) and c:IsFaceup() then
			if c:GetCounter(0x81)~=0 then
			if Duel.Remove(tc,0,REASON_RULE)>0 then
			c:RemoveCounter(tp,0x81,1,REASON_RULE)
			tc:GetFirst():ResetFlagEffect(159) end end
			if c:GetCounter(0x82)~=0 then
			if Duel.SendtoHand(tc,tp,REASON_RULE)>0 then
			c:RemoveCounter(tp,0x82,1,REASON_RULE) 
			tc:GetFirst():ResetFlagEffect(159) end end
			if c:GetCounter(0x83)~=0 then
			if Duel.SendtoDeck(tc,tp,2,REASON_RULE)>0 then
			c:RemoveCounter(tp,0x83,1,REASON_RULE) 
			tc:GetFirst():ResetFlagEffect(159) end end
		if c:GetCounter(0x81)==0 and c:GetCounter(0x82)==0 and c:GetCounter(0x83)==0 and c:GetCounter(0x84)==0 then
			local WIN_REASON_KING=0x101
			Duel.Win(c:GetControler(),WIN_REASON_KING)
		end
	end
end
function c159.cocondition2(e,tp,eg,ep,ev,re,r,rp)
	  local c=e:GetHandler()
	  local g=c:GetOverlayGroup()
	return c:GetCounter(0x84)~=0 and g:GetCount()~=0 
end
function c159.cooperation2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()   
	  local g=c:GetOverlayGroup()
	  if g:GetCount()==0 then return end
	  local tc=g:FilterSelect(tp,Card.IsFaceup,1,1,nil)
	if c:IsRelateToEffect(e) and c:IsFaceup() and tc:GetCount()~=0 then
			if c:GetCounter(0x84)~=0 then
			if Duel.SendtoGrave(tc,REASON_RULE)>0 then
			c:RemoveCounter(tp,0x84,1,REASON_RULE) 
			tc:GetFirst():ResetFlagEffect(159) end end
		if c:GetCounter(0x84)==0 then
			local WIN_REASON_KING=0x101
			Duel.Win(c:GetControler(),WIN_REASON_KING)
		end
	end
end

function c159.rebcondition1(e,tp,eg,ep,ev,re,r,rp)
	if rp==tp or not re:IsHasType(EFFECT_TYPE_ACTIVATE) or not re:IsHasProperty(EFFECT_FLAG_CARD_TARGET) then return false end
	local g=Duel.GetChainInfo(ev,CHAININFO_TARGET_CARDS)
	if not g or g:GetCount()~=1 then return false end
	local tc=g:GetFirst()
	e:SetLabelObject(tc)
	return tc:IsControler(e:GetHandler():GetControler()) and tc:IsLocation(LOCATION_MZONE)
	  and re:GetHandler():IsCanBeEffectTarget(e) and re:GetHandler():IsControler(1-e:GetHandlerPlayer())
	  and e:GetHandler():GetCounter(0x81)~=0
end
function c159.rebfilter(c,re,rp,tf,ceg,cep,cev,cre,cr,crp)
	return tf(re,rp,ceg,cep,cev,cre,cr,crp,0,c)
end
function c159.rebtarget1(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local tf=re:GetTarget()
	local res,ceg,cep,cev,cre,cr,crp=Duel.CheckEvent(re:GetCode(),true)
	if chkc then return chkc~=e:GetLabelObject() and chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(tp) and tf(re,rp,ceg,cep,cev,cre,cr,crp,0,chkc) end
	if chk==0 then return Duel.IsExistingTarget(c159.rebfilter,tp,0,LOCATION_MZONE,1,e:GetLabelObject(),re,rp,tf,ceg,cep,cev,cre,cr,crp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	Duel.SelectTarget(tp,c159.rebfilter,tp,0,LOCATION_MZONE,1,1,e:GetLabelObject(),re,rp,tf,ceg,cep,cev,cre,cr,crp)
end
function c159.reboperation1(e,tp,eg,ep,ev,re,r,rp)
	local tf=re:GetTarget()
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) and tf(re,rp,nil,nil,nil,nil,nil,nil,0,tc) then
		  local g=Group.FromCards(tc)
		Duel.ChangeTargetCard(ev,g)
	end
end
function c159.rebcondition2(e,tp,eg,ep,ev,re,r,rp)
	if rp==tp or not re:IsHasType(EFFECT_TYPE_ACTIVATE) or not re:IsHasProperty(EFFECT_FLAG_CARD_TARGET) then return false end
	local g=Duel.GetChainInfo(ev,CHAININFO_TARGET_CARDS)
	if not g or g:GetCount()~=1 then return false end
	local tc=g:GetFirst()
	e:SetLabelObject(tc)
	return tc:IsControler(e:GetHandler():GetControler()) and tc:IsLocation(LOCATION_MZONE)
	  and not re:GetHandler():IsCanBeEffectTarget(e) and re:GetHandler():IsControler(1-e:GetHandlerPlayer()) 
	  and e:GetHandler():GetCounter(0x81)~=0
end
function c159.reboperation2(e,tp,eg,ep,ev,re,r,rp)
	  Duel.NegateActivation(ev)
	  local c=e:GetHandler()	  
	  local tc=re:GetHandler()
	  local g=Duel.GetMatchingGroup(Card.IsFaceup,tp,0,LOCATION_MZONE,nil) 
	  local gtc=g:RandomSelect(tp,1)
	  local gtc2=gtc:GetFirst()
	  if tc then
	local operation=re:GetOperation()
	e:SetProperty(re:GetProperty())
	c:CreateEffectRelation(re)
	Duel.SetTargetCard(gtc2)
	if operation then operation(e,tp,gtc,tp,ev,re,r,rp) end
	c:ReleaseEffectRelation(re) 
	  end
end

function c159.discon(e,tp,eg,ep,ev,re,r,rp)
	return not e:GetHandler():IsStatus(STATUS_BATTLE_DESTROYED)
		and re:IsHasType(EFFECT_TYPE_ACTIVATE) and re:IsActiveType(TYPE_TRAP) and Duel.IsChainNegatable(ev) and e:GetHandler():GetCounter(0x81)~=0
end
function c159.distg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetOperationInfo(0,CATEGORY_NEGATE,eg,1,0,0)
	if re:GetHandler():IsDestructable() and re:GetHandler():IsRelateToEffect(re) then
		Duel.SetOperationInfo(0,CATEGORY_DESTROY,eg,1,0,0)
	end
end
function c159.disop(e,tp,eg,ep,ev,re,r,rp,chk)
	if e:GetHandler():IsFacedown() or not e:GetHandler():IsRelateToEffect(e) then return end
	Duel.NegateActivation(ev)
	if re:GetHandler():IsRelateToEffect(re) then
		Duel.Destroy(eg,REASON_EFFECT)
	end
end

function c159.atcon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetCounter(0x81)~=0
end
function c159.atop1(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local atk=Duel.GetMatchingGroupCount(Card.IsRace,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,RACE_SPELLCASTER)*500
	local d=Duel.GetAttackTarget()
	if d then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(-atk)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		d:RegisterEffect(e1)
		local e2=e1:Clone()
		e2:SetCode(EFFECT_UPDATE_DEFENSE)
		d:RegisterEffect(e2)
	end
end
function c159.atop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local atk=Duel.GetMatchingGroupCount(Card.IsRace,e:GetHandler():GetControler(),LOCATION_GRAVE,0,nil,RACE_SPELLCASTER)*500
	local a=Duel.GetAttacker()
	if a then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(-atk)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		a:RegisterEffect(e1)
		local e2=e1:Clone()
		e2:SetCode(EFFECT_UPDATE_DEFENSE)
		a:RegisterEffect(e2)
	end
end

function c159.fuscon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetCounter(0x82)~=0 and Duel.IsExistingMatchingCard(c159.fusfilter,tp,LOCATION_GRAVE+LOCATION_REMOVED,0,1,nil) 
end
function c159.fusfilter(c)
	return c:IsCode(23) and c:IsFaceup() and c:IsAbleToHand()
end
function c159.fustarget(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return (chkc:IsLocation(LOCATION_GRAVE) or chkc:IsLocation(LOCATION_REMOVED)) and chkc:IsControler(tp) and c159.fusfilter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c159.fusfilter,tp,0,LOCATION_GRAVE+LOCATION_REMOVED,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RTOHAND)
	local g=Duel.SelectTarget(tp,c159.fusfilter,tp,LOCATION_GRAVE+LOCATION_REMOVED,0,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,g,1,0,0)
end
function c159.fusoperation(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) then
		Duel.SendtoHand(tc,nil,REASON_EFFECT)
	end
end

function c159.mtcon(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)>=5 and e:GetHandler():GetCounter(0x83)~=0
end
function c159.mtop(e,tp,eg,ep,ev,re,r,rp)
	Duel.ConfirmDecktop(tp,5)
	local g=Duel.GetDecktopGroup(tp,5)
	local ct=g:FilterCount(Card.IsType,nil,TYPE_TUNER)
	Duel.ShuffleDeck(tp)
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_EXTRA_ATTACK)
	e1:SetReset(RESET_EVENT+0x1ff0000+RESET_PHASE+PHASE_END)
	e1:SetValue(ct-1)
	e:GetHandler():RegisterEffect(e1)
end

function c159.negdiscon(e,tp,eg,ep,ev,re,r,rp)
	if e:GetHandler():IsStatus(STATUS_BATTLE_DESTROYED) or not Duel.IsChainNegatable(ev) then return false end
	if re:IsHasCategory(CATEGORY_NEGATE)
		and Duel.GetChainInfo(ev-1,CHAININFO_TRIGGERING_EFFECT):IsHasType(EFFECT_TYPE_ACTIVATE) then return false end
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_DESTROY)
	return ex and tg~=nil and tc+tg:FilterCount(Card.IsOnField,nil)-tg:GetCount()>0 and e:GetHandler():GetCounter(0x83)~=0
end
function c159.negdistg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetOperationInfo(0,CATEGORY_DISABLE,eg,1,0,0)
	if re:GetHandler():IsDestructable() and re:GetHandler():IsRelateToEffect(re) then
		Duel.SetOperationInfo(0,CATEGORY_DESTROY,eg,1,0,0)
	end
end
function c159.negdisop(e,tp,eg,ep,ev,re,r,rp)
	Duel.NegateEffect(ev)
	if re:GetHandler():IsRelateToEffect(re) then
		Duel.Destroy(eg,REASON_EFFECT)
	end
end

function c159.fsfilter(c,e,tp)
		return not c:IsImmuneToEffect(e)
end
function c159.ffsfilter2(c,e,tp)
		return c:IsType(TYPE_MONSTER)
end
function c159.xyzfilter(c)
		return (c:IsCode(209) or c:IsCode(13719) or c:IsCode(65305468)) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,true,false)
end
function c159.xyzcon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetCounter(0x84)~=0
end
function c159.xyztg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0 and
		  Duel.IsExistingMatchingCard(c159.ffsfilter2,tp,LOCATION_MZONE,0,2,e:GetHandler(),e,tp) and Duel.IsExistingMatchingCard(c159.xyzfilter,tp,LOCATION_EXTRA,0,1,nil) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,0)
end
function c159.xyzop(e,tp,eg,ep,ev,re,r,rp)
	  if not Duel.IsExistingMatchingCard(c159.fsfilter,tp,LOCATION_MZONE,0,2,e:GetHandler(),e,tp) or not Duel.IsExistingMatchingCard(c159.xyzfilter,tp,LOCATION_EXTRA,0,1,nil) then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	  local g2=Duel.SelectMatchingCard(tp,c159.xyzfilter,tp,LOCATION_EXTRA,0,1,1,nil)
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	  local g=Duel.SelectMatchingCard(tp,c159.fsfilter,tp,LOCATION_MZONE,0,2,5,e:GetHandler(),e,tp)
	  Duel.Overlay(g2:GetFirst(),g)
	  Duel.SpecialSummon(g2:GetFirst(),SUMMON_TYPE_XYZ,tp,tp,true,false,POS_FACEUP)
	  g2:GetFirst():CompleteProcedure()
end

function c159.xyzfilter2(c)
	  return (c:IsSetCard(0x48) or c:IsSetCard(0x1048) or c:IsSetCard(0x2048)) and c:IsFaceup() 
end
function c159.xyzdamtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c159.xyzfilter2,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil) end
	  local count=Duel.GetMatchingGroupCount(c159.xyzfilter2,tp,LOCATION_MZONE,LOCATION_MZONE,nil)
	  Duel.SetTargetPlayer(1-tp)
	  local dam=count*1000
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,dam)
end
function c159.xyzdamop(e,tp,eg,ep,ev,re,r,rp)
	  if not Duel.IsExistingMatchingCard(c159.xyzfilter2,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil) then return end
	  local count=Duel.GetMatchingGroupCount(c159.xyzfilter2,tp,LOCATION_MZONE,LOCATION_MZONE,nil)
	  local dam=count*1000
	local p=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER)
	  Duel.Damage(p,dam,REASON_EFFECT)
end
