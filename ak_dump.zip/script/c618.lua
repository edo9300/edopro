--デストーイ・ホイールソウ・ライオ
function c618.initial_effect(c)
	--fusion material
	c:EnableReviveLimit() 
	Fusion.AddProcCode2(c,34688023,66457138,true,true)
	
	--destroy
	local e2=Effect.CreateEffect(c)
	e2:SetCategory(CATEGORY_DESTROY+CATEGORY_DAMAGE)
	e2:SetType(EFFECT_TYPE_IGNITION)
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetCountLimit(1)
	e2:SetRange(LOCATION_MZONE)
	e2:SetTarget(c618.target)
	e2:SetOperation(c618.operation)
	c:RegisterEffect(e2)
end

function c618.filter(c)
	return c:IsFaceup() and aux.TRUE
end
function c618.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(1-tp) and c618.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c618.filter,tp,0,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_DESTROY)
	local g=Duel.SelectTarget(tp,c618.filter,tp,0,LOCATION_MZONE,1,1,nil)
	local atk=g:GetFirst():GetTextAttack()
	if atk<0 then atk=0 end
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,atk)
end
function c618.operation(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) then
		local atk=tc:GetTextAttack()
		if atk<0 then atk=0 end
		if Duel.Destroy(tc,REASON_EFFECT)~=0 then
	  local dg=Duel.GetOperatedGroup()
	  local tatk=0
	  for dgc in aux.Next(dg) do
	  local atk=dgc:GetBaseAttack()
	  if atk<0 then atk=0 end
	  tatk=tatk+atk
	  end
	  Duel.Damage(1-tp,tatk,REASON_EFFECT)
		end
	end
end
