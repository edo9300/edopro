--Overlay-Magic Infinity Force
function c212.initial_effect(c) 
	--Special Summon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(13717,7))
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_CANNOT_DISABLE)
	e1:SetTarget(c212.target)
	e1:SetOperation(c212.operation)
	c:RegisterEffect(e1)	
	  local e2=e1:Clone()
	e2:SetDescription(aux.Stringid(13717,9))
	e2:SetTarget(c212.target2)
	e2:SetOperation(c212.operation2)
	c:RegisterEffect(e2) 
end

--Filter for second or more targets
function c212.sFilter(c,e,tp)
	local no=c.xyz_number
	return c:IsSetCard(0x7f) and c:IsFaceup() 
	  and Duel.IsExistingMatchingCard(c212.xyzFilter,tp,LOCATION_EXTRA,0,1,nil,e,tp,c)
		and aux.MustMaterialCheck(c,tp,EFFECT_MUST_BE_XMATERIAL) 
end
--Filter for XYZ monsters of a certain rank, that require a certain number of XYZ materials or lower
function c212.xyzFilter(c,e,tp,tc)
	return c:IsCode(211) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,true,false) and tc:IsCanBeXyzMaterial(c)
end
function c212.xyzFilter0(c,e,tp)
	return c:IsCode(211) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,true,false) 
end
--Special Summon target
function c212.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_GRAVE) and chkc:IsFaceup() end
	if chk==0 then return Duel.GetFlagEffect(tp,212)==0 
					  and Duel.IsExistingMatchingCard(c212.sFilter,tp,LOCATION_GRAVE,LOCATION_GRAVE,3,nil,e,tp) and Duel.GetLocationCountFromEx(tp)>0 end  
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g1=Duel.SelectTarget(tp,c212.sFilter,tp,LOCATION_GRAVE,LOCATION_GRAVE,3,99,nil,e,tp)   
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
	Duel.RegisterFlagEffect(tp,212,0,0,0)
end
--Special Summon operation
function c212.operation(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
	count = g:GetCount()
	if count < 2 then return end		
	if Duel.GetLocationCountFromEx(tp)<1 or not aux.MustMaterialCheck(g,tp,EFFECT_MUST_BE_XMATERIAL) then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local sg=Duel.SelectMatchingCard(tp,c212.xyzFilter0,tp,LOCATION_EXTRA,0,1,1,nil,e,tp)
	local sc = sg:GetFirst()
	if not sc then return end
	sc:SetMaterial(g)
	Duel.Overlay(sc,g)
	Duel.SpecialSummon(sc,SUMMON_TYPE_XYZ,tp,tp,true,false,POS_FACEUP)
	sc:CompleteProcedure()
end

function c212.sFilter2(c,e,tp)
	local no=c.xyz_number
	return c:IsSetCard(0x7f) and c:IsFaceup() and aux.MustMaterialCheck(c,tp,EFFECT_MUST_BE_XMATERIAL) 
end
--Special Summon target
function c212.target2(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_GRAVE) and chkc:IsFaceup() end
	if chk==0 then return Duel.GetFlagEffect(tp,91999980)~=0 and Duel.GetFlagEffect(tp,212)==0 and Duel.GetLocationCountFromEx(tp)>0
					  and Duel.IsExistingMatchingCard(c212.sFilter2,tp,LOCATION_GRAVE,LOCATION_GRAVE,3,nil,e,tp) 
					  and not Duel.IsExistingMatchingCard(aux.overfilter,tp,LOCATION_EXTRA+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,LOCATION_ONFIELD,1,nil,tp,211) end  
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g1=Duel.SelectTarget(tp,c212.sFilter2,tp,LOCATION_GRAVE,LOCATION_GRAVE,3,99,nil,e,tp)  
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
	Duel.RegisterFlagEffect(tp,212,0,0,0)
end
--Special Summon operation
function c212.operation2(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
	  g=g:Filter(c212.sFilter2,nil,e,tp)
	count = g:GetCount()
	if count < 2 or not aux.MustMaterialCheck(g,tp,EFFECT_MUST_BE_XMATERIAL) or Duel.GetLocationCountFromEx(tp)<1 or not Duel.IsExistingMatchingCard(c212.sFilter2,tp,LOCATION_GRAVE,LOCATION_GRAVE,3,nil,e,tp) or Duel.IsExistingMatchingCard(aux.overfilter,tp,LOCATION_EXTRA+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,LOCATION_ONFIELD,1,nil,tp,211) then return end  
	  local sc=Duel.CreateToken(tp,211,nil,nil,nil,nil,nil,nil) 
	  Duel.Remove(sc,POS_FACEUP,REASON_RULE)
	sc:SetMaterial(g)
	Duel.Overlay(sc,g)
	Duel.SpecialSummon(sc,SUMMON_TYPE_XYZ,tp,tp,true,true,POS_FACEUP)
	sc:CompleteProcedure()
	  sc:RegisterFlagEffect(157,0,0,1)
end
