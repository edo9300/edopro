--
function c712.initial_effect(c)
	--xyz summon
	Xyz.AddProcedure(c,aux.FilterBoolFunction(Card.IsAttribute,ATTRIBUTE_DARK),4,2)
	c:EnableReviveLimit()
	
	--spsummon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(80208158,0))
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_DELAY)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetRange(LOCATION_EXTRA)
	e1:SetCondition(c712.condition)
	e1:SetTarget(c712.target)
	e1:SetOperation(c712.activate)
	c:RegisterEffect(e1)

	--Gain ATK
	local e2=Effect.CreateEffect(c)
	e2:SetCategory(CATEGORY_ATKCHANGE)  
	e2:SetDescription(aux.Stringid(87911394,0))
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetCode(EVENT_PRE_DAMAGE_CALCULATE)
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCondition(c712.atkcon)
	e2:SetCost(c712.atkcost)
	e2:SetTarget(c712.atktg)
	e2:SetOperation(c712.atkop)
	c:RegisterEffect(e2,false,1)

	--cannot be target
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CANNOT_SELECT_BATTLE_TARGET)
	e3:SetRange(LOCATION_MZONE)
	e3:SetTargetRange(0,LOCATION_MZONE)
	e3:SetValue(c712.atlimit)
	c:RegisterEffect(e3)	
	
	local e4=Effect.CreateEffect(c)
	e4:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_ATKCHANGE)  
	e4:SetType(EFFECT_TYPE_QUICK_O)
	e4:SetCode(EVENT_FREE_CHAIN)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCost(c712.cost)
	e4:SetTarget(c712.tg)
	e4:SetOperation(c712.op)
	c:RegisterEffect(e4)	
end

--Sp Summon
function c712.filter(c,tp)
	return c:IsType(TYPE_XYZ) and c:IsControler(tp) and bit.band(c:GetSummonType(),SUMMON_TYPE_XYZ)~=0
end
function c712.filter2(c)
	return c:IsFaceup() and c:IsCode(703)
end
function c712.condition(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()  
	if c:IsType(TYPE_PENDULUM) and c:IsFaceup() then return false end
	return eg:IsExists(c712.filter,1,nil,1-tp) and not c:IsStatus(STATUS_CHAINING)
	and Duel.IsExistingMatchingCard(c712.filter2,tp,LOCATION_MZONE,0,1,nil)
end
function c712.filter5(c,xc)
	local tp=c:GetControler()
	return c:IsFaceup() and xc.xyz_filter(c) 
	and Duel.IsExistingMatchingCard(c712.filter52,tp,LOCATION_MZONE,0,1,c,xc)
end
function c712.filter52(c,xc)
	local tp=c:GetControler()
	return c:IsFaceup() and xc.xyz_filter(c) 
end
function c712.target(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()  
	local ft=Duel.GetLocationCountFromEx(tp)
	local ct=-ft
	if chk==0 then return ct<c.minxyzct and Duel.CheckXyzMaterial(c,c.xyz_filter,c:GetRank(),c.minxyzct,c.maxxyzct,nil) 
		and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,false,false) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,c,1,0,LOCATION_EXTRA)
end
function c712.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()  
	if c:IsRelateToEffect(e) then
		Duel.XyzSummon(tp,c,nil)
	end
end

function c712.atkcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local at=c:GetBattleTarget()
	return at and at:IsFaceup()
end
function c712.atkcost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():CheckRemoveOverlayCard(tp,1,REASON_COST) and e:GetHandler():GetFlagEffect(96864105)==0 end
	e:GetHandler():RemoveOverlayCard(tp,1,1,REASON_COST)
	e:GetHandler():RegisterFlagEffect(96864105,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_DAMAGE_CAL,0,1)  
end
function c712.cfilter(c,tp)
	return c:IsControler(1-tp) and c:IsLocation(LOCATION_MZONE) and c:IsFaceup()
end
function c712.atktg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return false end
	local c=e:GetHandler()
	local bc=c:GetBattleTarget()
	if chk==0 and not c:IsHasEffect(715) then return bc and bc:IsOnField() and bc:IsCanBeEffectTarget(e) end
	if chk==0 and c:IsHasEffect(715) then return Duel.GetMatchingGroup(c712.cfilter,tp,0,LOCATION_MZONE,nil,tp):GetCount()>0 end
	if not c:IsHasEffect(715) then Duel.SetTargetCard(bc) end
	if c:IsHasEffect(715) then
	e:SetProperty(0+EFFECT_FLAG_CARD_TARGET) end	
end
function c712.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Group.CreateGroup() 
	if not c:IsHasEffect(715) then  
	g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
	else
	g=Duel.GetMatchingGroup(c712.cfilter,tp,0,LOCATION_MZONE,nil,tp) end
	if g:GetCount()<1 then return end
	local tc=g:GetFirst()
	while tc do 
	if tc:IsFaceup() then
		local atk=tc:GetAttack()
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_SET_ATTACK_FINAL)
		e1:SetValue(0)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e1)   
		if c:IsFaceup() and c:IsRelateToEffect(e) and not tc:IsImmuneToEffect(e) then
			local e1=Effect.CreateEffect(c)
			e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetCode(EFFECT_UPDATE_ATTACK)
			e1:SetValue(atk)
			e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
			c:RegisterEffect(e1)
		end
	end
	tc=g:GetNext()
	end
end

function c712.atlimit(e,c)
	return c:IsFaceup() and c:IsType(TYPE_XYZ) and c~=e:GetHandler()
end

function c712.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsAbleToExtraAsCost() end
	Duel.SendtoDeck(e:GetHandler(),nil,2,REASON_COST)
end
function c712.filter3(c,e,tp)
	return c:IsSetCard(0x20f8) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
end
function c712.tg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()  
	if chk==0 then return Duel.IsExistingMatchingCard(c712.filter3,tp,LOCATION_GRAVE,0,2,nil,e,tp)
	and not Duel.IsPlayerAffectedByEffect(tp,59822133) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,2,0,LOCATION_GRAVE)
end
function c712.xyz(c)
	return c:IsFaceup() and c:IsType(TYPE_XYZ) 
end
function c712.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not Duel.IsExistingMatchingCard(c712.filter3,tp,LOCATION_GRAVE,0,2,nil,e,tp) then return end
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then return end   
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(tp,c712.filter3,tp,LOCATION_GRAVE,0,2,2,nil,e,tp)
	Duel.SpecialSummon(g,0,tp,tp,false,false,POS_FACEUP)		
	local tg=Duel.GetMatchingGroup(c712.xyz,tp,0,LOCATION_MZONE,nil)
	local tc=tg:GetFirst()
	while tc do
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_SET_ATTACK_FINAL)
		e1:SetValue(0)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
		tc=tg:GetNext()
	end
end