--D/D/D Synchro
function c766.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c766.target)
	e1:SetOperation(c766.activate)
	c:RegisterEffect(e1)
end
function c766.filter(c,e,tp)
	if not c:IsType(TYPE_SYNCHRO) then return false end
	if not c:IsSetCard(0x10af) then return c:IsSynchroSummonable(nil)
	else
		local mg=Duel.GetMatchingGroup(Card.IsCanBeSynchroMaterial,tp,LOCATION_MZONE+LOCATION_HAND,0,nil,c)
		if c:IsSynchroSummonable(nil,mg) then return true end
		if not e:IsHasType(EFFECT_TYPE_ACTIVATE) then return false end
		local mc=e:GetHandler()
		local e1=Effect.CreateEffect(mc)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_SET_AVAILABLE)
		e1:SetCode(EFFECT_ADD_TYPE)
		e1:SetValue(TYPE_MONSTER+TYPE_TUNER)
		e1:SetReset(RESET_CHAIN)
		mc:RegisterEffect(e1)
		local e2=e1:Clone()
		e2:SetCode(EFFECT_SYNCHRO_LEVEL)
		e2:SetValue(2)
		mc:RegisterEffect(e2)
		mg:AddCard(mc)
		local res=mg:IsExists(c766.ddfilter,1,nil,c,mg,mc)
		e1:Reset()
		e2:Reset()
		return res
	end
end
function c766.ddfilter(c,sc,mg,mc)
	local tlv=mc:GetSynchroLevel(sc)+c:GetSynchroLevel(sc)
	local mg2=mg:Clone()
	mg2:RemoveCard(mc) mg2:RemoveCard(c)
	local mgn=mg:Filter(c766.nfilter,nil,sc)
	local lv=mgn:GetSum(Card.GetSynchroLevel,sc)
	return c:IsCode(47198668) and sc.tuner_filter(mc) and sc.nontuner_filter(c,sc) and not c:IsType(TYPE_TUNER)
	and sc:GetLevel()<=tlv+lv
--and sc:IsSynchroSummonable(c,mg)
end
function c766.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c766.filter,tp,LOCATION_EXTRA,0,1,nil,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
end
function c766.nfilter(c,sc)
	return not c:IsType(TYPE_TUNER) and sc.nontuner_filter(c,sc) 
end
function c766.activate(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetMatchingGroup(c766.filter,tp,LOCATION_EXTRA,0,nil,e,tp)
	if g:GetCount()>0 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local tc=g:Select(tp,1,1,nil):GetFirst()
		if not tc:IsSetCard(0x10af) then
			Duel.SynchroSummon(tp,tc,nil)
		else
			local mg=Duel.GetMatchingGroup(Card.IsCanBeSynchroMaterial,tp,LOCATION_MZONE+LOCATION_HAND,0,nil,tc)
			local c=e:GetHandler()
			if e:IsHasType(EFFECT_TYPE_ACTIVATE) and c:IsRelateToEffect(e) and (not tc:IsSynchroSummonable(nil,mg) or Duel.SelectYesNo(tp,93)) then
				local mgn=mg:Filter(c766.nfilter,nil,tc)
				--mg:AddCard(c)
				local e1=Effect.CreateEffect(c)
				e1:SetType(EFFECT_TYPE_SINGLE)
				e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_IGNORE_IMMUNE)
				e1:SetCode(EFFECT_ADD_TYPE)
				e1:SetValue(TYPE_MONSTER+TYPE_TUNER)
				e1:SetReset(RESET_CHAIN)
				c:RegisterEffect(e1)
				local e2=e1:Clone()
				e2:SetCode(EFFECT_SYNCHRO_LEVEL)
				e2:SetValue(2)
				c:RegisterEffect(e2)
				local mat=Group.CreateGroup()
				Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
				local smat=mgn:FilterSelect(tp,c766.ddfilter,1,1,nil,tc,mg,c):GetFirst()
				mgn:RemoveCard(smat)
				mat:AddCard(smat) mat:AddCard(c)
				if tc:GetLevel()>c:GetSynchroLevel(tc)+smat:GetSynchroLevel(tc) and mgn:GetCount()>0 then
				Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
				local smat2=mgn:SelectWithSumEqual(tp,Card.GetSynchroLevel,tc:GetLevel()-c:GetSynchroLevel(tc)-smat:GetSynchroLevel(tc),1,99,tc) 
				mat:merge(smat2) end
				Duel.SendtoGrave(mat,REASON_MATERIAL+REASON_SYNCHRO)
				tc:SetMaterial(mat)
				Duel.SpecialSummon(tc,SUMMON_TYPE_SYNCHRO,tp,tp,false,false,POS_FACEUP) 
				--Duel.SynchroSummon(tp,tc,smat,mg) 
			else
				Duel.SynchroSummon(tp,tc,nil,mg)
			end
		end
	end
end
