--D/D/D Xyz
function c768.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c768.target)
	e1:SetOperation(c768.activate)
	c:RegisterEffect(e1)
end
function c768.filter(c,e,tp)
	return c:IsCanBeEffectTarget(e) and c:IsSetCard(0x10af) and c:IsType(TYPE_PENDULUM) and (c:IsLocation(LOCATION_GRAVE) or c:IsFaceup())
		and c:IsCanBeSpecialSummoned(e,0,tp,false,false)
end
function c768.xfilter(c,xyz)
	return xyz.xyz_filter and xyz.xyz_filter(c) and c:IsCanBeXyzMaterial(xyz)
end
function c768.xyzfilter(c,sg,e)
	--local ct=sg:GetCount()
	local mc=e:GetHandler()
	local e2=nil
	if c.xyz_filter==nil or not c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,false,false) then return false end
	local mg=sg:Filter(c768.xfilter,nil,c)
	local ct=mg:GetCount()
	local xcount=c.minxyzct
	if mg:IsExists(Card.IsCode,1,nil,47198668) and e:IsHasType(EFFECT_TYPE_ACTIVATE) then
		xcount=xcount-1
		e2=Effect.CreateEffect(mc)
		e2:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_IGNORE_IMMUNE)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(511002116)
		e2:SetReset(RESET_CHAIN)
		--mc:RegisterEffect(e2,false,6)
	end
	local res=(xcount<=ct) 
--and c:IsXyzSummonable(sg,xcount,xcount)
	--if e2 then e2:Reset() end
	return res
end
function c768.rescon(mft,exft,ft)
	return  function(sg,e,tp,mg)
				local exct=sg:FilterCount(Card.IsLocation,nil,LOCATION_EXTRA)
				local mct=sg:FilterCount(aux.NOT(Card.IsLocation),nil,LOCATION_EXTRA)
				return exft>=exct and mft>=mct and ft>=sg:GetCount() 
					and Duel.IsExistingMatchingCard(c768.xyzfilter,tp,LOCATION_EXTRA,0,1,sg,sg,e)
			end
end
function c768.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return false end
	local mg=Duel.GetMatchingGroup(c768.filter,tp,LOCATION_GRAVE+LOCATION_EXTRA,0,nil,e,tp)
	local ftex=Duel.GetLocationCountFromEx(tp)
	local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
	local ftt=Duel.GetUsableMZoneCount(tp)
	local ect=c29724053 and Duel.IsPlayerAffectedByEffect(tp,29724053) and c29724053[tp]-1
	if ect then ftex=math.min(ftex,ect) end
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then ftt=math.min(ftt,1) ftex=math.min(ftex,1) ft=math.min(ft,1) end
	if chk==0 then return Duel.IsPlayerCanSpecialSummonCount(tp,2) and ftt>0 and (ft>0 or ftex>0)
		and aux.SelectUnselectGroup(mg,e,tp,nil,ftt,c768.rescon(ft,ftex,ftt),0) end
	local sg=aux.SelectUnselectGroup(mg,e,tp,nil,ftt,c768.rescon(ft,ftex,ftt),1,tp,HINTMSG_SPSUMMON,c768.rescon(ft,ftex,ftt))
	Duel.SetTargetCard(sg)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,sg,sg:GetCount()+1,tp,LOCATION_EXTRA)
end
function c768.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
	if Duel.IsPlayerAffectedByEffect(tp,59822133) and g:GetCount()>1 then return end
	local ftex=Duel.GetLocationCountFromEx(tp)
	local ftt=Duel.GetUsableMZoneCount(tp)
	local ect=c29724053 and Duel.IsPlayerAffectedByEffect(tp,29724053) and c29724053[tp]
	if ect then ftex=math.min(ftex,ect) end
	if ftt<g:GetCount() or g:FilterCount(Card.IsLocation,nil,LOCATION_EXTRA)>ftex then
		local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
		local sg=aux.SelectUnselectGroup(g,e,tp,nil,ftt,c768.rescon(ft,ftex,ftt),1,tp,HINTMSG_SPSUMMON,c768.rescon(ft,ftex,ftt))
		if sg:GetCount()>0 then g=sg end
	end
	if not aux.MainAndExtraSpSummonLoop(c768.disop,0,0,0,false,false)(e,tp,eg,ep,ev,re,r,rp,g) then return end
	local xyzg=Duel.GetMatchingGroup(c768.xyzfilter,tp,LOCATION_EXTRA,0,g,g,e)
	if xyzg:GetCount()>0 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local xyz=xyzg:Select(tp,1,1,nil):GetFirst()
		local xcount=xyz.minxyzct
		if e:IsHasType(EFFECT_TYPE_ACTIVATE) and g:IsExists(Card.IsCode,1,nil,47198668) then
			xcount=xcount-1
			local e2=Effect.CreateEffect(c)
			e2:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_IGNORE_IMMUNE)
			e2:SetType(EFFECT_TYPE_SINGLE)
			e2:SetCode(511002116)
			e2:SetReset(RESET_CHAIN)
			c:RegisterEffect(e2,false,6)
		end
		Duel.XyzSummon(tp,xyz,g)
	end
end
function c768.disop(e,tp,eg,ep,ev,re,r,rp,tc)
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_DISABLE)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	tc:RegisterEffect(e1)
	local e2=e1:Clone()
	e2:SetCode(EFFECT_DISABLE_EFFECT)
	tc:RegisterEffect(e2)
end
