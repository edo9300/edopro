--Gorlag
function c140000009.initial_effect(c)
	--atk/def
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCode(EFFECT_UPDATE_ATTACK)
	e1:SetValue(c140000009.val)
	c:RegisterEffect(e1)
        --Special Summon
        local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(3534077,0))
	e2:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e2:SetCode(EVENT_BATTLE_DESTROYING)
	e2:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
        e2:SetCondition(c140000009.spcon)
	e2:SetTarget(c140000009.sptg)
	e2:SetOperation(c140000009.spop)
	c:RegisterEffect(e2)
        --Destroy Summoned Monsters
        local de=Effect.CreateEffect(c)
	de:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	de:SetCode(EVENT_LEAVE_FIELD)
	de:SetOperation(c140000009.desop)
	c:RegisterEffect(de)
        --Cannot Direct Attack
        local e3=Effect.CreateEffect(c)
        e3:SetType(EFFECT_TYPE_SINGLE)
        e3:SetCode(EFFECT_CANNOT_DIRECT_ATTACK)
        c:RegisterEffect(e3)
end
function c140000009.val(e,c)
	return Duel.GetMatchingGroupCount(c140000009.atkfilter,c:GetControler(),LOCATION_MZONE,LOCATION_MZONE,nil)*500
end
function c140000009.atkfilter(c)
        return c:IsAttribute(ATTRIBUTE_FIRE) and c:IsFaceup()
end
function c140000009.spcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local bc=c:GetBattleTarget()
	return c:IsRelateToBattle() and bc:IsLocation(LOCATION_GRAVE) and bc:IsType(TYPE_MONSTER)
end
function c140000009.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	local tc=e:GetLabelObject()
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and tc:IsCanBeSpecialSummoned(e,0,tp,false,false) and not tc:IsHasEffect(EFFECT_NECRO_VALLEY) end
	tc:CreateEffectRelation(e)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,tc,1,0,LOCATION_GRAVE)
end
function c140000009.spop(e,tp,eg,ep,ev,re,r,rp)
	local tc=e:GetLabelObject()
      local c=e:GetHandler()
      if Duel.GetLocationCount(tp,LOCATION_MZONE)==0 then return end
	if tc:IsRelateToEffect(e) and Duel.SpecialSummonStep(tc,0,tp,tp,false,false,POS_FACEUP_ATTACK) then
                if c:IsFaceup() and c:IsRelateToEffect(e) then c:SetCardTarget(tc) end
                --NonMaterial/Release
                local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_CANNOT_BE_SYNCHRO_MATERIAL)
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
		e1:SetValue(1)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
                local e2=e1:Clone()
                e2:SetCode(EFFECT_CANNOT_BE_XYZ_MATERIAL)
                tc:RegisterEffect(e2)
                local e5=e2:Clone()
                e5:SetCode(EFFECT_CANNOT_BE_FUSION_MATERIAL)
                tc:RegisterEffect(e5)
                local e3=e2:Clone()
                e3:SetCode(EFFECT_UNRELEASABLE_SUM)
                tc:RegisterEffect(e3)
                local e4=e2:Clone()
                e4:SetCode(EFFECT_UNRELEASABLE_NONSUM)
                tc:RegisterEffect(e4)
                --Change ATK/Attribute
                local e6=Effect.CreateEffect(e:GetHandler())
                e6:SetType(EFFECT_TYPE_SINGLE)
                e6:SetCode(EFFECT_SET_ATTACK)
                e6:SetValue(tc:GetBaseAttack()/2)
                e6:SetReset(RESET_EVENT+0xfe0000)
                tc:RegisterEffect(e6)
                local e7=e6:Clone()
                e7:SetCode(EFFECT_CHANGE_ATTRIBUTE)
                e7:SetValue(ATTRIBUTE_FIRE)
        	tc:RegisterEffect(e7)
                --Effect Negation
                local ee1=Effect.CreateEffect(e:GetHandler())
		ee1:SetType(EFFECT_TYPE_SINGLE)
		ee1:SetCode(EFFECT_DISABLE)
		ee1:SetReset(RESET_EVENT+0xfe0000)
		tc:RegisterEffect(ee1,true)
		local ee2=Effect.CreateEffect(e:GetHandler())
		ee2:SetType(EFFECT_TYPE_SINGLE)
		ee2:SetCode(EFFECT_DISABLE_EFFECT)
		ee2:SetReset(RESET_EVENT+0xfe0000)
		tc:RegisterEffect(ee2,true)
                --Cannot Change posistion
                local e8=Effect.CreateEffect(e:GetHandler())
		e8:SetType(EFFECT_TYPE_SINGLE)
		e8:SetCode(EFFECT_CANNOT_CHANGE_POSITION)
		e8:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e8)
                Duel.SpecialSummonComplete()
                --Cannot Attack this turn
                local e9=Effect.CreateEffect(e:GetHandler())
		e9:SetType(EFFECT_TYPE_SINGLE)
		e9:SetCode(EFFECT_CANNOT_ATTACK)
		e9:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e9)
	end
end
function c140000009.filter(c,rc)
        return rc:GetCardTarget():IsContains(c)
end
function c140000009.desop(e,tp,eg,ep,ev,re,r,rp)
        local c=e:GetHandler()
        if c:GetCardTargetCount()>0 then
		local dg=Duel.GetMatchingGroup(c140000009.filter,tp,LOCATION_MZONE,LOCATION_MZONE,nil,c)
		Duel.Destroy(dg,REASON_EFFECT)
	end
end
