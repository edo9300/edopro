--地縛囚人 線巡人 (K)
function c633.initial_effect(c)
	local e2=Effect.CreateEffect(c)
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetType(EFFECT_TYPE_IGNITION)
	e2:SetRange(LOCATION_GRAVE)
	e2:SetCost(c633.damcost)
	e2:SetTarget(c633.atktg)
	e2:SetOperation(c633.damop)
	c:RegisterEffect(e2)   
end

function c633.damcost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsAbleToRemoveAsCost() end
	Duel.Remove(e:GetHandler(),POS_FACEUP,REASON_COST)
end
function c633.atkfilter(c)
	return c:IsFaceup() and c:IsPreviousLocation(LOCATION_EXTRA) and c:GetFlagEffect(633)==0
end
function c633.atktg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(1-tp) and c633.atkfilter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c633.atkfilter,tp,0,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	Duel.SelectTarget(tp,c633.atkfilter,tp,0,LOCATION_MZONE,1,1,nil)
end
function c633.damop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc and tc:IsRelateToEffect(e) and tc:IsFaceup() then
		Duel.RaiseEvent(tc,EVENT_SPSUMMON_SUCCESS,e,0,tp,tp,0)
		tc:RegisterFlagEffect(633,RESET_EVENT+0x1fe0000,nil,1)
	end
end


