--Rank Revolution
function c11370094.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(TIMING_DAMAGE_STEP)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_DAMAGE_STEP)
	e1:SetCondition(c11370094.condition)
	e1:SetTarget(c11370094.target)
	e1:SetOperation(c11370094.operation)
	c:RegisterEffect(e1)
end

function c11370094.condition(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetCurrentPhase()==PHASE_DAMAGE and Duel.IsDamageCalculated() then return false end
	local g=Duel.GetFieldGroup(tp,LOCATION_MZONE,0)
	local tc=g:GetFirst()
	e:SetLabelObject(tc)
	return g:GetCount()==1 and tc:IsFaceup() and tc:IsType(TYPE_XYZ)
end
function c11370094.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return false end
	if chk==0 then return e:GetLabelObject():IsCanBeEffectTarget(e) end
	Duel.SetTargetCard(e:GetLabelObject())
end
function c11370094.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not c:IsLocation(LOCATION_SZONE) then return end
	local tc=e:GetLabelObject()
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_FIELD)
		e1:SetRange(LOCATION_SZONE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
		e1:SetTarget(c11370094.atktg)
            e1:SetLabelObject(tc)
            e1:SetReset(RESET_EVENT+0x1fe0000)
		c:RegisterEffect(e1)
            local e12=e1:Clone()
		e12:SetCode(EFFECT_DISABLE_EFFECT)
		c:RegisterEffect(e12)
		--local e2=Effect.CreateEffect(c)
            --e2:SetProperty(EFFECT_FLAG_SINGLE_RANGE+EFFECT_FLAG_OWNER_RELATE)
		--e2:SetType(EFFECT_TYPE_SINGLE)
		--e2:SetCode(EFFECT_CANNOT_BE_BATTLE_TARGET)
	      --e2:SetCondition(c11370094.atkcon)
		--e2:SetValue(1)
            --e2:SetReset(RESET_EVENT+0x1fe0000)
		--c:RegisterEffect(e2)
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_FIELD)
		e2:SetCode(EFFECT_CANNOT_ATTACK_ANNOUNCE)
		e2:SetRange(LOCATION_SZONE)
		e2:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
		e2:SetTarget(c11370094.atktg)
            e2:SetLabelObject(tc)
		e2:SetValue(1)
            e2:SetReset(RESET_EVENT+0x1fe0000)
		c:RegisterEffect(e2)
	      --Destroy
	      local e3=Effect.CreateEffect(c)
	      e3:SetType(EFFECT_TYPE_CONTINUOUS+EFFECT_TYPE_FIELD)
	      e3:SetRange(LOCATION_SZONE)
	      e3:SetCode(EVENT_LEAVE_FIELD)
            e3:SetLabelObject(tc)
	      e3:SetCondition(c11370094.descon2)
	      e3:SetOperation(c11370094.desop2)
            e3:SetReset(RESET_EVENT+0x1fe0000)
	      c:RegisterEffect(e3)
end
function c11370094.atktg(e,c)
      local tc=e:GetLabelObject()
	local rk=tc:GetRank()
	return c:GetRank()>rk or c:GetLevel()>rk
end
function c11370094.atkcon(e,tp,eg,ep,ev,re,r,rp)
      local atker=e:GetHandler():GetBattleTarget()
      local rk=e:GetHandler():GetRank()
	return atker and (atker:GetRank()>rk or atker:GetLevel()>rk)
end
function c11370094.descon2(e,tp,eg,ep,ev,re,r,rp)
      local tc=e:GetLabelObject()
	return tc and eg:IsContains(tc) 
end
function c11370094.desop2(e,tp,eg,ep,ev,re,r,rp)
	Duel.Destroy(e:GetHandler(),REASON_EFFECT)
end
function c11370094.desop(e,tp,eg,ep,ev,re,r,rp)
	e:GetLabelObject():Reset()
	--e:Reset()
end
