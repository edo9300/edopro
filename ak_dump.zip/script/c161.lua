--King 之變換
function c161.initial_effect(c)
	
	  local e1=Effect.CreateEffect(c)
	  e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_CARD_TARGET)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_TODECK+CATEGORY_COUNTER)
	  e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCondition(c161.condition)
	  e1:SetCost(c161.cost)
	  e1:SetTarget(c161.target)
	e1:SetOperation(c161.activate)
	c:RegisterEffect(e1)
end

function c161.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetFlagEffect(tp,161)==0
end
function c161.cofilter(c)
	return c:GetFlagEffect(159)~=0 
end
function c161.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.PayLPCost(tp,Duel.GetLP(tp)/2)
end
function c161.scofilter(c)
	return c:IsCode(159) and c:IsFaceup()
end
function c161.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local c=e:GetHandler()
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(tp) and chkc:IsCode(159) and chkc:IsFaceup() end
	if chk==0 then return Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_MZONE,0,1,nil,159) 
	and not Duel.IsPlayerAffectedByEffect(tp,59822133) and Duel.GetLocationCountFromEx(tp,tp,c)>0 end
	local ttg=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE,0,nil,159) 
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TODECK)
	local g=Duel.SelectTarget(tp,c161.scofilter,tp,LOCATION_MZONE,0,1,1,nil)
	local tc=g:GetFirst()   
	local counter1=tc:GetCounter(0x81)
	local counter2=tc:GetCounter(0x82)
	local counter3=tc:GetCounter(0x83)
	local counter4=tc:GetCounter(0x84)
	Duel.SetOperationInfo(0,CATEGORY_TODECK,g,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,0) 
	Duel.SetOperationInfo(0,CATEGORY_COUNTER,nil,counter1,0,0x81)
	Duel.SetOperationInfo(0,CATEGORY_COUNTER,nil,counter2,0,0x82)
	Duel.SetOperationInfo(0,CATEGORY_COUNTER,nil,counter3,0,0x83)
	Duel.SetOperationInfo(0,CATEGORY_COUNTER,nil,counter4,0,0x84)
end
function c161.activate(e,tp,eg,ep,ev,re,r,rp)
	  local c=e:GetHandler()
	  local tc=Duel.GetFirstTarget()  
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then return end	 
	  if tc==nil then return end
	  local counter1=tc:GetCounter(0x81)
	  local counter2=tc:GetCounter(0x82)
	  local counter3=tc:GetCounter(0x83)
	  local counter4=tc:GetCounter(0x84)
	  Duel.SendtoDeck(tc,tp,nil,REASON_RULE)
	  if Duel.GetLocationCountFromEx(tp)<1 then return end
	  local g=Duel.GetMatchingGroup(c161.cofilter,tp,LOCATION_ONFIELD+LOCATION_HAND+LOCATION_DECK+LOCATION_EXTRA+LOCATION_GRAVE+LOCATION_REMOVED,LOCATION_ONFIELD+LOCATION_HAND+LOCATION_DECK+LOCATION_EXTRA+LOCATION_GRAVE+LOCATION_REMOVED,nil)
	  if g:GetCount()==0 then return end  
	  local opt=0
	  if couter1==0 and counter2==0 and counter3==0 and counter4==0 then return end
	  if counter1>0 then
	  opt=Duel.SelectOption(tp,aux.Stringid(13715,4),aux.Stringid(13715,2),aux.Stringid(13715,3)) 
	  opt=opt+1 end
	  if counter2>0 then
	  opt=Duel.SelectOption(tp,aux.Stringid(13715,15),aux.Stringid(13715,2),aux.Stringid(13715,3))
	  if opt>0 then opt=opt+1 end end
	  if counter3>0 then
	  opt=Duel.SelectOption(tp,aux.Stringid(13715,15),aux.Stringid(13715,4),aux.Stringid(13715,3)) 
	  if opt==2 then opt=3 end end
	  if counter4>0 then
	  opt=Duel.SelectOption(tp,aux.Stringid(13715,15),aux.Stringid(13715,4),aux.Stringid(13715,2)) end
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	  if Duel.SpecialSummon(g,0,tp,tp,true,true,POS_FACEUP)==0 then return end
	  Duel.BreakEffect() 
	  if not Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_EXTRA,0,1,nil,159) then return end
	  local ttg=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_EXTRA,0,nil,159) 
	  local tc=ttg:GetFirst()  

	  if opt==0 then
	  tc:SetMaterial(g)
	  if Duel.SendtoGrave(g,REASON_MATERIAL+REASON_RITUAL)>0 then
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON) 
	  local ttg2=ttg:FilterSelect(tp,Card.IsCode,1,1,nil,159)
	  local tc=ttg2:GetFirst()
	  Duel.SpecialSummon(tc,SUMMON_TYPE_RITUAL,tp,tp,true,false,POS_FACEUP)
	  Duel.SpecialSummonComplete()
	  tc:CompleteProcedure()
	  if counter2~=0 then
	  tc:AddCounter(0x81,counter2) end
	  if counter3~=0 then
	  tc:AddCounter(0x81,counter3) end
	  if counter4~=0 then
	  tc:AddCounter(0x81,counter4) end
	  end end

	  if opt==1 then	  
	  tc:SetMaterial(g)
	  if Duel.SendtoGrave(g,REASON_MATERIAL+REASON_FUSION)>0 then
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON) 
	  local ttg2=ttg:FilterSelect(tp,Card.IsCode,1,1,nil,159)
	  local tc=ttg2:GetFirst()
	  Duel.SpecialSummon(tc,SUMMON_TYPE_FUSION+0x11,tp,tp,true,false,POS_FACEUP)
	  Duel.SpecialSummonComplete()
	  tc:CompleteProcedure()
	  if counter1~=0 then
	  tc:AddCounter(0x82,counter1) end
	  if counter3~=0 then
	  tc:AddCounter(0x82,counter3) end
	  if counter4~=0 then
	  tc:AddCounter(0x82,counter4) end
	  end end  

	  if opt==2 then 
	  tc:SetMaterial(g)
	  if Duel.SendtoGrave(g,REASON_MATERIAL+REASON_SYNCHRO)>0 then
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON) 
	  local ttg2=ttg:FilterSelect(tp,Card.IsCode,1,1,nil,159)
	  local tc=ttg2:GetFirst()
	  Duel.SpecialSummon(tc,SUMMON_TYPE_SYNCHRO,tp,tp,true,false,POS_FACEUP)
	  Duel.SpecialSummonComplete()
	  tc:CompleteProcedure()
	  if counter1~=0 then
	  tc:AddCounter(0x83,counter1) end
	  if counter2~=0 then
	  tc:AddCounter(0x83,counter2) end
	  if counter4~=0 then
	  tc:AddCounter(0x83,counter4) end
	  end end

	  if opt==3 then 
	  local ag=g
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	  local ttg2=ttg:FilterSelect(tp,Card.IsCode,1,1,nil,159)
	  local tc=ttg2:GetFirst()
	  local tc2=g:GetFirst()
	  while tc2 do
	  local ttc=tc2:GetOverlayGroup()
	  if ttc~=nil then
	  local btc=ttc:GetFirst()
	  while btc do
	  Duel.Overlay(tc,btc)
	  ag:Merge(btc)
	  btc=ttc:GetNext() end end
	  tc2=g:GetNext() end
	  tc2=g:GetFirst()
	  while tc2 do
	  Duel.Overlay(tc,tc2)
	  tc2=g:GetNext() end
	  tc:SetMaterial(ag)
	  Duel.SpecialSummon(tc,SUMMON_TYPE_XYZ,tp,tp,true,false,POS_FACEUP)
	  Duel.SpecialSummonComplete()
	  tc:CompleteProcedure()
	  if counter1~=0 then
	  tc:AddCounter(0x84,counter1) end
	  if counter2~=0 then
	  tc:AddCounter(0x84,counter2) end
	  if counter3~=0 then
	  tc:AddCounter(0x84,counter3) end
	  end
	  Duel.RegisterFlagEffect(tp,161,0,0,1)
end
