--Fire Whip
function c140000012.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c140000012.target)
	e1:SetOperation(c140000012.activate)
	c:RegisterEffect(e1)
end
function c140000012.filter(c,e,tp,tid)
	return bit.band(c:GetReason(),0x41)==0x41 and c:GetTurnID()==tid
		and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
end
function c140000012.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local tid=Duel.GetTurnCount()
	if chkc then return chkc:IsLocation(LOCATION_GRAVE) and c140000012.filter(chkc,e,tp,tid) end
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and Duel.IsExistingTarget(c140000012.filter,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,nil,e,tp,tid) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectTarget(tp,c140000012.filter,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,1,nil,e,tp,tid)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,g,1,0,0)
end
function c140000012.activate(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) then
		Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP_ATTACK)
                local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_CANNOT_BE_SYNCHRO_MATERIAL)
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
		e1:SetValue(1)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
                local e2=e1:Clone()
                e2:SetCode(EFFECT_CANNOT_BE_XYZ_MATERIAL)
                tc:RegisterEffect(e2)
                local e5=e2:Clone()
                e5:SetCode(EFFECT_CANNOT_BE_FUSION_MATERIAL)
                tc:RegisterEffect(e5)
                local e3=e2:Clone()
                e3:SetCode(EFFECT_UNRELEASABLE_SUM)
                tc:RegisterEffect(e3)
                local e4=e2:Clone()
                e4:SetCode(EFFECT_UNRELEASABLE_NONSUM)
                tc:RegisterEffect(e4)
                --Change ATK/Attribute
                local e6=Effect.CreateEffect(e:GetHandler())
                e6:SetType(EFFECT_TYPE_SINGLE)
                e6:SetCode(EFFECT_SET_ATTACK)
                e6:SetValue(tc:GetBaseAttack()/2)
                e6:SetReset(RESET_EVENT+0xfe0000)
                tc:RegisterEffect(e6)
                local e7=e6:Clone()
                e7:SetCode(EFFECT_CHANGE_ATTRIBUTE)
                e7:SetValue(ATTRIBUTE_FIRE)
        	tc:RegisterEffect(e7)
                --Effect Negation
                local ee1=Effect.CreateEffect(e:GetHandler())
		ee1:SetType(EFFECT_TYPE_SINGLE)
		ee1:SetCode(EFFECT_DISABLE)
		ee1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(ee1,true)
		local ee2=Effect.CreateEffect(e:GetHandler())
		ee2:SetType(EFFECT_TYPE_SINGLE)
		ee2:SetCode(EFFECT_DISABLE_EFFECT)
		ee2:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(ee2,true)
                --Cannot Change posistion
                local e8=Effect.CreateEffect(e:GetHandler())
		e8:SetType(EFFECT_TYPE_SINGLE)
		e8:SetCode(EFFECT_CANNOT_CHANGE_POSITION)
		e8:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e8)
                Duel.SpecialSummonComplete()
	end
end
