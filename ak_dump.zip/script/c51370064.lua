--Persona Shutter Layer 1
function c51370064.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c51370064.target)
	e1:SetOperation(c51370064.activate)
	c:RegisterEffect(e1)

	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_CONTINUOUS+EFFECT_TYPE_FIELD)
	e3:SetRange(LOCATION_MZONE+LOCATION_SZONE)
	e3:SetCode(EVENT_LEAVE_FIELD)
	e3:SetCondition(c51370064.descon2)
	e3:SetOperation(c51370064.desop2)
	c:RegisterEffect(e3)
end

function c51370064.filter(c,tp)
	return c:IsFaceup() and c:GetLevel()>0
	  and Duel.IsPlayerCanSpecialSummonMonster(tp,51370064,0,0,c:GetBaseAttack(),c:GetBaseDefense(),c:GetOriginalLevel(),c:GetOriginalRace(),c:GetOriginalAttribute())
end
function c51370064.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chkc then return chkc:IsControler(1-tp) and chkc:IsLocation(LOCATION_MZONE) and c51370064.filter(chkc,tp) end
	if chk==0 then return Duel.IsExistingTarget(c51370064.filter,tp,0,LOCATION_MZONE,1,nil,tp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	local g=Duel.SelectTarget(tp,c51370064.filter,tp,0,LOCATION_MZONE,1,1,nil,tp)
end
function c51370064.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0
		or not Duel.IsPlayerCanSpecialSummonMonster(tp,51370064,0,0,tc:GetBaseAttack(),tc:GetBaseDefense(),tc:GetOriginalLevel(),tc:GetOriginalRace(),tc:GetOriginalAttribute()) then return end
	c:AddMonsterAttribute(TYPE_NORMAL+TYPE_TRAP,tc:GetOriginalAttribute(),tc:GetOriginalRace(),tc:GetOriginalLevel(),tc:GetBaseAttack(),tc:GetBaseDefense())
	Duel.SpecialSummonStep(c,0,tp,tp,true,false,POS_FACEUP)
	--c:AddMonsterAttributeComplete()
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_CHANGE_CODE)
	e1:SetValue(tc:GetOriginalCode())
	e1:SetReset(RESET_EVENT+0x1fe0000)
	c:RegisterEffect(e1,true)
	c:SetCardTarget(tc)
	c:CreateRelation(tc,RESET_EVENT+0x1fe0000)
	Duel.SpecialSummonComplete()	
end

function c51370064.descon2(e,tp,eg,ep,ev,re,r,rp)
	local tc=e:GetHandler():GetFirstCardTarget()
	return tc and eg:IsContains(tc) 
end
function c51370064.desop2(e,tp,eg,ep,ev,re,r,rp)
	Duel.Destroy(e:GetHandler(),REASON_EFFECT)
end
