--CCC Water Sword the Embodiment of Valiant Fused Arms
function c536.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcCodeFun(c,51370066,c536.filter,1,true,true)

	local e3=Effect.CreateEffect(c)
	e3:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)	  
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e3:SetCode(EVENT_SPSUMMON_SUCCESS)
	e3:SetOperation(c536.atkop2)
	--c:RegisterEffect(e3)

	--adup
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_DELAY)
	  e1:SetCategory(CATEGORY_ATKCHANGE)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e1:SetCode(EVENT_ATTACK_ANNOUNCE)
	e1:SetTarget(c536.atktg)
	e1:SetOperation(c536.atkop)
	c:RegisterEffect(e1)
end
c536.material_setcode=0x913

function c536.filter(c,fc)
	local attr=c:IsAttribute(ATTRIBUTE_FIRE)
	if Card.IsFusionAttribute then
		attr=c:IsFusionAttribute(ATTRIBUTE_FIRE,fc)
	end
	return attr and (c:GetLevel()==5 or c:GetLevel()==6)
end

function c536.filter2(c)
	return not c:IsCode(51370066)
end
function c536.atkop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	  if not c:GetSummonType()==SUMMON_TYPE_FUSION then return end
	local gg=c:GetMaterial()
	  local g=gg:Filter(c536.filter2,nil)
	local tc=g:GetFirst()
	  local att=tc:GetOriginalAttribute()
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_CHANGE_ATTRIBUTE)
	e1:SetValue(att)  
	e1:SetReset(RESET_EVENT+EVENT_TO_DECK) 
	  c:RegisterEffect(e1) 
end

function c536.filter3(c,att)
	return c:IsFaceup() and c:GetAttribute()==att and c:GetAttack()>0
end
function c536.atktg(e,tp,eg,ep,ev,re,r,rp,chk)
	  local att=ATTRIBUTE_FIRE
	if chk==0 then return Duel.IsExistingMatchingCard(c536.filter3,tp,LOCATION_MZONE,LOCATION_MZONE,1,e:GetHandler(),att) end
end
function c536.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	  local att=ATTRIBUTE_FIRE
	if c:IsFaceup() and c:IsRelateToEffect(e) then
		local g=Duel.GetMatchingGroup(c536.filter3,tp,LOCATION_MZONE,LOCATION_MZONE,c,att)
		local tatk=0
			local tc=g:GetFirst()
			while tc do
			local atk=tc:GetAttack()
			tatk=tatk+atk
			tc=g:GetNext() end
		if tatk>0 then
			local e1=Effect.CreateEffect(c)
			e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetCode(EFFECT_UPDATE_ATTACK)
			e1:SetValue(tatk)
			e1:SetReset(RESET_EVENT+0x1ff0000)
			c:RegisterEffect(e1)
		end
	end
end
