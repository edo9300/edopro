--Impact Revive
function c140000124.initial_effect(c)
		--Special Summon
		local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_DRAW)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_BATTLE_DESTROYED)
	e1:SetTarget(c140000124.target)
	e1:SetOperation(c140000124.activate)
	c:RegisterEffect(e1)
end
function c140000124.target(e,tp,eg,ep,ev,re,r,rp,chk)
		local tc=eg:GetFirst()
	if chk==0 then return Duel.GetLocationCount(1-tp,LOCATION_MZONE)>0 and eg:GetCount()==1
		and tc:IsLocation(LOCATION_GRAVE) and tc:IsReason(REASON_BATTLE)
		and tc:IsCanBeSpecialSummoned(e,0,tp,false,false,POS_FACEUP_ATTACK,1-tp) and not tc:IsHasEffect(EFFECT_NECRO_VALLEY)
				and tc:GetControler()==1-tp end
	tc:CreateEffectRelation(e)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,eg,1,0,0)
end
function c140000124.tar(c)
		return c:IsFaceup() and c:IsChainAttackable()
end
function c140000124.activate(e,tp,eg,ep,ev,re,r,rp)
	local tc=eg:GetFirst()
	if not tc:IsRelateToEffect(e) then return end
		if Duel.SpecialSummonStep(tc,0,tp,1-tp,false,false,POS_FACEUP_ATTACK) then
				local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(500)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1,true)
		Duel.SpecialSummonComplete()
				local g=Duel.SelectMatchingCard(tp,c140000124.tar,tp,LOCATION_MZONE,0,1,1,nil)
				local at=g:GetFirst()
				if at then
					local e2=Effect.CreateEffect(e:GetHandler())
					e2:SetType(EFFECT_TYPE_SINGLE)
					e2:SetCode(EFFECT_EXTRA_ATTACK)
					e2:SetValue(1)
					e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
					at:RegisterEffect(e2)
				end
	end
end
