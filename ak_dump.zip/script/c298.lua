--RR－ライズ・ファルコン
function c298.initial_effect(c)
	--xyz summon
	Xyz.AddProcedure(c,aux.FilterBoolFunction(Card.IsRace,RACE_WINDBEAST),4,3)
	c:EnableReviveLimit()

	--cannot attack
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetRange(LOCATION_MZONE)
	e3:SetTargetRange(0,LOCATION_MZONE)
	e3:SetCode(EFFECT_CANNOT_BE_BATTLE_TARGET)
	e3:SetTarget(c298.tga)
	e3:SetValue(c298.vala)
	c:RegisterEffect(e3)

	--cannot attack
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_ATTACK_ALL)
	e1:SetValue(c298.atkfilter)
	c:RegisterEffect(e1)

	--atk
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(73887236,0))
	  e2:SetCategory(CATEGORY_ATKCHANGE)
	e2:SetType(EFFECT_TYPE_IGNITION)
	e2:SetRange(LOCATION_MZONE)
	--e2:SetProperty(0)   
	e2:SetCountLimit(1)
	e2:SetCost(c298.cost)
	e2:SetTarget(c298.target)
	e2:SetOperation(c298.operation)
	c:RegisterEffect(e2,false,1)
end

function c298.atkfilter(e,c)
	return bit.band(c:GetSummonType(),SUMMON_TYPE_SPECIAL)==SUMMON_TYPE_SPECIAL
end

function c298.atkfilter2(c)
	return bit.band(c:GetSummonType(),SUMMON_TYPE_SPECIAL)~=SUMMON_TYPE_SPECIAL
end
function c298.tga(e,c)
	return bit.band(c:GetSummonType(),SUMMON_TYPE_SPECIAL)~=SUMMON_TYPE_SPECIAL
--Duel.IsExistingMatchingCard(c298.atkfilter2,e:GetHandler():GetControler(),0,LOCATION_MZONE,1,nil)
end
function c298.vala(e,c)
	return c==e:GetHandler()
end

function c298.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():CheckRemoveOverlayCard(tp,1,REASON_COST) end
	e:GetHandler():RemoveOverlayCard(tp,1,1,REASON_COST)
end
function c298.filter(c)
	return c:IsFaceup() and c:GetAttack()>0
		and bit.band(c:GetSummonType(),SUMMON_TYPE_SPECIAL)==SUMMON_TYPE_SPECIAL
end
function c298.target(e,tp,eg,ep,ev,re,r,rp,chk)
	--if chkc then return chkc:IsControler(1-tp) and chkc:IsLocation(LOCATION_MZONE) and c298.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c298.filter,tp,0,LOCATION_MZONE,1,nil) end
	--Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	--Duel.SelectTarget(tp,c298.filter,tp,0,LOCATION_MZONE,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_ATKCHANGE,e:GetHandler(),1,0,0)
end
function c298.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_UPDATE_ATTACK)
	e1:SetValue(c298.tatk)
	e1:SetReset(RESET_EVENT+0x1ff0000+RESET_PHASE+PHASE_END)
	c:RegisterEffect(e1)
end
function c298.tatk(e,c)
	local g=Duel.GetMatchingGroup(c298.filter,e:GetHandlerPlayer(),0,LOCATION_MZONE,nil)
	local tc=g:GetFirst()
	local tatk=0
	while tc do
	local atk=tc:GetAttack()
	if atk<0 then atk=0 end
	tatk=tatk+atk
	tc=g:GetNext() end
	return tatk
end