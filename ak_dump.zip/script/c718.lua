function c718.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCategory(CATEGORY_HANDES+CATEGORY_DAMAGE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCondition(c718.condition) 
	e1:SetTarget(c718.target)   
	e1:SetOperation(c718.operation)
	c:RegisterEffect(e1)
end

function c718.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.IsExistingMatchingCard(c718.filter30,tp,LOCATION_MZONE,0,1,nil)
end
function c718.filter30(c)
	return c:IsFaceup() and c:IsSetCard(0xf8) 
end
function c718.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetFieldGroupCount(tp,0,LOCATION_HAND)>0 end
	local count1=Duel.GetMatchingGroupCount(c718.filter30,tp,LOCATION_MZONE,0,nil)
	local count2=Duel.GetFieldGroupCount(tp,0,LOCATION_HAND)
	if count1>count2 then count1=count2 end
	Duel.SetOperationInfo(0,CATEGORY_HANDES,nil,0,1-tp,count1)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,count1*300)  
end
function c718.operation(e,tp,eg,ep,ev,re,r,rp)
	local count1=Duel.GetMatchingGroupCount(c718.filter30,tp,LOCATION_ONFIELD,0,e:GetHandler())
	local count2=Duel.GetFieldGroupCount(tp,0,LOCATION_HAND)
	if count1<1 or count2<1 then return end
	if count1>count2 then count1=count2 end
	local a=Duel.GetFieldGroup(tp,0,LOCATION_HAND)
	Duel.ConfirmCards(tp,a)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TOGRAVE)
	local n=Duel.SelectMatchingCard(tp,nil,1-tp,LOCATION_HAND,0,count1,count1,nil)
	Duel.SendtoGrave(n,REASON_EFFECT+REASON_DISCARD)
	local g=Duel.GetOperatedGroup()
	Duel.BreakEffect()
	if g:GetCount()<1 then return end
	local g2=g:Filter(Card.IsLocation,nil,LOCATION_GRAVE)
	if g2:GetCount()<1 then return end  
	Duel.Damage(1-tp,g2:GetCount()*300,REASON_EFFECT)
end 