--超越融合
--Transcendental Polymerization
function c704.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(100912052,0))
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_FUSION_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCost(c704.cost)
	e1:SetTarget(c704.target)
	e1:SetOperation(c704.activate)
	c:RegisterEffect(e1)
end

function c704.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.CheckLPCost(tp,1000) end
	Duel.PayLPCost(tp,1000)
	local e2=Effect.CreateEffect(e:GetHandler())
	e2:SetProperty(EFFECT_FLAG_OATH)	
	e2:SetCategory(CATEGORY_DAMAGE+CATEGORY_DESTROY)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e2:SetCode(EVENT_PHASE+PHASE_END)
	e2:SetCountLimit(1) 
	e2:SetTarget(c704.destg)
	e2:SetOperation(c704.desop)
	e2:SetReset(RESET_PHASE+PHASE_END)
	Duel.RegisterEffect(e2,tp)   
end
function c704.destg(e,tp,eg,ep,ev,re,r,rp,chk)
	local g=Duel.GetMatchingGroup(c704.des,tp,0xff,0xff,nil)
	if chk==0 then return g:GetCount()>0 end
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,g:GetCount(),0,0)
end
function c704.des(c)
	return c:GetFlagEffect(704)~=0
end
function c704.desop(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetMatchingGroup(c704.des,tp,0xff,0xff,nil)
	if g:GetCount()==0 then return end
	local g2=Duel.GetMatchingGroup(aux.TRUE,tp,LOCATION_MZONE,0,nil)
	Duel.Destroy(g2,REASON_EFFECT)
	local ag=Duel.GetOperatedGroup()
	if ag:GetCount()==0 then return end 
	local tc=ag:GetFirst()
	local tatk=0
	while tc do
	local atk=tc:GetPreviousAttackOnField()
	tatk=tatk+atk
	tc=ag:GetNext() end
	Duel.Damage(tp,tatk,REASON_EFFECT)
end

function c704.fcheck(tp,sg,fc)
	return #sg==2
end
function c704.filter1(c,e)
	return c:IsOnField() and not c:IsImmuneToEffect(e)
end
function c704.filter2(c,e,tp,m,f,chkf)
	return c:IsType(TYPE_FUSION) and (not f or f(c))
		and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_FUSION,tp,false,false) and c:CheckFusionMaterial(m,nil,chkf)
end
function c704.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then
		local chkf=tp
		local mg1=Duel.GetFusionMaterial(tp):Filter(Card.IsOnField,nil)
		local res=Duel.IsExistingMatchingCard(c704.filter2,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg1,nil,chkf)
		if not res then
			local ce=Duel.GetChainMaterial(tp)
			if ce~=nil then
				local fgroup=ce:GetTarget()
				local mg2=fgroup(ce,e,tp)
				local mf=ce:GetValue()
				res=Duel.IsExistingMatchingCard(c704.filter2,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg2,mf,chkf)
			end
		end
		return res 
	end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
	if e:IsHasType(EFFECT_TYPE_ACTIVATE) then
		Duel.SetChainLimit(aux.FALSE)
	end
end
function c704.filter3(c,e,tp,mg)
	return c:IsCanBeFusionMaterial()
		and Duel.IsExistingMatchingCard(c704.filter2,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg)
end
function c704.filter5(c,e,tp)
	return not c:IsHasEffect(EFFECT_NECRO_VALLEY) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsType(TYPE_TOKEN)
end
function c704.activate(e,tp,eg,ep,ev,re,r,rp)
	local chkf=tp
	local mg1=Duel.GetFusionMaterial(tp):Filter(c704.filter1,nil,e)
	local sg1=Duel.GetMatchingGroup(c704.filter2,tp,LOCATION_EXTRA,0,nil,e,tp,mg1,nil,chkf)
	local mg2=nil
	local sg2=nil
	local fg=nil
	local ce=Duel.GetChainMaterial(tp)
	if ce~=nil then
		local fgroup=ce:GetTarget()
		mg2=fgroup(ce,e,tp)
		local mf=ce:GetValue()
		sg2=Duel.GetMatchingGroup(c704.filter2,tp,LOCATION_EXTRA,0,nil,e,tp,mg2,mf,chkf)
	end
   if sg1:GetCount()>0 or (sg2~=nil and sg2:GetCount()>0) then
		local sg=sg1:Clone()
		if sg2 then sg:Merge(sg2) end
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local tg=sg:Select(tp,1,1,nil)
		local tc=tg:GetFirst()
		if sg1:IsContains(tc) and (sg2==nil or not sg2:IsContains(tc) or not Duel.SelectYesNo(tp,ce:GetDescription())) then
			local mat1=Duel.SelectFusionMaterial(tp,tc,mg1,nil,chkf)
			tc:SetMaterial(mat1)
			Duel.SendtoGrave(mat1,REASON_EFFECT+REASON_MATERIAL+REASON_FUSION)
			fg=mat1
			Duel.BreakEffect()
			Duel.SpecialSummon(tc,SUMMON_TYPE_FUSION,tp,tp,false,false,POS_FACEUP)
		else
			local mat2=Duel.SelectFusionMaterial(tp,tc,mg2,nil,chkf)
			local fop=ce:GetOperation()
			fg=mat2
			fop(ce,e,tp,tc,mat2)
		end

	local ac=fg:GetFirst()
	while ac do
	ac:RegisterFlagEffect(704,RESET_PHASE+PHASE_END,0,1)
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e1:SetCode(EVENT_BE_MATERIAL)
	e1:SetOperation(c704.activate2)
	e1:SetReset(RESET_PHASE+PHASE_END)
	ac:RegisterEffect(e1,true)  
	ac=fg:GetNext() end
		tc:CompleteProcedure()
	end
	Duel.BreakEffect()

	local ag=fg:Filter(c704.filter5,nil,e,tp)
	if ag:GetCount()<1 or Duel.GetLocationCount(tp,LOCATION_MZONE)<1 then return end
	if ag:GetCount()>1 and (Duel.IsPlayerAffectedByEffect(tp,59822133) or Duel.GetLocationCount(tp,LOCATION_MZONE)<2) then return end   
	local atc=ag:GetFirst()
	while atc do
	Duel.SpecialSummonStep(atc,0,tp,tp,false,false,POS_FACEUP_ATTACK)   
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_SET_ATTACK_FINAL)
	e1:SetValue(0)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	atc:RegisterEffect(e1,true) 
	atc=ag:GetNext() end
	Duel.SpecialSummonComplete()

	local ag2=ag:Filter(Card.IsLocation,nil,LOCATION_MZONE)
	local op=Duel.SelectOption(tp,aux.Stringid(26082117,0),aux.Stringid(8316661,0))
	if op==0 then
		local atc2=ag2:GetFirst()
		while atc2 do
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_CHANGE_LEVEL)
		e1:SetValue(4)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		atc2:RegisterEffect(e1,true)	
		atc2=ag2:GetNext() end end
	if op==1 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
		local atc3=ag2:Select(tp,1,1,nil):GetFirst()
		if not atc3:IsType(TYPE_TUNER) then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_ADD_TYPE)
		e1:SetValue(TYPE_TUNER)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		atc3:RegisterEffect(e1,true) end end
end
function c704.activate2(e,tp,eg,ep,ev,re,r,rp)
   if r==REASON_SYNCHRO or r==REASON_XYZ then
   e:GetHandler():ResetFlagEffect(704) end
end
function c704.lvfilter(c)
	return c:GetLevel()==4
end