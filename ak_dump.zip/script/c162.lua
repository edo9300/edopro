--King 之君臨儀式
function c162.initial_effect(c)
	c:EnableCounterPermit(0x81)
	
	  local e1=Effect.CreateEffect(c)
	  e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	  e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)	 
	  e1:SetTarget(c162.target)
	e1:SetOperation(c162.activate)
	c:RegisterEffect(e1)
end

function c162.target(e,tp,eg,ep,ev,re,r,rp,chk)
	  local g=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE+LOCATION_HAND,0,nil,46986414)
	  local g1=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE+LOCATION_HAND,0,nil,89943723)
	  local g2=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE+LOCATION_HAND,0,nil,44508094)
	  local g3=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE+LOCATION_HAND,0,nil,84013237)
	  if chk==0 then return g:GetCount()~=0  and g1:GetCount()~=0  and g2:GetCount()~=0  and g3:GetCount()~=0 and Duel.GetLocationCountFromEx(tp)>0 end
	  local ttg=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_EXTRA,0,nil,159) 
	  Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,ttg,ttg:GetCount(),0,0) 
end
function c162.scofilter(c)
	return c:IsCode(159) 
end
function c162.activate(e,tp,eg,ep,ev,re,r,rp)
	  local c=e:GetHandler()
	  local g=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE+LOCATION_HAND,0,nil,46986414)
	  local g1=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE+LOCATION_HAND,0,nil,89943723)
	  local g2=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE+LOCATION_HAND,0,nil,44508094)
	  local g3=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE+LOCATION_HAND,0,nil,84013237)
	  local ttg=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_EXTRA,0,nil,159) 
	  if Duel.GetLocationCountFromEx(tp)<1 then return end
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON) 
	  local ttg2=ttg:FilterSelect(tp,Card.IsCode,1,1,nil,159)
	  local tc=ttg2:GetFirst()
	  if g:GetCount()==0  and g1:GetCount()==0  and g2:GetCount()==0  and g3:GetCount()==0 then return end 
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	  local t=g:FilterSelect(tp,Card.IsCode,1,1,nil,46986414)
	  local t1=g1:FilterSelect(tp,Card.IsCode,1,1,nil,89943723)
	  local t2=g2:FilterSelect(tp,Card.IsCode,1,1,nil,44508094)
	  local t3=g3:FilterSelect(tp,Card.IsCode,1,1,nil,84013237)
	  t1:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t2:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t3:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t:GetFirst():RegisterFlagEffect(159,0,0,0)
	  t:Merge(t1)
	  t:Merge(t2)
	  t:Merge(t3)
	tc:SetMaterial(t)
	  if Duel.SendtoGrave(t,REASON_MATERIAL+REASON_RITUAL)>0 then
	  Duel.SpecialSummonStep(tc,SUMMON_TYPE_RITUAL,tp,tp,true,false,POS_FACEUP)
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_SINGLE)
	  e1:SetCode(EFFECT_REMOVE_TYPE)
	  e1:SetValue(TYPE_SYNCHRO+TYPE_FUSION+TYPE_XYZ)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	  tc:RegisterEffect(e1)
	  Duel.SpecialSummonComplete()
	  tc:CompleteProcedure()
	  if not Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_SZONE,0,1,nil,161) and not c:GetFlagEffect(159)~=0 then
	  tc:AddCounter(0x81,4) end end
end

