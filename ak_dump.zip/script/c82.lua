--古代機械混沌融合 (K)
function c82.initial_effect(c)
		--Activate
		local e1=Effect.CreateEffect(c)
	  e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
		e1:SetDescription(aux.Stringid(13719,4))
		e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_REMOVE+CATEGORY_FUSION_SUMMON)
		e1:SetType(EFFECT_TYPE_ACTIVATE)
		e1:SetCode(EVENT_FREE_CHAIN)
		e1:SetCost(c82.cost)
		e1:SetTarget(c82.target)
		e1:SetOperation(c82.activate)
		c:RegisterEffect(e1)	
end

function c82.filter(c)
		return c:IsCode(24094653) and c:IsDiscardable()
end
function c82.cost(e,tp,eg,ep,ev,re,r,rp,chk)
		if chk==0 then return Duel.IsExistingMatchingCard(c82.filter,tp,LOCATION_HAND,0,1,e:GetHandler()) end
		Duel.DiscardHand(tp,Card.IsDiscardable,1,1,REASON_COST+REASON_DISCARD)
end
function c82.filter1(c,e,tp)
	return c:IsCanBeFusionMaterial() and not c:IsImmuneToEffect(e) and c:IsCanBeSpecialSummoned(e,0,tp,true,false)
end
function c82.filter00(c)
	  return c:GetSummonLocation()==LOCATION_EXTRA and c:IsAbleToRemove() and not c:IsSetCard(0x7) 
end
function c82.filter01(c,tc,mcount,tp)
		return c:IsCanBeFusionMaterial(tc) and Duel.IsExistingMatchingCard(c82.filter00,tp,LOCATION_GRAVE,0,mcount,c)
end
function c82.filter02(c,e,tp,mg,f,chkf)
	local m=mg:Clone()
	m:RemoveCard(c)
	local mcount1=c.min_material_count
	local mcount2=c.max_material_count
	return c:IsType(TYPE_FUSION) and (not f or f(c))
		and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_FUSION,tp,false,false) and c:CheckFusionMaterial(m,nil,chkf)
			--and m:IsExists(c82.filter01,mcount,nil,c,mcount,tp,chkf)
			and Duel.IsExistingMatchingCard(c82.filter00,tp,LOCATION_GRAVE,0,mcount1,nil)
			and Duel.GetLocationCountFromEx(tp)>=mcount1
			--and ((not c:IsCode(511001544) and Duel.GetLocationCount(tp,LOCATION_MZONE)>=mcount)
				 --or (c:IsCode(511001544) and m:IsExists(Card.IsCode,1,nil,511001540) and Duel.GetLocationCount(tp,LOCATION_MZONE)>=mcount)
				 --or (c:IsCode(511001544) and not m:IsExists(Card.IsCode,1,nil,511001540) and Duel.GetLocationCount(tp,LOCATION_MZONE)>=mcount+1))
end
function c82.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local chkf=Duel.GetLocationCountFromEx(tp)>0 and PLAYER_NONE or tp
	local mg1=Duel.GetMatchingGroup(c82.filter1,tp,LOCATION_DECK+LOCATION_EXTRA+LOCATION_GRAVE,0,nil,e,tp)
	if chkc then return chkc:IsLocation(LOCATION_EXTRA) and chkc:IsControler(tp) and chkc:IsType(TYPE_FUSION) end
	if chk==0 then
		local res=Duel.IsExistingMatchingCard(c82.filter02,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg1,nil,chkf)
		return Duel.IsPlayerCanSpecialSummonCount(tp,2) and res and not Duel.IsPlayerAffectedByEffect(tp,59822133)
	end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectTarget(tp,c82.filter02,tp,LOCATION_EXTRA,0,1,1,nil,e,tp,mg1,nil,chkf)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,g,1,tp,LOCATION_EXTRA)
	Duel.SetOperationInfo(0,CATEGORY_REMOVE,nil,g.min_material_count,tp,LOCATION_GRAVE)
end
function c82.afilter(c,tc)
		return c:IsCanBeFusionMaterial(tc) and (c:IsCode(511001540) or c:IsCode(511001539) or c:IsHasEffect(EFFECT_FUSION_SUBSTITUTE))
end
function c82.afilter2(c,tc,code)
		return c:IsCanBeFusionMaterial(tc) and code~=c:GetCode() and (c:IsCode(511001540) or c:IsCode(511001539) or c:IsHasEffect(EFFECT_FUSION_SUBSTITUTE))
end
function c82.bfilter(c,tc)
		return c:IsCanBeFusionMaterial(tc) and (c:IsCode(511001540) or c:IsHasEffect(EFFECT_FUSION_SUBSTITUTE))
end
function c82.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then return end   
	local chkf=Duel.GetLocationCountFromEx(tp)>0 and PLAYER_NONE or tp
	local mg1=Duel.GetMatchingGroup(c82.filter1,tp,LOCATION_DECK+LOCATION_EXTRA+LOCATION_GRAVE,0,nil,e,tp)
	local tc=Duel.GetFirstTarget()
	if not tc:IsRelateToEffect(e) then return end
	local mcount1=tc.min_material_count
	local mcount2=tc.max_material_count
	if Duel.GetLocationCountFromEx(tp)<mcount2 then mcount2=Duel.GetLocationCountFromEx(tp) end
	local mg2=nil
	if not Duel.IsExistingMatchingCard(c82.filter00,tp,LOCATION_GRAVE,0,mcount1,nil) or Duel.GetLocationCountFromEx(tp)<mcount1 then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
	local rg=Duel.SelectMatchingCard(tp,c82.filter00,tp,LOCATION_GRAVE,0,mcount1,mcount2,nil)
	Duel.Remove(rg,POS_FACEUP,REASON_EFFECT)
	if mg1:GetCount()<2 then return end
	--if not ((not tc:IsCode(511001544) and Duel.GetLocationCount(tp,LOCATION_MZONE)>=mcount)
			--or (tc:IsCode(511001544) and (mg1:IsExists(Card.IsCode,1,nil,511001540) or mg1:IsExists(Card.IsHasEffect,1,nil,EFFECT_FUSION_SUBSTITUTE)) and Duel.GetLocationCount(tp,LOCATION_MZONE)==mcount)
			--or (tc:IsCode(511001544) and Duel.GetLocationCount(tp,LOCATION_MZONE)>=mcount+1)) then return end
	mg1:Sub(rg)
	local mat1=Group.CreateGroup()
	--if (not tc:IsCode(511001544) and Duel.GetLocationCount(tp,LOCATION_MZONE)>=mcount)
		  --or (tc:IsCode(511001544) and Duel.GetLocationCount(tp,LOCATION_MZONE)>=mcount+1) then
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	mat1=Duel.SelectFusionMaterial(tp,tc,mg1,nil,chkf) 
	--end
	--if tc:IsCode(511001544) and (Duel.GetLocationCount(tp,LOCATION_MZONE)==mcount and (mg1:IsExists(Card.IsCode,1,nil,511001540) or mg1:IsExists(Card.IsHasEffect,1,nil,EFFECT_FUSION_SUBSTITUTE))) then
	  --Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	  --mat1=mg1:FilterSelect(tp,c82.afilter,1,1,nil,tc)
	  --local m1=mat1:GetFirst()
	  --if m1:IsCode(511001540) or m1:IsHasEffect(EFFECT_FUSION_SUBSTITUTE) then
	  --Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	  --local mat2=mg1:FilterSelect(tp,c82.afilter2,1,1,m1,tc,m1:GetCode()) 
	  --mat1:Merge(mat2) 
	  --else 
	  --Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	  --local mat2=mg1:FilterSelect(tp,c82.bfilter,1,1,m1,tc) 
	  --mat1:Merge(mat2) end end	

	local matc=mat1:GetFirst()
	while matc do
	Duel.SpecialSummonStep(matc,0,tp,tp,true,false,POS_FACEUP)
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_DISABLE)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	matc:RegisterEffect(e1,true)
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_DISABLE_EFFECT)
	e2:SetReset(RESET_EVENT+0x1fe0000)
	matc:RegisterEffect(e2,true)
	matc=mat1:GetNext() end
	Duel.SpecialSummonComplete()
	tc:SetMaterial(mat1)
	Duel.SendtoGrave(mat1,REASON_EFFECT+REASON_MATERIAL+REASON_FUSION)
	Duel.BreakEffect()
	Duel.SpecialSummon(tc,SUMMON_TYPE_FUSION,tp,tp,false,false,POS_FACEUP)
	tc:CompleteProcedure()
end
