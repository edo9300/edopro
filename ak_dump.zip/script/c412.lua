--琰魔龍王 紅蓮惡魔·禍 (K)
function c412.initial_effect(c)
	--synchro summon
	aux.AddSynchroMixProcedure(c,aux.Tuner(nil),aux.Tuner(nil),nil,Synchro.NonTuner(Card.IsSetCard,0x911),1,1)
	c:EnableReviveLimit()

	local e9=Effect.CreateEffect(c)
	e9:SetProperty(EFFECT_FLAG_INITIAL)
	e9:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e9:SetCode(EVENT_BATTLED)
	e9:SetRange(LOCATION_MZONE)
	e9:SetCondition(c412.con)
	e9:SetOperation(c412.op)
	c:RegisterEffect(e9)

	--damage
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(35809262,0))
	e2:SetCategory(CATEGORY_DAMAGE)
	e2:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_F)
	e2:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e2:SetCode(EVENT_BATTLE_DESTROYING)
	  e2:SetLabelObject(e9)
	e2:SetCondition(c412.damcon)
	e2:SetTarget(c412.damtg)
	e2:SetOperation(c412.damop)
	c:RegisterEffect(e2)
	local e22=Effect.CreateEffect(c)
	e22:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e22:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_PLAYER_TARGET)
	e22:SetCategory(CATEGORY_DAMAGE)
	e22:SetCode(EVENT_DESTROYED)
	e22:SetRange(LOCATION_MZONE)
	e22:SetCondition(c412.damcon2)
	e22:SetTarget(c412.damtg2)
	e22:SetOperation(c412.damop)
	c:RegisterEffect(e22)

	--Special Summon
	local e4=Effect.CreateEffect(c)
	e4:SetDescription(aux.Stringid(35952884,1))
	e4:SetType(EFFECT_TYPE_TRIGGER_O+EFFECT_TYPE_SINGLE)
	e4:SetProperty(EFFECT_FLAG_DAMAGE_STEP)
	e4:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e4:SetCode(EVENT_DESTROYED)
	e4:SetCondition(c412.sumcon)
	e4:SetTarget(c412.sumtg)
	e4:SetOperation(c412.sumop)
	c:RegisterEffect(e4)
end

function c412.damcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local bc=c:GetBattleTarget()
	return c:IsRelateToBattle() and bc:IsLocation(LOCATION_GRAVE) and bc:IsType(TYPE_MONSTER)
end
function c412.damtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	local bc=e:GetHandler():GetBattleTarget()
	Duel.SetTargetCard(bc)
	local dam=bc:GetAttack()
	if dam<0 then dam=0 end
	Duel.SetTargetPlayer(1-tp)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,dam)
end
function c412.damcon2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local bc=eg:GetFirst()
	return bc~=nil and bc:GetFlagEffect(412)~=0 and bc:IsLocation(LOCATION_GRAVE) and bc:IsType(TYPE_MONSTER)
end
function c412.damtg2(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	local bc=eg:GetFirst()
	Duel.SetTargetCard(bc)
	local dam=bc:GetAttack()
	if dam<0 then dam=0 end
	Duel.SetTargetPlayer(1-tp)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,dam)
end
function c412.damop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) then
		local p=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER)
		local dam=tc:GetAttack()
		if dam<0 then dam=0 end
		Duel.Damage(p,dam,REASON_EFFECT)
	end
end

function c412.sumcon(e,tp,eg,ep,ev,re,r,rp,chk)
	return e:GetHandler():IsPreviousPosition(POS_FACEUP) and e:GetHandler():IsPreviousLocation(LOCATION_ONFIELD)
end
function c412.filter(c,e,tp)
	return c:IsCode(39765958) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
end
function c412.sumtg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and Duel.IsExistingMatchingCard(c412.filter,tp,LOCATION_GRAVE,0,1,nil,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_GRAVE)
end
function c412.setfilter(c)
	return  c:IsFaceup() and not c:IsDisabled()
end
function c412.sumop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	  local tg=Duel.GetFirstMatchingCard(c412.filter,tp,LOCATION_GRAVE,0,nil,e,tp)
	if tg~=nil and Duel.SpecialSummon(tg,0,tp,tp,false,false,POS_FACEUP) then
	  Duel.BreakEffect()
	local g=Duel.GetMatchingGroup(c412.setfilter,tp,LOCATION_MZONE,LOCATION_MZONE,nil)
	if g:GetCount()>0 then
	  local tc=g:GetFirst()
	  while tc do
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_DISABLE)
	  e1:SetReset(RESET_EVENT+0x1fe0000)
	tc:RegisterEffect(e1)
	local e2=e1:Clone()
	e2:SetCode(EFFECT_DISABLE_EFFECT)
	tc:RegisterEffect(e2)
	  tc=g:GetNext()
	  end
	end end
end

function c412.con(e)
	local c=e:GetHandler()
	local atk=c:GetAttack()
	local bc=c:GetBattleTarget()
	if not bc then return end
	local bct=0
	if bc:GetPosition()==POS_FACEUP_ATTACK then
		bct=bc:GetAttack()
	else bct=bc:GetDefense()+1 end
	return c:IsRelateToBattle() and c:GetPosition()==POS_FACEUP_ATTACK 
	 and atk>=bct and not bc:IsStatus(STATUS_BATTLE_DESTROYED)
end 
function c412.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local bc=c:GetBattleTarget()
	  bc:RegisterFlagEffect(412,RESET_EVENT+EVENT_DAMAGE_STEP_END,0,1)
	  Duel.Destroy(bc,REASON_RULE)
	  bc:SetStatus(STATUS_BATTLE_DESTROYED,true) 
end
