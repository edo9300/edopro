--Aura Armor
function c110000119.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_ATTACK_ANNOUNCE)
	e1:SetCondition(c110000119.condition)
	e1:SetTarget(c110000119.target)
	e1:SetOperation(c110000119.activate)
	c:RegisterEffect(e1)
end
function c110000119.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetTurnPlayer()~=tp and Duel.GetAttackTarget()==nil and Duel.GetLP(tp)<=2000
end
function c110000119.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and Duel.IsPlayerCanSpecialSummonMonster(tp,110000118,0,0x4011,0,0,4,RACE_WARRIOR,ATTRIBUTE_EARTH) end
	Duel.SetOperationInfo(0,CATEGORY_TOKEN,nil,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,0)
end
function c110000119.activate(e,tp,eg,ep,ev,re,r,rp)
        if not Duel.NegateAttack() then return end
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<1
		or not Duel.IsPlayerCanSpecialSummonMonster(tp,110000118,0,0x4011,0,0,4,RACE_WARRIOR,ATTRIBUTE_EARTH) then return end
	local token=Duel.CreateToken(tp,110000118)
	Duel.SpecialSummonStep(token,0,tp,tp,false,false,POS_FACEUP)
	local e1=Effect.CreateEffect(e:GetHandler())
    e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_SET_ATTACK)
	--e1:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	--e1:SetRange(LOCATION_MZONE)
	e1:SetValue(c110000119.atkval)
        token:RegisterEffect(e1,true)
        local e2=e1:Clone()
        e2:SetCode(EFFECT_SET_DEFENSE)
        token:RegisterEffect(e2,true)
	    Duel.SpecialSummonComplete()
        local lp=Duel.GetLP(tp)
        Duel.PayLPCost(tp,lp/2)
end
function c110000119.atkval(e)
        local tp=e:GetHandler():GetControler()
	return Duel.GetLP(tp)
end
