--デストーイ・マーチ
function c625.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_DISABLE)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_CHAINING)
	e1:SetCondition(c625.condition)
	e1:SetTarget(c625.target)
	e1:SetOperation(c625.activate)
	c:RegisterEffect(e1)
end
function c625.filter(c,tp)
	return c:IsControler(tp) and c:IsLocation(LOCATION_MZONE) and c:IsSetCard(0xad)
end
function c625.condition(e,tp,eg,ep,ev,re,r,rp)
	if not re:IsHasProperty(EFFECT_FLAG_CARD_TARGET) then return false end
	local g=Duel.GetChainInfo(ev,CHAININFO_TARGET_CARDS)
	return g and g:FilterCount(c625.filter,nil,tp)==1
	    and re:IsActiveType(TYPE_MONSTER) and re:GetHandler():GetControler()~=tp
end
function c625.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	local g=Duel.GetChainInfo(ev,CHAININFO_TARGET_CARDS)
	local sc=g:Filter(c625.filter,nil,tp):GetFirst()
	Duel.SetTargetCard(sc)
	Duel.SetOperationInfo(0,CATEGORY_DISABLE,eg,1,0,0)
end
function c625.spfilter2(c,e,tp,lv)
	return c:IsType(TYPE_FUSION) and c:GetLevel()==lv and c:IsSetCard(0xad)
		and c:IsAbleToGrave() and Duel.IsExistingMatchingCard(c625.spfilter,tp,LOCATION_EXTRA,0,1,c,e,tp)
end
function c625.spfilter(c,e,tp)
	return c:IsType(TYPE_FUSION) and c:IsSetCard(0xad) 
	    and c:IsLevelAbove(8)
		and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_FUSION,tp,false,false)
end
function c625.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local sc=Duel.GetFirstTarget()
	local oc=re:GetHandler()
	if oc:IsFaceup() and not oc:IsImmuneToEffect(e) then
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
		e1:SetRange(LOCATION_MZONE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		oc:RegisterEffect(e1)
		local e02=e1:Clone()         
		e02:SetCode(EFFECT_DISABLE_EFFECT)
		oc:RegisterEffect(e02)
	end
	if not (sc:IsFaceup() and sc:IsRelateToEffect(e) and sc:GetLevel()>0) then return end
	local sg=Duel.GetMatchingGroup(c625.spfilter2,tp,LOCATION_EXTRA,0,nil,e,tp,sc:GetLevel())
	if sg:GetCount()==0 then return end
	if Duel.SelectYesNo(tp,aux.Stringid(74416026,0)) then	
	    Duel.BreakEffect()
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TOGRAVE)
		local tc=sg:Select(tp,1,1,nil):GetFirst()
		if Duel.SendtoGrave(tc,REASON_EFFECT)==0 or not tc:IsLocation(LOCATION_GRAVE) then return end
		local mg=Duel.GetMatchingGroup(c625.spfilter,tp,LOCATION_EXTRA,0,nil,e,tp)
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local sc2=mg:Select(tp,1,1,nil):GetFirst()
		if Duel.SpecialSummon(sc2,SUMMON_TYPE_FUSION,tp,tp,false,false,POS_FACEUP) then
			sc2:CompleteProcedure()
		end
	end
end
