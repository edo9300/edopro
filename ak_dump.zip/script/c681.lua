--地縛戒隸 地妖 (K)
function c681.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcFunRep(c,aux.FilterBoolFunction(c681.spfilter),2,false)

	local e2=Effect.CreateEffect(c)
	e2:SetProperty(EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DELAY)
	e2:SetCategory(CATEGORY_DESTROY+CATEGORY_DAMAGE)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e2:SetCode(EVENT_DESTROYED)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCondition(c681.descon)
	e2:SetTarget(c681.atktg)
	e2:SetCountLimit(1)
	e2:SetOperation(c681.damop)
	c:RegisterEffect(e2)	 
end

function c681.spfilter(c)
	return c:IsFusionSetCard(0x151a) or c:IsFusionSetCard(0x21)
end


function c681.desfilter(c,tp)
	return c:GetPreviousControler()==1-tp and not c:IsReason(REASON_BATTLE)
end
function c681.descon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local myfield=Duel.GetFieldCard(tp,LOCATION_SZONE,5)
	local oppfield=Duel.GetFieldCard(1-tp,LOCATION_SZONE,5)
	local g=eg:Filter(c681.desfilter,nil,tp)
	return ((myfield~=nil and myfield:IsFaceup())
	or (oppfield~=nil and oppfield:IsFaceup()))
	and g:GetCount()>0
end
function c681.atkfilter(c)
	return aux.TRUE
end
function c681.atktg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c681.atkfilter,tp,LOCATION_MZONE,0,1,nil) end
	local g2=Duel.GetMatchingGroup(c681.atkfilter,tp,LOCATION_MZONE,0,nil)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g2,g2:GetCount(),0,0)
end
function c681.damop(e,tp,eg,ep,ev,re,r,rp)
	local g2=Duel.GetMatchingGroup(c681.atkfilter,tp,LOCATION_MZONE,0,nil)
	if Duel.Destroy(g2,REASON_EFFECT)~=0 then
	  local g=Duel.GetOperatedGroup()
	  Duel.BreakEffect()
	  local tatk=0
	  local tc=g:GetFirst()
	  while tc do
	  local atk=tc:GetAttack()
	  tatk=tatk+atk
	  tc=g:GetNext() end
	  Duel.Damage(1-tp,tatk,REASON_EFFECT)
	end
end
