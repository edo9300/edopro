--無限靈機
function c178.initial_effect(c)
	c:EnableCounterPermit(0x85)

	--Activate
	local e1=Effect.CreateEffect(c)
      e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
      e1:SetCategory(CATEGORY_COUNTER)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_DAMAGE)
      e1:SetCondition(c178.condition)
	--e1:SetTarget(c178.target)
      e1:SetOperation(c178.operation)
      e1:SetRange(LOCATION_SZONE)
	c:RegisterEffect(e1)
	local e2=e1:Clone()
      e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
      e2:SetRange(LOCATION_SZONE)
	c:RegisterEffect(e2)
end

function c178.condition(e,tp,eg,ep,ev,re,r,rp)
      return ep==tp
end
function c178.target(e,tp,eg,ep,ev,re,r,rp,chk)
      if chk==0 then return true end
	--if chk==0 then return e:GetHandler():IsCanAddCounter(0x85,10000) end
	Duel.SetOperationInfo(0,CATEGORY_COUNTER,nil,10000,0,0x85)
end
function c178.operation(e,tp,eg,ep,ev,re,r,rp)
     local c=e:GetHandler()
     local damcounter=math.floor(ev/100)
     c:AddCounter(0x85,damcounter)
end
