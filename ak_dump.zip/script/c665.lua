--真青眼の究極竜
function c665.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcCodeRep(c,89631139,3,true,true)
	
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_IGNITION)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCountLimit(1,56532353+EFFECT_COUNT_CODE_DUEL)
	e1:SetCost(c665.cost)
	e1:SetTarget(c665.atcon)
	e1:SetOperation(c665.operation)
	c:RegisterEffect(e1)	
		
	--immune
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetCode(EFFECT_IMMUNE_EFFECT)
	e2:SetRange(LOCATION_GRAVE)
    e2:SetTargetRange(LOCATION_MZONE,0)
	e2:SetTarget(c665.target)
	e2:SetValue(c665.efilter)
	c:RegisterEffect(e2)
	local e3=e2:Clone()
	e3:SetCode(EFFECT_CANNOT_BE_EFFECT_TARGET)
	e3:SetValue(Auxiliary.tgoval)	
	c:RegisterEffect(e3)	
end

function c665.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	local e2=Effect.CreateEffect(e:GetHandler())
	e2:SetCategory(CATEGORY_DESTROY)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e2:SetCode(EVENT_PHASE+PHASE_BATTLE)
	e2:SetCountLimit(1)	
	e2:SetTarget(c665.destg)
	e2:SetOperation(c665.desop)
	e2:SetReset(RESET_PHASE+PHASE_END)
	Duel.RegisterEffect(e2,0)	
end
function c665.destg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsDestructable() end
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,e:GetHandler(),1,0,0)
end
function c665.desop(e,tp,eg,ep,ev,re,r,rp)
	Duel.Destroy(e:GetHandler(),REASON_EFFECT)
end
function c665.costfilter(c)
	return c:IsCode(23995346)
end
function c665.atcon(e,tp,eg,ep,ev,re,r,rp,chk)	
	if chk==0 then return Duel.IsExistingMatchingCard(c665.costfilter,tp,LOCATION_EXTRA,0,1,nil) end
	local g=Duel.GetMatchingGroup(c665.costfilter,tp,LOCATION_EXTRA,0,nil)
	Duel.ConfirmCards(1-tp,g)
end
function c665.operation(e,tp,eg,ep,ev,re,r,rp)
    local c=e:GetHandler()
    local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_EXTRA_ATTACK)
	e1:SetValue(2)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	c:RegisterEffect(e1)
end

--Immune
function c665.target(e,c)
	return c:IsFaceup() and c:IsSetCard(0xdd)
end
function c665.efilter(e,te)
	return te:GetOwnerPlayer()~=e:GetHandlerPlayer()
end
