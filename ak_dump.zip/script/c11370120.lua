--升华螺旋
function c11370120.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c11370120.target)
	e1:SetOperation(c11370120.activate)
	c:RegisterEffect(e1)
end
function c11370120.filter(c,e,tp,tid)
	return c:IsReason(REASON_DESTROY) and c:IsType(TYPE_XYZ) and c:GetTurnID()==tid 
	  and c:IsAbleToRemove() and not c:IsImmuneToEffect(e) 
	  and Duel.IsExistingMatchingCard(c11370120.xyzfilter,tp,LOCATION_EXTRA,0,1,nil,c:GetRank(),e,tp)
end
function c11370120.xyzfilter(c,rk,e,tp)
	return c:IsType(TYPE_XYZ) and c:GetRank()==rk+2 and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,true,false)
end
function c11370120.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return c11370120.filter(chkc) and c:IsLocation(LOCATION_GRAVE) and c:IsControler(tp) end
	local mg=Duel.GetMatchingGroup(c11370120.filter,tp,LOCATION_GRAVE,0,nil,e,tp,Duel.GetTurnCount())
	if chk==0 then return Duel.GetLocationCountFromEx(tp)>0 and mg:GetCount()>0 end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
	local xyz=Duel.SelectTarget(tp,c11370120.filter,tp,LOCATION_GRAVE,0,1,1,nil,e,tp,Duel.GetTurnCount())
	  Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,LOCATION_EXTRA)
end
function c11370120.activate(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetLocationCountFromEx(tp)<1 then return end
	local tc=Duel.GetFirstTarget()
	  if tc then
	  if Duel.Remove(tc,POS_FACEUP,REASON_EFFECT)>0 then
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local xyz=Duel.SelectMatchingCard(tp,c11370120.xyzfilter,tp,LOCATION_EXTRA,0,1,1,nil,tc:GetRank(),e,tp)
	Duel.SpecialSummon(xyz,SUMMON_TYPE_XYZ,tp,tp,true,false,POS_FACEUP)
	xyz:GetFirst():CompleteProcedure() end end
end
