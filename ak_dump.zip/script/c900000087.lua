--��ȫ�ƻ�-�����������-
function c900000087.initial_effect(c)
	
	--����Ч��
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	c:RegisterEffect(e1)
	
	--500���¹��������Թ��ޱ��ƻ�ʱ�Է�����10�ſ���ȥĹ��
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(900000087,2))
	e2:SetCategory(CATEGORY_DECKDES)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e2:SetCode(EVENT_BATTLE_DESTROYED)
	e2:SetRange(LOCATION_SZONE)
	e2:SetCondition(c900000087.condition)
	e2:SetTarget(c900000087.target)
	e2:SetOperation(c900000087.operation)
	c:RegisterEffect(e2)
end
-------------------------------------------------------------------------------------------------------------------------------------------
function c900000087.filter(c,tp)
	return c:IsPreviousLocation(LOCATION_MZONE) and c:GetPreviousControler()==tp
		and c:GetControler()==tp and c:IsAttribute(ATTRIBUTE_DARK) and c:IsAttackBelow(500)
end

function c900000087.condition(e,tp,eg,ep,ev,re,r,rp)
	return eg:IsExists(c900000087.filter,1,nil,tp)
end

function c900000087.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetOperationInfo(0,CATEGORY_DECKDES,nil,0,1-tp,10)
end

function c900000087.operation(e,tp,eg,ep,ev,re,r,rp)
	Duel.DiscardDeck(1-tp,10,REASON_EFFECT)
end
