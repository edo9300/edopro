--最終突撃命令
function c105.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCategory(CATEGORY_TOGRAVE)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetCode(EVENT_FREE_CHAIN)
      e1:SetCondition(c105.condition)
	--e1:SetTarget(c105.target)
	e1:SetOperation(c105.operation2)
	c:RegisterEffect(e1)
	--Pos Change
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetCode(EFFECT_SET_POSITION)
      e2:SetProperty(EFFECT_FLAG_SET_AVAILABLE)
	e2:SetRange(LOCATION_SZONE)
	e2:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
	e2:SetValue(POS_FACEUP_ATTACK)
	c:RegisterEffect(e2)
	local e3=e2:Clone()
	e3:SetCode(EFFECT_CANNOT_CHANGE_POSITION)
	c:RegisterEffect(e3)
end

function c105.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetFieldGroupCount(tp,LOCATION_GRAVE,0)>=15 and Duel.GetFieldGroupCount(tp,0,LOCATION_GRAVE)>=15
end
function c105.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return  Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)>2 and  Duel.GetFieldGroupCount(tp,0,LOCATION_DECK)>2 end
	Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(20173070,0))
	local g1=Duel.SelectTarget(tp,nil,tp,LOCATION_DECK,0,3,3,nil)
	if g1:GetCount()<3 then return end
	Duel.Hint(HINT_SELECTMSG,1-tp,aux.Stringid(20173070,0))
	local g2=Duel.SelectTarget(1-tp,nil,1-tp,LOCATION_DECK,0,3,3,nil)
	if g2:GetCount()<3 then return end
	g1:Merge(g2)	
	end
function c105.operation(e,tp,eg,ep,ev,re,r,rp)	
local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
local g1=g:Filter(Card.IsControler,nil,tp)
local g2=g:Filter(Card.IsControler,nil,1-tp)
local dcount=Duel.GetFieldGroupCount(tp,LOCATION_DECK,LOCATION_DECK)
if g1:GetCount()>2 and g2:GetCount()>2 then
Duel.DisableShuffleCheck()
Duel.SendtoHand(g,nil,REASON_EFFECT)
Duel.DiscardDeck(tp,dcount,REASON_EFFECT)
Duel.DiscardDeck(1-tp,dcount,REASON_EFFECT)
Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TODECK)
Duel.SendtoDeck(g1,nil,1,REASON_EFFECT)
Duel.SortDecktop(tp,tp,3)
Duel.Hint(HINT_SELECTMSG,1-tp,HINTMSG_TODECK)
Duel.SendtoDeck(g2,nil,1,REASON_EFFECT)
Duel.SortDecktop(1-tp,1-tp,3)
end
end

function c105.operation2(e,tp,eg,ep,ev,re,r,rp)
     if Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)>=3 and Duel.GetFieldGroupCount(tp,0, LOCATION_DECK)>=3 then
     local g=Duel.GetFieldGroup(tp,LOCATION_DECK,0)
     local sg=g:Select(tp,3,3,nil)
     local tc=sg:GetFirst()
     while tc do
     g:RemoveCard(tc)
     tc=sg:GetNext() end
     
     local g2=Duel.GetFieldGroup(tp,0,LOCATION_DECK)
     local sg2=g2:Select(1-tp,3,3,nil)
     local tc2=sg2:GetFirst()
     while tc2 do
     g2:RemoveCard(tc2)
     tc2=sg2:GetNext() end
     g:Merge(g2)
     Duel.SendtoGrave(g,REASON_EFFECT) end
end
