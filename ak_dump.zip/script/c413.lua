--垃圾栗子球 (K)
function c413.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(40640057,0))
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e1:SetType(EFFECT_TYPE_QUICK_O+EFFECT_TYPE_FIELD)
	e1:SetCategory(CATEGORY_DESTROY)
	e1:SetCode(EVENT_PRE_DAMAGE_CALCULATE)
	  e1:SetRange(LOCATION_HAND)
	e1:SetCondition(c413.condition)
	e1:SetCost(c413.cost)
	e1:SetTarget(c413.target)
	e1:SetOperation(c413.activate)
	c:RegisterEffect(e1)
	  local e2=e1:Clone()
	e2:SetCode(EVENT_CHAINING)
	e2:SetCondition(c413.condition2)
	e2:SetTarget(c413.target2)
	e2:SetOperation(c413.activate2)
	c:RegisterEffect(e2)
end

function c413.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetBattleDamage(tp)>=Duel.GetLP(tp) and not e:GetHandler():IsStatus(STATUS_CHAINING)
end
function c413.condition2(e,tp,eg,ep,ev,re,r,rp)
	  if re:GetHandler():IsDisabled() then return end
	--if re:IsActiveType(TYPE_SPELL+TYPE_TRAP) and not re:IsHasType(EFFECT_TYPE_ACTIVATE) then return false end
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if not ex then return false end
	return (cp==tp or ep==PLAYER_ALL) and cv>=Duel.GetLP(tp) and not e:GetHandler():IsStatus(STATUS_CHAINING)
end
function c413.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsAbleToGraveAsCost() end
	Duel.SendtoGrave(e:GetHandler(),REASON_COST+REASON_DISCARD)
end
function c413.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,eg,1,0,0)
end
function c413.target2(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,re:GetHandler(),1,0,0)
end
function c413.activate(e,tp,eg,ep,ev,re,r,rp)
	  local c=e:GetHandler()
	  if Duel.GetBattleDamage(tp)>=Duel.GetLP(tp) then
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_FIELD)
	  e1:SetCode(EFFECT_CHANGE_DAMAGE)
	  e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	  e1:SetTargetRange(1,0)
	  e1:SetValue(0)
	e1:SetReset(RESET_PHASE+PHASE_DAMAGE)
	Duel.RegisterEffect(e1,tp)  
	  local atker=Duel.GetAttacker()
	  local atked=Duel.GetAttackTarget()
	  if atker==nil then return end
	  if atker:IsControler(tp) and atked~=nil and atked:IsOnField() then 
	  Duel.Destroy(atked,REASON_EFFECT) end
	  if atker:IsControler(1-tp) and atker:IsOnField() then 
	  Duel.Destroy(atker,REASON_EFFECT) end end
end
function c413.activate2(e,tp,eg,ep,ev,re,r,rp)
	  local c=e:GetHandler()
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	  if ex or re:GetHandler():IsDisabled() or not ((cp==tp or ep==PLAYER_ALL) and cv>=Duel.GetLP(tp)) then return end
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_FIELD)
	  e1:SetCode(EFFECT_CHANGE_DAMAGE)
	  e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	  e1:SetTargetRange(1,0)
	  e1:SetValue(0)
	e1:SetReset(RESET_CHAIN)
	Duel.RegisterEffect(e1,tp)	
	  Duel.Destroy(re:GetHandler(),REASON_EFFECT)  
end
