--Performapal Resurection - Reborn Force
function c51370037.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(TIMING_END_PHASE)
	e1:SetTarget(c51370037.target)
	e1:SetOperation(c51370037.activate)
	c:RegisterEffect(e1)

	if not c51370037.global_check then
		c51370037.global_check=true
	local ch=Effect.CreateEffect(c)
	ch:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	ch:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	ch:SetCode(EVENT_DESTROYED)
	ch:SetOperation(c51370037.checkop)
	Duel.RegisterEffect(ch,0)
	end
end

function c51370037.afilter(c,tp)
	return c:IsReason(REASON_DESTROY) and c:IsType(TYPE_MONSTER)  and c:IsPreviousSetCard(0x9f)  and c:GetPreviousLocation()==LOCATION_MZONE and c:GetPreviousControler()==tp
end
function c51370037.checkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local count=eg:FilterCount(c51370037.afilter,nil,c:GetControler())
	if count>0 then c:RegisterFlagEffect(11370097,RESET_PHASE+PHASE_END,0,1) end
end

function c51370037.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return e:GetHandler():GetFlagEffect(11370097)~=0 end
end
function c51370037.activate(e,tp,eg,ep,ev,re,r,rp)
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_REFLECT_DAMAGE)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetTargetRange(1,0)
	e1:SetValue(c51370037.refval)
	e1:SetReset(RESET_PHASE+PHASE_END)
	Duel.RegisterEffect(e1,tp)
	if Duel.GetCurrentPhase()>=PHASE_BATTLE_START and Duel.GetCurrentPhase()<=PHASE_BATTLE then
	--if Duel.GetCurrentPhase()==PHASE_BATTLE then
	Duel.SkipPhase(1-tp,PHASE_BATTLE,RESET_PHASE+PHASE_BATTLE,1)
	Duel.SkipPhase(tp,PHASE_BATTLE,RESET_PHASE+PHASE_BATTLE,1)
	end
end
function c51370037.refval(e,re,val,r,rp,rc)
	return bit.band(r,REASON_EFFECT)~=0
end
