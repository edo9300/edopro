--Crystal Seal
function c140000030.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
      e1:SetCategory(CATEGORY_REMOVE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(0,0x1c0)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetTarget(c140000030.target)
	e1:SetOperation(c140000030.operation)
	c:RegisterEffect(e1)

      --Sealing
      local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_CONTINUOUS+EFFECT_TYPE_SINGLE)
	e2:SetCode(EVENT_LEAVE_FIELD)
	e2:SetOperation(c140000030.retop)
	c:RegisterEffect(e2)

      --Self Destroy
      local e3=Effect.CreateEffect(c)
      e3:SetType(EFFECT_TYPE_QUICK_F+EFFECT_TYPE_FIELD)
	e3:SetRange(LOCATION_SZONE)
	e3:SetCode(EVENT_CHAINING)
      e3:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e3:SetCondition(c140000030.descon2)
	e3:SetOperation(c140000030.desop2)
	c:RegisterEffect(e3)

	--不会被卡的效果破坏、除外、返回手牌和卡组
	local e4=Effect.CreateEffect(c)
	e4:SetType(EFFECT_TYPE_SINGLE)
	e4:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e4:SetRange(LOCATION_SZONE)
	e4:SetCode(EFFECT_INDESTRUCTABLE_EFFECT)
	e4:SetValue(c140000030.rmfilter)
	c:RegisterEffect(e4)
	local e5=e4:Clone()
	e5:SetCode(EFFECT_CANNOT_REMOVE)
	c:RegisterEffect(e5)
	local e6=e5:Clone()
	e6:SetCode(EFFECT_CANNOT_TO_HAND)
	c:RegisterEffect(e6)
	local e7=e6:Clone()
	e7:SetCode(EFFECT_CANNOT_TO_DECK)
	c:RegisterEffect(e7)
	local e8=e6:Clone()
	e8:SetCode(EFFECT_CANNOT_USE_AS_COST)
	c:RegisterEffect(e8)
end

function c140000030.filter(c)
	return c:IsFaceup() and c:IsAbleToRemove()
end
function c140000030.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and c140000030.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c140000030.filter,tp,0,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	local g=Duel.SelectTarget(tp,c140000030.filter,tp,0,LOCATION_MZONE,1,1,nil)
        Duel.SetOperationInfo(0,CATEGORY_REMOVE,g,1,0,0)
end
function c140000030.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
      local seq=tc:GetSequence()
	if tc:IsControler(1-tp) then seq=seq+16 end
	if c:IsRelateToEffect(e) and tc:IsFaceup() and tc:IsRelateToEffect(e) and Duel.Remove(tc,0,REASON_EFFECT+REASON_TEMPORARY)~=0 then
		c:SetCardTarget(tc)
		local e2=Effect.CreateEffect(e:GetHandler())
		e2:SetType(EFFECT_TYPE_FIELD)
		e2:SetCode(EFFECT_DISABLE_FIELD)
		e2:SetLabel(seq)
		e2:SetLabelObject(tc)
		e2:SetCondition(c140000030.discon)
		e2:SetOperation(c140000030.disop)
		Duel.RegisterEffect(e2,tp)
	end
end

function c140000030.retop(e,tp,eg,ep,ev,re,r,rp)
	local tc=e:GetHandler():GetFirstCardTarget()
	if tc and tc:IsLocation(LOCATION_REMOVED) then
		Duel.ReturnToField(tc)
	end
end

function c140000030.discon(e,c)
	if e:GetLabelObject():IsLocation(LOCATION_REMOVED) then return true end
        if e:GetHandler():IsFaceup() and e:GetHandler():IsOnField() then return true else return false end
end
function c140000030.disop(e,tp)
	local dis1=bit.lshift(0x1,e:GetLabel())
	return dis1
end

function c140000030.descon2(e,tp,eg,ep,ev,re,r,rp)
        if re then
            if re:GetHandler():IsCode(10) or re:GetHandler():IsCode(11) or re:GetHandler():IsCode(12) then return true end
            --local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_ATKCHANGE)
            --return ex or 
        else
            return false
        end
        
end
function c140000030.desop2(e,tp,eg,ep,ev,re,r,rp)
	Duel.Destroy(e:GetHandler(),REASON_EFFECT)
end

function c140000030.rmfilter(e,te)
	return e:GetHandler()~=te:GetHandler()
end
