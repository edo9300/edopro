--CCC Rock Armor the Embodiment of Heavy Armor
function c547.initial_effect(c)
	--Xyz.AddProcedure(c,nil,6,2)
	Xyz.AddProcedure(c,aux.FilterBoolFunction(Card.IsAttribute,ATTRIBUTE_WATER),6,2)

	c:EnableReviveLimit()

	local e3=Effect.CreateEffect(c)
	e3:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)	  
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e3:SetCode(EVENT_SPSUMMON_SUCCESS)
	e3:SetOperation(c547.atkop2)
	--c:RegisterEffect(e3)

	local e1=Effect.CreateEffect(c)
	--e1:SetProperty(0)
	  e1:SetCategory(CATEGORY_ATKCHANGE)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCost(c547.atkcost)
	e1:SetOperation(c547.atkop)
	c:RegisterEffect(e1,false,1)

	--negate
	local e5=Effect.CreateEffect(c)
	e5:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e5:SetCode(EVENT_ATTACK_ANNOUNCE)
	e5:SetOperation(c547.negop1)
	c:RegisterEffect(e5)
	local e6=Effect.CreateEffect(c)
	e6:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e6:SetCode(EVENT_BE_BATTLE_TARGET)
	e6:SetOperation(c547.negop2)
	c:RegisterEffect(e6)
end

function c547.mfilter(c)
	return c:IsFaceup() and not c:IsType(TYPE_XYZ) and c:GetLevel()==6
end
function c547.xyzfilter1(c,g)
	return g:IsExists(c547.xyzfilter2,1,c,c:GetAttribute())
end
function c547.xyzfilter2(c,att)
	return c:GetAttribute()==att
end
function c547.xyzcon(e,c,og)
	if c==nil then return true end
	local tp=c:GetControler()
	local mg=Duel.GetMatchingGroup(c547.mfilter,tp,LOCATION_MZONE,0,nil)
	return Duel.GetLocationCount(tp,LOCATION_MZONE)>-1
		and mg:IsExists(c547.xyzfilter1,1,nil,mg)
end
function c547.xyzop(e,tp,eg,ep,ev,re,r,rp,c,og)
	  local c=e:GetHandler()
	local mg=Duel.GetMatchingGroup(c547.mfilter,tp,LOCATION_MZONE,0,nil)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
	local g1=mg:FilterSelect(tp,c547.xyzfilter1,1,1,nil,mg)
	local tc1=g1:GetFirst()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
	local g2=mg:FilterSelect(tp,c547.xyzfilter2,1,1,tc1,tc1:GetAttribute())
	local tc2=g2:GetFirst()
	g1:Merge(g2)
	c:SetMaterial(g1)
	Duel.Overlay(c,g1)
end

function c547.atkop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	  if not c:GetSummonType()==SUMMON_TYPE_XYZ then return end
	local g=c:GetMaterial()
	local tc=g:GetFirst()
	  while tc do
	  local att=tc:GetAttribute()
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_ADD_ATTRIBUTE)
	e1:SetValue(att)  
	e1:SetReset(RESET_EVENT+EVENT_TO_DECK) 
	  c:RegisterEffect(e1) 
	  tc=g:GetNext() end
end

function c547.atkcost(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return c:CheckRemoveOverlayCard(tp,1,REASON_COST) end
	c:RemoveOverlayCard(tp,1,1,REASON_COST)
end

function c547.filter3(c,att)
	return c:IsFaceup() and c:GetAttribute()==att and c:GetDefense()>0
end
function c547.atkop(e,tp,eg,ep,ev,re,r,rp)
	local tc=e:GetHandler()
	if tc:IsFaceup() then
		local g=Duel.GetMatchingGroup(c547.filter3,tp,LOCATION_MZONE,LOCATION_MZONE,nil,ATTRIBUTE_WATER)
		local def=0
		local sc=g:GetFirst()
		while sc do
			local cdef=sc:GetDefense()
			if cdef<0 then cdef=0 end
			def=def+cdef
			sc=g:GetNext()
		end
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(def/2)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
	end
end

function c547.negop1(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local d=Duel.GetAttackTarget()
	if d and d:GetAttribute()==ATTRIBUTE_WATER then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		d:RegisterEffect(e1)
		local e2=Effect.CreateEffect(e:GetHandler())
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE_EFFECT)
		e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		d:RegisterEffect(e2)
	end
end
function c547.negop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local a=Duel.GetAttacker()
	if a and a:GetAttribute()==ATTRIBUTE_WATER then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		a:RegisterEffect(e1)
		local e2=Effect.CreateEffect(e:GetHandler())
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE_EFFECT)
		e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		a:RegisterEffect(e2)
	end
end
