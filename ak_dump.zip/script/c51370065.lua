--Persona Shutter Layer 2
function c51370065.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	c:RegisterEffect(e1)
	--immune
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_IMMUNE_EFFECT)
	e3:SetRange(LOCATION_SZONE)
	e3:SetTargetRange(0,LOCATION_ONFIELD)
	e3:SetValue(c51370065.efilter)
	c:RegisterEffect(e3)
end
function c51370065.efilter(e,re)
	return e:GetHandlerPlayer()~=re:GetHandlerPlayer()
end
