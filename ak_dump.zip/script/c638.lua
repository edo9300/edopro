--地縛牢 (K)
function c638.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	c:RegisterEffect(e1)

	--race
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetRange(LOCATION_FZONE)
	e2:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
	e2:SetCode(EFFECT_IMMUNE_EFFECT)
	e2:SetValue(c638.eefilter)
	c:RegisterEffect(e2)   

	local e4=Effect.CreateEffect(c)
	e4:SetCategory(CATEGORY_DISABLE)
	e4:SetProperty(EFFECT_FLAG_DELAY)
	e4:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e4:SetCode(EVENT_DESTROYED)
	e4:SetOperation(c638.activate)
	c:RegisterEffect(e4) 
end

function c638.eefilter(e,te)
	return te:GetOwner()~=e:GetOwner() 
	and (te:GetCode()==EFFECT_UPDATE_ATTACK or te:GetCode()==EFFECT_SET_ATTACK_FINAL or te:GetCode()==EFFECT_SET_BASE_ATTACK or te:GetCode()==EFFECT_SET_ATTACK)
end

function c638.filter(c)
	return c:IsType(TYPE_EFFECT) and c:IsFaceup() and not c:IsStaus(STATUS_DISABLED)
end
function c638.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not c:IsPreviousLocation(LOCATION_SZONE) then return end
	Duel.SetLP(rp,Duel.GetLP(rp)/2)
	local g=Duel.GetMatchingGroup(c638.filter,rp,LOCATION_MZONE,0,nil)
	if g:GetCount()>0 then
		local tc=g:GetFirst()
		while tc do
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE_EFFECT)
		e2:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e2)
		tc=g:GetNext() end end
end
