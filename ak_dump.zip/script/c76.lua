--
function c76.initial_effect(c)
	--Negate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_NEGATE+CATEGORY_DRAW)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_CHAINING)
	e1:SetCondition(c76.condition)
	e1:SetTarget(c76.target)
	e1:SetOperation(c76.operation)
	c:RegisterEffect(e1)
end

function c76.cfilter(c)
	return c:IsOnField() and c:IsType(TYPE_MONSTER)
end
function c76.cfilter2(c)
	return c:IsSetCard(0xba)
end
function c76.condition(e,tp,eg,ep,ev,re,r,rp)
	if tp==ep or not Duel.IsChainNegatable(ev) then return false end
	if not re:IsActiveType(TYPE_MONSTER) and not re:IsHasType(EFFECT_TYPE_ACTIVATE) then return false end
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_DESTROY)
	return ex and tg~=nil and tc+tg:FilterCount(c76.cfilter,nil)-tg:GetCount()>0 and Duel.IsExistingMatchingCard(c76.filter2,tp,LOCATION_MZONE,0,1,nil)
end
function c76.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetOperationInfo(0,CATEGORY_NEGATE,eg,1,0,0)
end
function c76.operation(e,tp,eg,ep,ev,re,r,rp)
	Duel.NegateActivation(ev)
	if re:GetHandler():IsRelateToEffect(re) then
		Duel.Draw(tp,1,REASON_EFFECT)
	end
end
