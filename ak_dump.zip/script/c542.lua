--CCC Water Sword the Embodiment of Valiant Fused Arms
function c542.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	Synchro.AddProcedure(c,nil,1,1,Synchro.NonTuner(aux.FilterBoolFunction(Card.IsAttribute,ATTRIBUTE_FIRE)),1,99)

	local e3=Effect.CreateEffect(c)
	e3:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)	  
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e3:SetCode(EVENT_SPSUMMON_SUCCESS)
	e3:SetOperation(c542.atkop2)
	--c:RegisterEffect(e3)

	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(4290468,0))
	e1:SetCategory(CATEGORY_ATKCHANGE)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	  e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCountLimit(1)
	e1:SetTarget(c542.target)
	e1:SetOperation(c542.operation)
	c:RegisterEffect(e1)

	--adup
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_DELAY)
	  e1:SetCategory(CATEGORY_ATKCHANGE)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e1:SetCode(EVENT_ATTACK_ANNOUNCE)
	e1:SetTarget(c542.atktg)
	e1:SetOperation(c542.atkop)
	c:RegisterEffect(e1)
end
function c542.filter(c)
	return c:IsAttribute(ATTRIBUTE_FIRE) 
end

function c542.afilter(c)
	return c:IsFaceup() and c:GetAttack()>0
end
function c542.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsControler(1-tp) and chkc:IsLocation(LOCATION_MZONE) and c542.afilter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c542.afilter,tp,0,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	local g=Duel.SelectTarget(tp,c542.afilter,tp,0,LOCATION_MZONE,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_DISABLE,g,1,0,0)
end
function c542.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if tc:IsFaceup() and tc:IsRelateToEffect(e) and tc:GetAttack()>0 then
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(-1000)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
	end
end

function c542.filter2(c)
	return not c:IsCode(51370066)
end
function c542.atkop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	  if not c:GetSummonType()==SUMMON_TYPE_FUSION then return end
	local gg=c:GetMaterial()
	  local g=gg:Filter(c542.filter2,nil)
	local tc=g:GetFirst()
	  local att=tc:GetOriginalAttribute()
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_CHANGE_ATTRIBUTE)
	e1:SetValue(att)  
	e1:SetReset(RESET_EVENT+EVENT_TO_DECK) 
	  c:RegisterEffect(e1) 
end

function c542.filter3(c,att)
	return c:IsFaceup() and c:GetAttribute()==att and c:GetLevel()>0
end
function c542.atktg(e,tp,eg,ep,ev,re,r,rp,chk)
	  local att=ATTRIBUTE_FIRE
	if chk==0 then return Duel.IsExistingMatchingCard(c542.filter3,tp,LOCATION_MZONE,LOCATION_MZONE,1,e:GetHandler(),att) end
end
function c542.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	  local att=ATTRIBUTE_FIRE
	if c:IsFaceup() and c:IsRelateToEffect(e) then
		local g=Duel.GetMatchingGroup(c542.filter3,tp,LOCATION_MZONE,LOCATION_MZONE,c,att)
		local tatk=0
			local tc=g:GetFirst()
			while tc do
			local atk=tc:GetLevel()
			tatk=tatk+atk
			tc=g:GetNext() end
		if tatk>0 then
			local e1=Effect.CreateEffect(c)
			e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetCode(EFFECT_UPDATE_ATTACK)
			e1:SetValue(tatk*200)
			e1:SetReset(RESET_EVENT+0x1ff0000)
			c:RegisterEffect(e1)
		end
	end
end
