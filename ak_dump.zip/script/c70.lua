--Virus Canon
function c70.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
      e1:SetCategory(CATEGORY_TOGRAVE)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c70.target)
	e1:SetOperation(c70.activate) 
	c:RegisterEffect(e1)
end

function c70.filter(c)
	return c:IsType(TYPE_SPELL) and c:IsAbleToGrave()
end
function c70.target(e,tp,eg,ep,ev,re,r,rp,chk)
      if chk==0 then return Duel.IsExistingMatchingCard(c70.filter,tp,0,LOCATION_DECK,1,nil) end
      Duel.Hint(HINT_SELECTMSG,1-tp,HINTMSG_TOGRAVE)
      local g=Duel.SelectTarget(1-tp,c70.filter,tp,0,LOCATION_DECK,10,10,e:GetHandler())
      local a=Duel.GetMatchingGroupCount(c70.filter,tp,0,LOCATION_DECK,e:GetHandler())
      if a>10 then a=10 end 
      Duel.SetOperationInfo(0,CATEGORY_TOGRAVE,g,a,1-tp,0)
end
function c70.activate(e,tp,eg,ep,ev,re,r,rp)
     local c=e:GetHandler()
     if not c:IsRelateToEffect(e) then return end
     local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
     if g:GetCount()>0 then
	    --Duel.ConfirmCards(tp,dg) 
	    Duel.SendtoGrave(g,REASON_EFFECT)
     end     
end
