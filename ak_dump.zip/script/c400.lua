--Junk Changerr (K)
function c400.initial_effect(c)
	--lv change
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(26082117,0))
	e1:SetCategory(CATEGORY_LVCHANGE)		
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetType(EFFECT_TYPE_IGNITION)
	e1:SetCountLimit(1)
	e1:SetRange(LOCATION_MZONE)
	e1:SetTarget(c400.tg)
	e1:SetOperation(c400.op)
	c:RegisterEffect(e1)
end

function c400.filter(c)
	return c:IsFaceup() and c:GetLevel()>0 and c:IsSetCard(0x43)
end
function c400.tg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(tp) and c400.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c400.filter,tp,LOCATION_MZONE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,aux.Stringid(26082117,1))
	Duel.SelectTarget(tp,c400.filter,tp,LOCATION_MZONE,0,1,1,nil)
end
function c400.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
      local tc=Duel.GetFirstTarget()
      local lv=tc:GetLevel()
	if tc:IsRelateToEffect(e) and tc:IsFaceup() and c:IsFaceup() and c:IsRelateToEffect(e) then
            local opt=Duel.SelectOption(tp,aux.Stringid(13705,0),aux.Stringid(13705,1))
            if opt==0 then
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_LEVEL)
		e1:SetValue(1)
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e1) end
            if opt==1 then
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_UPDATE_LEVEL)
		e2:SetValue(-1)
		e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
		tc:RegisterEffect(e2) end            
	end
end
