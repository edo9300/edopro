--天穹覇龍ドラゴアセンション
function c306.initial_effect(c)
	--synchro summon
	Synchro.AddProcedure(c,nil,1,1,Synchro.NonTuner(nil),1,99)
	c:EnableReviveLimit()
	--atk
	local e1=Effect.CreateEffect(c)
	--e1:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_SET_ATTACK)
	  --e1:SetRange(LOCATION_MZONE)
	e1:SetValue(c306.atkvalue)
	c:RegisterEffect(e1)

	--spsummon
	--local e2=Effect.CreateEffect(c)
	--e2:SetDescription(aux.Stringid(37910722,1))
	--e2:SetCategory(CATEGORY_SPECIAL_SUMMON)
	--e2:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	--e2:SetProperty(EFFECT_FLAG_DAMAGE_STEP)
	--e2:SetCode(EVENT_DESTROYED)
	--e2:SetCondition(c306.spcon)
	--e2:SetTarget(c306.sptg)
	--e2:SetOperation(c306.spop)
	--c:RegisterEffect(e2)

	--Destroy replace
	local e5=Effect.CreateEffect(c)
	  e5:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e5:SetType(EFFECT_TYPE_CONTINUOUS+EFFECT_TYPE_SINGLE)
	e5:SetCode(EFFECT_DESTROY_REPLACE)
	e5:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e5:SetRange(LOCATION_MZONE)
	e5:SetTarget(c306.desreptg)
	e5:SetOperation(c306.desrepop)
	c:RegisterEffect(e5)
end

function c306.atkvalue(e,c)
	return Duel.GetFieldGroupCount(c:GetControler(),LOCATION_HAND,0)*1000
end

function c306.spcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	return c:IsPreviousLocation(LOCATION_ONFIELD) and c:GetPreviousControler()==tp
end
function c306.spfilter(c,e,tp,sync)
	return c:IsControler(tp) and c:IsLocation(LOCATION_GRAVE)
		and bit.band(c:GetReason(),0x80008)==0x80008 and c:GetReasonCard()==sync
		and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
end
function c306.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	local mg=c:GetMaterial()
	  local g=mg:Filter(c306.spfilter,nil,e,tp,c)
	local ct=g:GetCount()
	if chk==0 then return c:GetSummonType()==SUMMON_TYPE_SYNCHRO
		and ct>0 and Duel.GetLocationCount(tp,LOCATION_MZONE)>=ct
		and mg:FilterCount(c306.spfilter,nil,e,tp,c)==ct end
	Duel.SetTargetCard(mg)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,mg,ct,0,0)
end
function c306.spop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local mg=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS)
	local g=mg:Filter(Card.IsRelateToEffect,nil,e)
	if g:GetCount()<mg:GetCount() then return end
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<g:GetCount() then return end
	Duel.SpecialSummon(g,0,tp,tp,false,false,POS_FACEUP)
end

function c306.repfilter(c)
	return not c:IsStatus(STATUS_DESTROY_CONFIRMED+STATUS_BATTLE_DESTROYED)
end
function c306.desreptg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	local mg=c:GetMaterial()
	  local g=mg:Filter(c306.spfilter,nil,e,tp,c)
	local ct=g:GetCount()
	if chk==0 then return not c:IsReason(REASON_REPLACE) and c:IsOnField() and c:IsFaceup() and c:IsAbleToExtra() 
					 and c:GetSummonType()==SUMMON_TYPE_SYNCHRO
				 and ct>0 and Duel.GetLocationCount(tp,LOCATION_MZONE)>=ct-1
				 and mg:FilterCount(c306.spfilter,nil,e,tp,c)==ct end
	if Duel.SelectYesNo(tp,aux.Stringid(37910722,1)) then   
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,g,ct,0,0)
	return true
	else return false end
end
function c306.desrepop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local mg=c:GetMaterial()
	  local g=mg:Filter(c306.spfilter,nil,e,tp,c)
	  if Duel.SendtoDeck(c,nil,2,REASON_EFFECT)>0 then
	--if g:GetCount()<mg:GetCount() then return end
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<g:GetCount() then return end
	Duel.SpecialSummon(g,0,tp,tp,false,false,POS_FACEUP) end
end
