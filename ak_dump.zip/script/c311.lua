--煉獄の契約 (K)
function c311.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_HANDES)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCondition(c311.condition)
	e1:SetTarget(c311.target)
	e1:SetOperation(c311.activate)
	c:RegisterEffect(e1)
end

function c311.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.IsExistingMatchingCard(nil,tp,LOCATION_HAND,0,3,e:GetHandler()) 
end
function c311.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c311.filter,tp,LOCATION_HAND,0,1,nil,e,tp)
            and Duel.GetLocationCount(tp,LOCATION_MZONE)>0 end
      Duel.SetOperationInfo(0,CATEGORY_HANDES,nil,0,tp,Duel.GetFieldGroupCount(tp,LOCATION_HAND,0))
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,0)
end
function c311.activate(e,tp,eg,ep,ev,re,r,rp)
      local g=Duel.GetFieldGroup(tp,LOCATION_HAND,0)
	Duel.SendtoGrave(g,REASON_EFFECT+REASON_DISCARD)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local sg=g:FilterSelect(tp,c311.filter,1,1,nil,e,tp)
      if sg:GetCount()==0 then return end
	local tc=sg:GetFirst()
	Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP)
end
function c311.filter(c,e,tp)
	return c:IsCanBeSpecialSummoned(e,0,tp,false,false) and c:IsSetCard(0xb) and c:IsType(TYPE_MONSTER)
end
