--地縛戒隸 地海妖 (K)
function c635.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcFunRep(c,aux.FilterBoolFunction(c635.spfilter),2,false)

	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_DELAY)
	e1:SetCategory(CATEGORY_DAMAGE+CATEGORY_DESTROY)
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCountLimit(1)
	e1:SetCondition(c635.thcon)
	e1:SetTarget(c635.target)
	e1:SetOperation(c635.activate)
	c:RegisterEffect(e1)	
end

function c635.spfilter(c)
	return c:IsFusionSetCard(0x151a) or c:IsFusionSetCard(0x21)
end

function c635.cfilter(c,tp)
	return c:IsFaceup() and c:IsControler(1-tp)
end
function c635.cfilter2(c)
	return c:GetTurnID()==Duel.GetTurnCount() and bit.band(c:GetSummonType(),SUMMON_TYPE_SPECIAL)==SUMMON_TYPE_SPECIAL
end
function c635.thcon(e,tp,eg,ep,ev,re,r,rp)
	return eg:IsExists(c635.cfilter,1,nil,tp) and Duel.GetTurnPlayer()==tp
end
function c635.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return Duel.IsExistingMatchingCard(c635.cfilter2,tp,0,LOCATION_MZONE,1,nil) end
	local g2=Duel.GetMatchingGroup(c635.cfilter2,tp,0,LOCATION_MZONE,nil)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g2,g2:GetCount(),0,0)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,g2:GetCount()*800)
end
function c635.activate(e,tp,eg,ep,ev,re,r,rp)
	local g2=Duel.GetMatchingGroup(c635.cfilter2,tp,0,LOCATION_MZONE,nil)
	if Duel.Destroy(g2,REASON_EFFECT)~=0 then
	  local g=Duel.GetOperatedGroup()
	  Duel.BreakEffect()
	  Duel.Damage(1-tp,g:GetCount()*800,REASON_EFFECT)
	end
end
