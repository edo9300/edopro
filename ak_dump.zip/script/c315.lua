--Blaster Cartridge(K)
function c315.initial_effect(c)
	local e2=Effect.CreateEffect(c)
	e2:SetCategory(CATEGORY_DECKDES+CATEGORY_DRAW+CATEGORY_TODECK)
	e2:SetType(EFFECT_TYPE_ACTIVATE)
      e2:SetCode(EVENT_FREE_CHAIN)
	e2:SetTarget(c315.sptg)
	e2:SetOperation(c315.spop)
	c:RegisterEffect(e2)
end

function c315.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsPlayerCanDraw(tp,1) and Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)>4 
                     and Duel.IsPlayerCanDiscardDeck(tp,4) end
	Duel.SetOperationInfo(0,CATEGORY_DECKDES,0,0,tp,4)
      Duel.SetOperationInfo(0,CATEGORY_DRAW,nil,1,tp,1)
      Duel.SetOperationInfo(0,CATEGORY_TODECK,e:GetHandler(),1,0,0)
end
function c315.spop(e,tp,eg,ep,ev,re,r,rp)
      local c=e:GetHandler()
	if Duel.DiscardDeck(tp,4,REASON_EFFECT)~=0 and Duel.Draw(tp,1,REASON_EFFECT)~=0 then
      c:CancelToGrave()
      Duel.SendtoDeck(c,nil,0,REASON_EFFECT)
      c:RegisterFlagEffect(315,0,0,0)
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e1:SetCode(EVENT_TO_GRAVE)
      e1:SetCondition(c315.sdcon2)
	e1:SetOperation(c315.sdop2)
	c:RegisterEffect(e1)
      local e3=e1:Clone()
	e3:SetCode(EVENT_TO_HAND)
      e3:SetCondition(c315.sdcon3)
	c:RegisterEffect(e3)
      local e5=e1:Clone()
	e5:SetCode(EVENT_REMOVE)
	c:RegisterEffect(e5)
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e2:SetCategory(CATEGORY_TOGRAVE)
	e2:SetProperty(EFFECT_FLAG_PLAYER_TARGET+EFFECT_FLAG_CANNOT_DISABLE)
	e2:SetCode(EVENT_DRAW)
	e2:SetTargetRange(1,0)
      e2:SetCondition(c315.sdcon)
	e2:SetOperation(c315.sdop)
	Duel.RegisterEffect(e2,tp) end
end
function c315.sdcon(e,tp,eg,ep,ev,re,r,rp)
	return eg:IsContains(e:GetHandler()) and e:GetHandler():GetFlagEffect(315)~=0
end
function c315.sdcon2(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetFlagEffect(315)~=0
end
function c315.sdcon3(e,tp,eg,ep,ev,re,r,rp)
	return bit.band(r,REASON_DRAW)==0 and e:GetHandler():GetFlagEffect(315)~=0
end
function c315.sdop(e,tp,eg,ep,ev,re,r,rp)
      Duel.SendtoGrave(e:GetHandler(),REASON_EFFECT)
end
function c315.sdop2(e,tp,eg,ep,ev,re,r,rp)
      e:GetHandler():ResetFlagEffect(315)
end
