--Infernity Burst (K)
function c314.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCategory(CATEGORY_DAMAGE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c314.target)
	e1:SetOperation(c314.activate)
	c:RegisterEffect(e1)
end

function c314.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c314.filter,tp,LOCATION_MZONE,0,1,nil) end
      local dam=Duel.GetMatchingGroupCount(c314.filter,tp,LOCATION_MZONE,0,nil)*800
	Duel.SetTargetPlayer(1-tp)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,dam)
end
function c314.activate(e,tp,eg,ep,ev,re,r,rp)
	local p=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER)
      local dam=Duel.GetMatchingGroupCount(c314.filter,tp,LOCATION_MZONE,0,nil)*800
	Duel.Damage(p,dam,REASON_EFFECT)
end
function c314.filter(c,e,tp)
	return c:IsFaceup() and c:IsSetCard(0xb)
end
