--天裝騎兵 鉛器三叉槍將 (K)
function c805.initial_effect(c)
	--link summon
	Link.AddProcedure(c,c805.value,2)
	c:EnableReviveLimit()
	--zone limit
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e1:SetCode(EFFECT_MUST_USE_MZONE)
	e1:SetRange(LOCATION_MZONE)
	e1:SetTargetRange(1,0)
	e1:SetValue(c805.zonelimit)
	c:RegisterEffect(e1)

	--atkup
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_SET_ATTACK)
	e2:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCondition(c805.acon)
	e2:SetValue(c805.val2)
	c:RegisterEffect(e2)

	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_TOHAND+CATEGORY_SEARCH)
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e3:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DELAY)
	e3:SetCode(EVENT_BATTLE_DESTROYED)
	e3:SetTarget(c805.erastg)
	e3:SetOperation(c805.erasop)
	c:RegisterEffect(e3)
end

function c805.value(c)
	return c:IsLinkSetCard(0x578) and c:IsLinkType(TYPE_LINK)
end

function c805.zonelimit(e)
	return 0x1f001f | (0x600060 & ~e:GetHandler():GetLinkedZone())
end

function c805.acon(e)
	local c=e:GetHandler()
	return c:GetSequence()==5 or c:GetSequence()==6
end
function c805.val2(e,c)
	return c:GetBaseAttack()*2
end

function c805.judge(c)
	return c:IsCode(511009503) and c:IsAbleToHand() and not c:IsHasEffect(EFFECT_NECRO_VALLEY) 
end
function c805.erastg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c805.judge,tp,LOCATION_DECK+LOCATION_GRAVE,0,1,nil) end
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,nil,1,tp,LOCATION_DECK+LOCATION_GRAVE)
end
function c805.erasop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)
	local g=Duel.SelectMatchingCard(tp,c805.judge,tp,LOCATION_DECK+LOCATION_GRAVE,0,1,1,nil)
	if g:GetCount()>0 then
		Duel.SendtoHand(g,nil,REASON_EFFECT)
		Duel.ConfirmCards(1-tp,g)
		if Duel.GetLocationCount(tp,LOCATION_SZONE)<1 or not Duel.MoveToField(c,tp,tp,LOCATION_SZONE,POS_FACEUP,true) or not c:IsLocation(LOCATION_SZONE) then return end
		local ptype=c:GetOriginalType()
		if c:IsType(TYPE_LINK) and not c:IsType(TYPE_SPELL+TYPE_CONTINUOUS) then
		local link=c:GetLink()
		c:SetCardData(CARDDATA_TYPE,ptype-TYPE_LINK+TYPE_SPELL+TYPE_CONTINUOUS) end
		local e02=Effect.CreateEffect(c)
		e02:SetType(EFFECT_TYPE_SINGLE)
		e02:SetRange(LOCATION_SZONE)
		e02:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
		e02:SetCode(EFFECT_LINK_SPELL_KOISHI)
		e02:SetValue(c:GetOriginalLinkMarker())
		e02:SetReset(RESET_EVENT+RESETS_STANDARD) 
		c:RegisterEffect(e02)
		local e01=e02:Clone()
		e01:SetCode(784)
		e01:SetValue(link)
		c:RegisterEffect(e01)   
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_LEAVE_FIELD_REDIRECT)
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
		e1:SetReset(RESET_EVENT+RESETS_REDIRECT)
		e1:SetValue(LOCATION_REMOVED)
		c:RegisterEffect(e1,true)   
		local e2=Effect.CreateEffect(c)
		e2:SetDescription(aux.Stringid(102380,0))
		e2:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_TODECK)
		e2:SetType(EFFECT_TYPE_IGNITION)
		e2:SetRange(LOCATION_SZONE)
		e2:SetCountLimit(1)
		e2:SetTarget(c805.sptg)
		e2:SetOperation(c805.spop)
		e2:SetReset(RESET_EVENT+RESETS_STANDARD)		
		c:RegisterEffect(e2)
		local e3=Effect.CreateEffect(c) local e4=Effect.CreateEffect(c) local e5=Effect.CreateEffect(c) local e6=Effect.CreateEffect(c) local e7=Effect.CreateEffect(c)
		e3:SetProperty(EFFECT_FLAG_DELAY+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_IGNORE_IMMUNE)
		e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
		e3:SetCode(EVENT_LEAVE_FIELD_P)
		e3:SetOperation(function(...) c:SetCardData(CARDDATA_TYPE,ptype) e3:Reset() e4:Reset() e5:Reset() e6:Reset() e7:Reset() end)	   
		c:RegisterEffect(e3,true)   
		e4=e3:Clone()
		e4:SetCode(EVENT_CHANGE_POS)
		c:RegisterEffect(e4,true)   
		e5=e3:Clone()
		e5:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
		e5:SetCode(EVENT_ADJUST) 
		e5:SetCondition(c805.adcon)
		e5:SetRange(LOCATION_SZONE)
		c:RegisterEffect(e5,true)	 
		e6=e3:Clone()
		e6:SetCode(EVENT_SSET)
		c:RegisterEffect(e6,true) 
		e7=e3:Clone()
		e7:SetCode(47408488)
		c:RegisterEffect(e7,true)		
	end
end
function c805.thfilter(c)
	return c:IsType(TYPE_LINK) and not c:IsHasEffect(EFFECT_NECRO_VALLEY) 
		and c:IsAbleToDeck()
end
function c805.spfilter(c,e,tp,tc)
	return c:IsType(TYPE_LINK) and c:IsSetCard(0x578) and not c:IsHasEffect(EFFECT_NECRO_VALLEY) 
		and c:IsCanBeSpecialSummoned(e,0,tp,false,false,POS_FACEUP,tp,tc:GetLinkedZone())
end
function c805.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return Duel.IsExistingMatchingCard(c805.thfilter,tp,LOCATION_GRAVE,0,1,nil) and Duel.IsExistingMatchingCard(c805.spfilter,tp,LOCATION_GRAVE,0,1,nil,e,tp,c) and Duel.GetLocationCount(tp,LOCATION_MZONE)>0 end
	Duel.SetOperationInfo(0,CATEGORY_TODECK,nil,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_GRAVE)
end
function c805.spop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not Duel.IsExistingMatchingCard(c805.thfilter,tp,LOCATION_GRAVE,0,1,nil) then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TODECK)
	local g=Duel.SelectMatchingCard(tp,c805.thfilter,tp,LOCATION_GRAVE,0,1,1,nil)
	if Duel.SendtoDeck(g,nil,2,REASON_EFFECT)~=0
		and Duel.GetLocationCount(tp,LOCATION_MZONE)>0 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local sg=Duel.SelectMatchingCard(tp,c805.spfilter,tp,LOCATION_GRAVE,0,1,1,nil,e,tp,c)
		if sg:GetCount()<1 then return end
		Duel.SpecialSummon(sg,0,tp,tp,false,false,POS_FACEUP,c:GetLinkedZone())
	end
end
function c805.adcon(e)
	local c=e:GetHandler()
	return c:IsDisabled() or not c:IsLocation(LOCATION_SZONE)
end



