--Performapal Curtain Call
function c51370036.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_ATKCHANGE)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c51370036.target)
	e1:SetOperation(c51370036.activate)
	c:RegisterEffect(e1)
end

function c51370036.filter(c,tid)
	return c:IsReason(REASON_DESTROY) and c:IsType(TYPE_MONSTER) and c:GetTurnID()==tid
		and c:IsSetCard(0x9f)
end
function c51370036.filter2(c,tp)
	return c:IsLocation(LOCATION_MZONE) and c:IsControler(tp) and c:IsFaceup()
end
function c51370036.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return c51370036.filter2(chkc,tp) end
	if chk==0 then return Duel.IsExistingTarget(c51370036.filter,tp,LOCATION_GRAVE+LOCATION_EXTRA+LOCATION_REMOVED+LOCATION_DECK+LOCATION_HAND,LOCATION_GRAVE+LOCATION_EXTRA+LOCATION_REMOVED+LOCATION_DECK+LOCATION_HAND,1,nil,Duel.GetTurnCount())
	and  Duel.IsExistingTarget(c51370036.filter2,tp,LOCATION_MZONE,0,1,nil,tp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	local g=Duel.SelectTarget(tp,c51370036.filter2,tp,LOCATION_MZONE,0,1,1,nil,tp)
end
function c51370036.activate(e,tp,eg,ep,ev,re,r,rp)
	local count=Duel.GetMatchingGroupCount(c51370036.filter,tp,LOCATION_GRAVE+LOCATION_EXTRA+LOCATION_REMOVED+LOCATION_DECK+LOCATION_HAND,LOCATION_GRAVE+LOCATION_EXTRA+LOCATION_REMOVED+LOCATION_DECK+LOCATION_HAND,nil,Duel.GetTurnCount())
	local tc=Duel.GetFirstTarget()
	if tc and tc:IsRelateToEffect(e) and tc:IsFaceup() then
      if count>0 then
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_UPDATE_ATTACK)
	e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	e1:SetValue(count*600)
	tc:RegisterEffect(e1) end
	local e2=Effect.CreateEffect(e:GetHandler())
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
	e2:SetValue(1)
	e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	tc:RegisterEffect(e2)
	local e3=e2:Clone()
	e3:SetCode(EFFECT_INDESTRUCTABLE_EFFECT)
	tc:RegisterEffect(e3)
	local e4=Effect.CreateEffect(e:GetHandler())
	e4:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e4:SetCode(EVENT_ATTACK_ANNOUNCE)
	e4:SetHintTiming(TIMING_BATTLE_PHASE)
	e4:SetRange(LOCATION_MZONE)
	e4:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	e4:SetOperation(c51370036.operation)
	tc:RegisterEffect(e4)
	end
end
function c51370036.operation(e,tp,eg,ep,ev,re,r,rp)
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_DISABLE)
	e1:SetTargetRange(0,LOCATION_ONFIELD)
	e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	Duel.RegisterEffect(e1,tp)
end
