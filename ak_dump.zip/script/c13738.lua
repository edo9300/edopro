--Don Thousand's Contract
function c13738.initial_effect(c)
--Activate
	local e1=Effect.CreateEffect(c)
      e1:SetCategory(CATEGORY_DRAW)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCost(c13738.cost)
	e1:SetTarget(c13738.target)
	e1:SetOperation(c13738.activate)
	c:RegisterEffect(e1)
	--Prevent Summon
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e2:SetCode(EVENT_DRAW)
	e2:SetRange(LOCATION_SZONE)
	--e2:SetCondition(c13738.ctcon)
	e2:SetOperation(c13738.ctop)
	c:RegisterEffect(e2)
end
function c13738.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.CheckLPCost(1-tp,2000) end
	Duel.PayLPCost(1-tp,2000)
end
function c13738.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsPlayerCanDraw(tp,1) and Duel.IsPlayerCanDraw(1-tp,1) 
                     and Duel.GetActivityCount(tp,ACTIVITY_SUMMON)==0 end
	Duel.SetOperationInfo(0,CATEGORY_DRAW,nil,0,PLAYER_ALL,1)
end
function c13738.activate(e,tp,eg,ep,ev,re,r,rp)
      local a=Duel.GetDecktopGroup(tp,1)
      local b=Duel.GetDecktopGroup(1-tp,1)
	Duel.Draw(tp,1,REASON_EFFECT)
	Duel.Draw(1-tp,1,REASON_EFFECT)
end

function c13738.elimit(e,te,tp)
	return te:GetHandler():IsType(TYPE_SPELL)
end
function c13738.eqfilter(c,tp)
	return c:IsType(TYPE_SPELL) and c:GetControler()==tp
end
function c13738.ctcon(e,tp,eg,ep,ev,re,r,rp)
	return eg:IsExists(c13738.eqfilter,1,nil)
end
function c13738.ctop(e,tp,eg,ep,ev,re,r,rp)
	Duel.ConfirmCards(Duel.GetTurnPlayer(),eg)
	Duel.ConfirmCards(1-Duel.GetTurnPlayer(),eg)
	Duel.ShuffleHand(tp)
	Duel.ShuffleHand(1-tp)
      if eg:IsExists(c13738.eqfilter,1,nil,tp) then
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetCode(EFFECT_CANNOT_SUMMON)
	e1:SetReset(RESET_PHASE+PHASE_END)
	e1:SetTargetRange(1,0)
	Duel.RegisterEffect(e1,tp)
	end 
      if eg:IsExists(c13738.eqfilter,1,nil,1-tp) then
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetCode(EFFECT_CANNOT_SUMMON)
	e1:SetReset(RESET_PHASE+PHASE_END)
	e1:SetTargetRange(0,1)
	Duel.RegisterEffect(e1,tp)
	end 
end
