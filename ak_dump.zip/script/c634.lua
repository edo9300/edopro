--地縛戒隸 地獅鷲 (K)
function c634.initial_effect(c)
	--synchro summon
	Synchro.AddProcedure(c,aux.FilterBoolFunction(c634.spfilter),1,1,Synchro.NonTuner(c634.spfilter),1,99)
	c:EnableReviveLimit()   

	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(39823987,0))
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DELAY)
	e1:SetCategory(CATEGORY_DESTROY)
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e1:SetCode(EVENT_DESTROYED)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCondition(c634.descon)
	e1:SetTarget(c634.destg)
	e1:SetOperation(c634.desop)
	c:RegisterEffect(e1)
end

function c634.spfilter(c)
	return c:IsSetCard(0x151a) or c:IsSetCard(0x21)
end

function c634.desfilter(c,tp)
	return c:IsPreviousLocation(LOCATION_MZONE) and c:GetPreviousControler()==tp and c:IsPreviousSetCard(0x151a)
end
function c634.descon(e,tp,eg,ep,ev,re,r,rp)
	local g=eg:Filter(c634.desfilter,nil,tp)
	return g:GetCount()>0
end
function c634.destg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc.IsControler(1-tp) and chkaux.TRUE end
	if chk==0 then return Duel.IsExistingTarget(aux.TRUE,tp,0,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_DESTROY)
	local g=Duel.SelectTarget(tp,aux.TRUE,tp,0,LOCATION_MZONE,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,1,0,0)
end
function c634.desop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc and tc:IsRelateToEffect(e) then
		Duel.Destroy(tc,REASON_EFFECT)
	end
end