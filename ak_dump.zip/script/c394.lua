
--加速同步 (K)
function c394.initial_effect(c)
	--special summon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(72714392,0))
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(0,TIMING_END_PHASE)
	e1:SetTarget(c394.target)
	e1:SetOperation(c394.soperation)
	c:RegisterEffect(e1)
end

function c394.filter(c,tlv2,tp)
	local lv=c:GetLevel()
	local tlv1=lv/2
	local sg=Duel.GetMatchingGroup(c394.filter22,tp,LOCATION_MZONE,0,c)
	return lv>0 and lv%2==0 and c:IsType(TYPE_TUNER) and c:IsFaceup() and sg:GetCount()>0
	and sg:CheckWithSumEqual(c394.filter23,tlv2-tlv1,1,99)
end
function c394.filter22(c,sc,tc,e)
	local tlv=c:GetSynchroLevel(sc)
	local tp=sc:GetControler()
	if sc:IsCode(80896940) and not c:IsType(TYPE_SYNCHRO) then return false end 
	return tlv>0 and c:IsType(TYPE_SYNCHRO) and not c:IsType(TYPE_TUNER) and c:IsFaceup()
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc)) and not c:IsImmuneToEffect(e) 
	  and (sc.tuner_filter==nil or sc.tuner_filter(tc))
end

function c394.filter023(c,sg,tc,sc,lv1,count1,count2)
	local tp=sc:GetControler()
	if Duel.GetLocationCountFromEx(tp,tp,Group.FromCards(c,tc),sc)<1 then return false end  
	local ag=sg:Clone()
	ag:RemoveCard(c)
	return ag:CheckWithSumEqual(c394.filter23,sc:GetLevel()*2-lv1-c:GetSynchroLevel(sc),count1-1,count2-1,sc)
end
function c394.filter23(c,sc)
	return c:GetSynchroLevel(sc)
end
function c394.tfilter(c,sc,e,tp)
	  local lv1=c:GetSynchroLevel(sc)
	  local count1=1
	  if sc.minntct~=nil then count1=sc.minntct end
	  local count2=1
	  if sc.maxntct~=nil then count2=sc.maxntct end
	  local sg=Duel.GetMatchingGroup(c394.filter22,tp,LOCATION_MZONE,0,c,sc,c,e)
	  if not
	  (lv1>0 and c:IsType(TYPE_TUNER) and c:IsFaceup() and not c:IsImmuneToEffect(e) 
	  and (sc.tuner_filter==nil or sc.tuner_filter(c)) and sg:GetCount()>0) then return false end
	  --if sc:GetOriginalCode()==84 then
	  --return Duel.IsExistingMatchingCard(c394.ntfilter22,tp,LOCATION_MZONE,0,1,c,c,sc,lv1,e,tp) 
	  if sc.req_filter then 
	  return Duel.IsExistingMatchingCard(c394.ntfilter01,tp,LOCATION_MZONE,0,1,c,c,sc,lv1,e,tp) 
	  else return sg:IsExists(c394.filter023,1,nil,sg,c,sc,lv1,count1,count2) end
end
function c394.ntfilter01(c,tc,sc,lv1,e,tp)
	  local lv01=c:GetSynchroLevel(sc)
	  local g=Group.FromCards(c,tc)
	  if Duel.GetLocationCountFromEx(tp,tp,g,sc)<1 then return false end
	  --if g:IsExists(Auxiliary.TuneMagXyzFilter,1,nil,g,tp) then return false end
	  return lv01>0 and c:IsType(TYPE_SYNCHRO) and not c:IsType(TYPE_TUNER) and c:IsFaceup() and not c:IsImmuneToEffect(e) 
	  --and (sc.tuner_filter==nil or sc.tuner_filter(tc))
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc))
	  and ((sc:GetLevel()*2-lv1-lv01==0 and sc.req_filter(g))
		or (sc.maxntct>1 and sc:GetLevel()*2-lv1-lv01>0
		and Duel.IsExistingMatchingCard(c394.ntfilter02,tp,LOCATION_MZONE,0,1,c,c,tc,sc,lv1,e,tp)) )
end
function c394.ntfilter02(c,nc1,tc,sc,lv1,e,tp)
	  local lv02=c:GetSynchroLevel(sc)
	  local lv01=nc1:GetSynchroLevel(sc)
	  local g=Group.FromCards(c,tc,nc1)
	  --if g:IsExists(Auxiliary.TuneMagXyzFilter,1,nil,g,tp) then return false end
	  return lv02>0 and c:IsType(TYPE_SYNCHRO) and not c:IsType(TYPE_TUNER) and c:IsFaceup() and not c:IsImmuneToEffect(e) 
	  --and (sc.tuner_filter==nil or sc.tuner_filter(tc))
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc))
	  --and (sc.nontuner_filter==nil or sc.nontuner_filter(nc1))
	  and ((sc:GetLevel()*2-lv1-lv01-lv02==0 and sc.req_filter(g))
		or (sc.maxntct>2 and sc:GetLevel()*2-lv1-lv01-lv02>0 and Duel.IsExistingMatchingCard(c394.ntfilter03,tp,LOCATION_MZONE,0,1,c,nc1,c,tc,sc,lv1,e,tp)) )
end
function c394.ntfilter03(c,nc1,nc2,tc,sc,lv1,e,tp)
	  local lv03=c:GetSynchroLevel(sc)
	  local lv01=nc1:GetSynchroLevel(sc)
	  local lv02=nc2:GetSynchroLevel(sc)
	  local g=Group.CreateGroup()
	  g:AddCard(c) g:AddCard(nc1) g:AddCard(nc2)
	  --if g:IsExists(Auxiliary.TuneMagXyzFilter,1,nil,g,tp) then return false end
	  return lv03>0 and c:IsType(TYPE_SYNCHRO) and not c:IsType(TYPE_TUNER) and c:IsFaceup() and not c:IsImmuneToEffect(e)
	  and c~=nc1 and c~=nc2
	  --and (sc.tuner_filter==nil or sc.tuner_filter(tc))
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc))
	  --and (sc.nontuner_filter==nil or sc.nontuner_filter(nc1))
	  --and (sc.nontuner_filter==nil or sc.nontuner_filter(nc2))
	  and ((sc:GetLevel()*2-lv1-lv01-lv02-lv03==0 and sc.req_filter(g))
		or (sc.maxntct>3 and sc:GetLevel()*2-lv1-lv01-lv02-lv03>0 and Duel.IsExistingMatchingCard(c394.ntfilter04,tp,LOCATION_MZONE,0,1,c,nc1,nc2,c,tc,sc,lv1,e,tp)) )
end
function c394.ntfilter04(c,nc1,nc2,nc3,tc,sc,lv1,e,tp)
	  local lv04=c:GetSynchroLevel(sc)
	  local lv01=nc1:GetSynchroLevel(sc)
	  local lv02=nc2:GetSynchroLevel(sc)
	  local lv03=nc3:GetSynchroLevel(sc)
	  local g=Group.CreateGroup()
	  g:AddCard(c) g:AddCard(nc1) g:AddCard(nc2) g:AddCard(nc3)
	  --if g:IsExists(Auxiliary.TuneMagXyzFilter,1,nil,g,tp) then return false end
	  return lv04>0 and c:IsType(TYPE_SYNCHRO) and not c:IsType(TYPE_TUNER) and c:IsFaceup() and not c:IsImmuneToEffect(e) 
	  and c~=nc1 and c~=nc2 and c~=nc3
	  --and (sc.tuner_filter==nil or sc.tuner_filter(tc))
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc))
	  --and (sc.nontuner_filter==nil or sc.nontuner_filter(nc1))
	  --and (sc.nontuner_filter==nil or sc.nontuner_filter(nc2))
	  --and (sc.nontuner_filter==nil or sc.nontuner_filter(nc3))
	  and sc:GetLevel()*2-lv1-lv01-lv02-lv03-lv04==0 and sc.req_filter(g)
end

function c394.ntfilter22(c,tc,sc,lv1,e,tp)
	  local lv12=c:GetSynchroLevel(sc)
	  local sg=Duel.GetMatchingGroup(c394.filter22,tp,LOCATION_MZONE,0,c,sc,c,e)
	  return lv12>4 and c:IsType(TYPE_SYNCHRO) and not c:IsType(TYPE_TUNER) and c:IsFaceup() and not c:IsImmuneToEffect(e) 
	  and (tc.tuner_filter==nil or tc.tuner_filter(c))
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc,SUMMON_TYPE_SYNCHRO,tp))
	  and ((sg:GetCount()>0 and sg:CheckWithSumEqual(c394.filter23,sc:GetLevel()*2-lv1-lv12,1,99,sc)) or sc:GetLevel()*2==lv1+lv12)
end

function c394.tfilter2(c,sc,e,tp)
	  local lv1=c:GetSynchroLevel(sc)
	  return lv1>0 and c:IsType(TYPE_TUNER) and c:IsFaceup() and not c:IsImmuneToEffect(e) 
	  and (sc.tuner_filter==nil or sc.tuner_filter(c))
	  and Duel.IsExistingMatchingCard(c394.tfilter22,tp,LOCATION_MZONE,0,1,c,c,sc,lv1,e,tp) 
end
function c394.tfilter22(c,tc,sc,lv1,e,tp)
	  local lv12=c:GetSynchroLevel(sc)
	  return lv12>0 and c:IsType(TYPE_TUNER) and c:IsFaceup() and not c:IsImmuneToEffect(e) 
	  --and (sc.tuner_filter==nil or sc.tuner_filter(tc))
	  and (sc.tuner_filter2==nil or sc.tuner_filter2(c))
	  and Duel.IsExistingMatchingCard(c394.ntfilter,tp,LOCATION_MZONE,0,1,c,tc,c,sc,lv1+lv12,e) 
end
function c394.ntfilter(c,tc1,tc2,sc,lv1,e)
	  local lv2=c:GetSynchroLevel(sc)
	  local tp=sc:GetControler()
	  if lv2<=0 then return false end 
	  local slv=lv1+lv2
	  if Duel.GetLocationCountFromEx(tp,tp,Group.FromCards(c,tc1,tc2),sc)<1 then return false end
	  --if Group.FromCards(c,tc1,tc2):IsExists(Auxiliary.TuneMagXyzFilter,1,nil,Group.FromCards(c,tc1,tc2),tp) then return false end
	  --if sc:IsCode(97489701) and not c:IsCode(70902743) then return false end
	  --if sc:IsCode(412) and not c:IsSetCard(0x911) then return false end
	  --if sc:IsCode(62242678) and not (c:IsRace(RACE_DRAGON) and c:IsAttribute(ATTRIBUTE_DARK) and c:IsType(TYPE_SYNCHRO)) then return false end
	  return not c:IsType(TYPE_TUNER) and c:IsType(TYPE_SYNCHRO) and c:IsFaceup() 
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc)) and not c:IsImmuneToEffect(e) 
	  --and (sc.tuner_filter==nil or sc.tuner_filter(tc1))
	  --and (sc.tuner_filter2==nil or sc.tuner_filter2(tc2))
	  and slv==sc:GetLevel()*2
end
function c394.ntfilter32(c,sc,e)
	  local lv=c:GetSynchroLevel(sc)
	  if lv<=0 then return false end 
	  return not c:IsType(TYPE_TUNER) and c:IsFaceup() and c:IsType(TYPE_SYNCHRO) and not c:IsImmuneToEffect(e) 
	  and (sc.ntuner_filter==nil or sc.ntuner_filter(c))
end

function c394.tfilter3(c,sc,e,tp)
	  local lv1=c:GetSynchroLevel(sc)
	  return lv1>0 and c:IsFaceup() and not c:IsImmuneToEffect(e) 
	  and c:IsCode(21159309)
	  and Duel.IsExistingMatchingCard(c394.tfilter32,tp,LOCATION_MZONE,0,1,c,c,sc,lv1,e,tp) 
end
c394.list={[67030233]=70902743,[7841112]=44508094,[686]=83994433,[687]=83994433,[688]=33698022}
function c394.tfilter32(c,tc,sc,lv1,e,tp)
	  local lv12=c:GetSynchroLevel(sc)
	  if not c:IsType(TYPE_TUNER) and not c:IsType(TYPE_SYNCHRO) then return false end
	  if not tc:IsType(TYPE_TUNER) and not tc:IsType(TYPE_SYNCHRO) then return false end
	  return lv12>0 and (c:IsType(TYPE_TUNER) or tc:IsType(TYPE_TUNER)) and c:IsFaceup() and not c:IsImmuneToEffect(e) 
	  --and (sc.tuner_filter==nil or sc.tuner_filter(tc))
	  and (sc.tuner_filter2==nil or sc.tuner_filter2(c,sc,tc))
	  --and c394.list[sc:GetCode()] and c:IsCode(c394.list[sc:GetCode()])
	  and Duel.IsExistingMatchingCard(c394.ntfilter3,tp,LOCATION_MZONE,0,1,c,tc,c,sc,lv1+lv12,e) 
end
function c394.ntfilter3(c,tc1,tc2,sc,lv1,e)
	  local lv2=c:GetSynchroLevel(sc)
	  local tp=sc:GetControler()
	  if lv2<=0 then return false end 
	  if Duel.GetLocationCountFromEx(tp,tp,Group.FromCards(c,tc1,tc2),sc)<1 then return false end
	  --if Group.FromCards(c,tc1,tc2):IsExists(Auxiliary.TuneMagXyzFilter,1,nil,Group.FromCards(c,tc1,tc2),tp) then return false end
	  local slv=lv1+lv2
	  return c~=tc1 and c~=tc2 and not c:IsType(TYPE_TUNER) and c:IsFaceup() and c:IsType(TYPE_SYNCHRO) and not c:IsImmuneToEffect(e) 
	  --and (sc.tuner_filter==nil or sc.tuner_filter(tc1))
	  --and (sc.tuner_filter2==nil or sc.tuner_filter2(tc2,sc,tc1))
	  and slv==sc:GetLevel()*2
end

function c394.exfilter2(c,e,tp)
	if not(c:IsType(TYPE_SYNCHRO) and not c:IsSetCard(0x301) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_SYNCHRO,tp,false,false)) then return false end
	--if c:IsCode(97489701) or c:IsCode(412) or c:IsCode(62242678) or c:IsCode(16172067) then 
	if c.tuner_filter2 and not c:IsSetCard(0x3f) then 
	  return Duel.IsExistingMatchingCard(c394.tfilter2,tp,LOCATION_MZONE,0,1,nil,c,e,tp)
	elseif c:IsSetCard(0x3f) then 
	  return Duel.IsExistingMatchingCard(c394.tfilter3,tp,LOCATION_MZONE,0,1,nil,c,e,tp) 
	else return Duel.IsExistingMatchingCard(c394.tfilter,tp,LOCATION_MZONE,0,1,nil,c,e,tp) end
end
function c394.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c394.exfilter2,tp,LOCATION_EXTRA,0,1,nil,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
end
function c394.ofilter(c,e)
	return not c:IsImmuneToEffect(e) and c:IsFaceup()
end
function c394.soperation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not Duel.IsExistingMatchingCard(c394.exfilter2,tp,LOCATION_EXTRA,0,1,nil,e,tp) then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local sg=Duel.SelectMatchingCard(tp,c394.exfilter2,tp,LOCATION_EXTRA,0,1,1,nil,e,tp)
	if sg:GetCount()==0 then return end
	local sc=sg:GetFirst()
	local count1=1
	if sc.minntct~=nil then count1=sc.minntct end
	local count2=1
	if sc.maxntct~=nil then count2=sc.maxntct end
	local g=Group.CreateGroup()

	--if sc:IsCode(97489701) or sc:IsCode(412) or sc:IsCode(62242678) or sc:IsCode(16172067) then 
	if sc.tuner_filter2 and not sc:IsSetCard(0x3f) then 
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	g=Duel.SelectMatchingCard(tp,c394.tfilter2,tp,LOCATION_MZONE,0,1,1,nil,sc,e,tp)
	local lv11=g:GetFirst():GetSynchroLevel(sc)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local gg=Duel.SelectMatchingCard(tp,c394.tfilter22,tp,LOCATION_MZONE,0,1,1,g:GetFirst(),g:GetFirst(),sc,lv11,e,tp)
	local ssg=Duel.GetMatchingGroup(c394.ntfilter32,tp,LOCATION_MZONE,0,g:GetFirst(),sc,e)
	g:Merge(gg)
	local lv1=0
	local tc=g:GetFirst()
	while tc do
	  local lv=tc:GetSynchroLevel(sc)
	  lv1=lv1+lv
	  tc=g:GetNext() end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local g2=ssg:SelectWithSumEqual(tp,c394.filter23,sc:GetLevel()*2-lv1,count1,count2,sc)
	if g2:GetCount()<1 then return end
	g:Merge(g2)

	elseif sc:IsSetCard(0x3f) then 
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	g=Duel.SelectMatchingCard(tp,c394.tfilter3,tp,LOCATION_MZONE,0,1,1,nil,sc,e,tp)
	local lv11=g:GetFirst():GetSynchroLevel(sc)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local gg=Duel.SelectMatchingCard(tp,c394.tfilter32,tp,LOCATION_MZONE,0,1,1,g:GetFirst(),g:GetFirst(),sc,lv11,e,tp)
	g:Merge(gg)
	local lv1=0
	local tc=g:GetFirst()
	while tc do
	  local lv=tc:GetSynchroLevel(sc)
	  lv1=lv1+lv
	  tc=g:GetNext() end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local g2=Duel.SelectMatchingCard(tp,c394.ntfilter3,tp,LOCATION_MZONE,0,1,1,nil,g:GetFirst(),g:GetNext(),sc,lv1,e)
	if g2:GetCount()<1 then return end
	g:Merge(g2)   

	else
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	g=Duel.SelectMatchingCard(tp,c394.tfilter,tp,LOCATION_MZONE,0,1,1,nil,sc,e,tp) 
	local lv1=g:GetFirst():GetSynchroLevel(sc)
	local ssg=Duel.GetMatchingGroup(c394.filter22,tp,LOCATION_MZONE,0,g:GetFirst(),sc,g:GetFirst(),e)
	local sgg=ssg:Clone()
	--if sc:GetOriginalCode()==84 then 
	if sc.req_filter then
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	--local ag=Duel.SelectMatchingCard(tp,c394.ntfilter22,tp,LOCATION_MZONE,0,1,1,g:GetFirst(),g:GetFirst(),sc,g:GetFirst():GetSynchroLevel(sc),e,tp) 
	local ag1=Duel.SelectMatchingCard(tp,c394.ntfilter01,tp,LOCATION_MZONE,0,1,1,g:GetFirst(),g:GetFirst(),sc,lv1,e,tp):GetFirst()
	g:AddCard(ag1) 
	--ssg:RemoveCard(ag)
	--if sc:GetLevel()*2>g:GetFirst():GetSynchroLevel(sc)+ag:GetFirst():GetSynchroLevel(sc) then
	--Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	--local g22=ssg:SelectWithSumEqual(tp,c394.filter23,sc:GetLevel()*2-g:GetFirst():GetSynchroLevel(sc)-ag:-GetFirst():GetSynchroLevel(sc),count1-1,count2-1,sc)
	local lv01=ag1:GetSynchroLevel(sc)
	if sc:GetLevel()*2-lv1-lv01>0 then 
	local ag2=Duel.SelectMatchingCard(tp,c394.ntfilter02,tp,LOCATION_MZONE,0,1,1,ag1,ag1,g:GetFirst(),sc,lv1,e,tp):GetFirst()
	g:AddCard(ag2) 
	--ssg:RemoveCard(ag2)
	local lv02=ag2:GetSynchroLevel(sc)
	if sc:GetLevel()*2-lv1-lv01-lv02>0 then
	local ag3=Duel.SelectMatchingCard(tp,c394.ntfilter03,tp,LOCATION_MZONE,0,1,1,ag2,ag1,ag2,g:GetFirst(),sc,lv1,e,tp):GetFirst()
	g:AddCard(ag3) 
	--ssg:RemoveCard(ag3)
	local lv03=ag3:GetSynchroLevel(sc)
	if sc:GetLevel()*2-lv1-lv01-lv02-lv03>0 then 
	local ag4=Duel.SelectMatchingCard(tp,c394.ntfilter04,tp,LOCATION_MZONE,0,1,1,ag3,ag1,ag2,ag3,g:GetFirst(),sc,lv1,e,tp):GetFirst()
	--ssg:RemoveCard(ag4)
	local lv04=ag4:GetSynchroLevel(sc)
	g:AddCard(ag4) end end end
 
	else
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local bbg=sgg:FilterSelect(tp,c394.filter023,1,1,nil,sgg,g:GetFirst(),sc,lv1,count1,count2)
	if bbg==nil then return end   
	local aag=sgg:Clone()
	aag:RemoveCard(bbg:GetFirst())
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local g2=aag:SelectWithSumEqual(tp,c394.filter23,sc:GetLevel()*2-lv1-bbg:GetFirst():GetSynchroLevel(sc),count1-1,count2-1,sc)
	if g2:GetCount()<1 then return end
	g2:Merge(bbg) g:Merge(g2) end end
	local tlv=g:GetSum(Card.GetSynchroLevel,sc)
	if tlv~=sc:GetLevel()*2 then return end
	Duel.SendtoGrave(g,REASON_EFFECT+REASON_MATERIAL+REASON_SYNCHRO)
	sc:SetMaterial(g)
	Duel.SpecialSummon(sc,SUMMON_TYPE_SYNCHRO,tp,tp,false,false,POS_FACEUP) 
	sc:CompleteProcedure()
end