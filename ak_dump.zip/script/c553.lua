--驚絢靈擺 (K)
function c553.initial_effect(c)
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_TOHAND)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCondition(c553.atcon)
	e1:SetTarget(c553.target)
	e1:SetOperation(c553.actop)
	c:RegisterEffect(e1)	
end

function c553.atcon(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFieldCard(tp,LOCATION_PZONE,0)
	local tc2=Duel.GetFieldCard(tp,LOCATION_PZONE,1)
	return tc==nil and tc2==nil 
end
function c553.filter2(c)
	return c:IsAbleToHand() and c:IsType(TYPE_PENDULUM) and c:IsFaceup()
end
function c553.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return c553.filter2(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c553.filter2,tp,LOCATION_EXTRA,0,2,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RTOHAND)
	local g2=Duel.SelectTarget(tp,c553.filter2,tp,LOCATION_EXTRA,0,2,2,nil)
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,g2,2,0,0)
end
function c553.actop(e,tp,eg,ep,ev,re,r,rp)
	local ex,g2=Duel.GetOperationInfo(0,CATEGORY_TOHAND)
	if g2:GetCount()~=2 then return end
	if g2:GetFirst():IsRelateToEffect(e) and g2:GetNext():IsRelateToEffect(e) then
		Duel.SendtoHand(g2,nil,REASON_EFFECT)
	end
end

