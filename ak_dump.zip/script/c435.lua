--Screwturn 見習戦士 (K)
function c435.initial_effect(c)
	
end
