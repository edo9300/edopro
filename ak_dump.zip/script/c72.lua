--  黄泉天輪 (K)
function c72.initial_effect(c)
--Activate
local e1=Effect.CreateEffect(c)
e1:SetCategory(CATEGORY_REMOVE+CATEGORY_DESTROY)
e1:SetType(EFFECT_TYPE_ACTIVATE)
e1:SetCode(EVENT_FREE_CHAIN)
e1:SetTarget(c72.target)
e1:SetOperation(c72.activate)
c:RegisterEffect(e1)

--remove
local e3=Effect.CreateEffect(c)
e3:SetType(EFFECT_TYPE_FIELD)
e3:SetCode(EFFECT_TO_GRAVE_REDIRECT)
e3:SetRange(LOCATION_SZONE)
e3:SetTarget(c72.rmtarget)
e3:SetValue(LOCATION_REMOVED)
c:RegisterEffect(e3)

--Special Summon
local e2=Effect.CreateEffect(c)
e2:SetDescription(aux.Stringid(72,0))
e2:SetCategory(CATEGORY_SPECIAL_SUMMON)
e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
e2:SetRange(LOCATION_SZONE)
e2:SetCode(EVENT_PHASE+PHASE_STANDBY)
e2:SetCountLimit(1)
e2:SetTarget(c72.drtg)
e2:SetOperation(c72.drop)
c:RegisterEffect(e2)
end

function c72.desfilter(c)
return c:IsType(TYPE_MONSTER) and c:IsDestructable()
end
function c72.filter(c)
return c:IsType(TYPE_MONSTER) and c:IsAbleToRemove()
end
function c72.target(e,tp,eg,ep,ev,re,r,rp,chk)
if chk==0 then return true end
local tg=Duel.GetMatchingGroup(c72.desfilter,tp,LOCATION_MZONE,LOCATION_MZONE,nil)
local sg=Duel.GetMatchingGroup(c72.filter,tp,LOCATION_DECK,LOCATION_DECK,nil)
Duel.SetOperationInfo(0,CATEGORY_REMOVE,nil,sg:GetCount(),PLAYER_ALL,LOCATION_DECK)
Duel.SetOperationInfo(0,CATEGORY_DESTROY,nil,tg:GetCount(),PLAYER_ALL,LOCATION_MZONE)
end
function c72.activate(e,tp,eg,ep,ev,re,r,rp)
local sg=Duel.GetMatchingGroup(c72.filter,tp,LOCATION_DECK,LOCATION_DECK,nil)
local tg=Duel.GetMatchingGroup(c72.desfilter,tp,LOCATION_MZONE,LOCATION_MZONE,nil)
Duel.Remove(sg,POS_FACEUP,REASON_EFFECT)
Duel.Destroy(tg,REASON_EFFECT)
end

function c72.filt(c,e,tp)
return c:IsCanBeSpecialSummoned(e,0,tp,false,false) and c:IsType(TYPE_MONSTER) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
end
function c72.drtg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
if chk==0 then
return (Duel.IsExistingMatchingCard(c72.filt,tp,LOCATION_GRAVE,0,1,nil,e,tp)
and Duel.GetLocationCount(tp,LOCATION_MZONE)>0)
or (Duel.IsExistingMatchingCard(c72.filt,1-tp,LOCATION_GRAVE,0,1,nil,e,1-tp)
and Duel.GetLocationCount(1-tp,LOCATION_MZONE,1-tp)>0)
end
Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,0,PLAYER_ALL,LOCATION_GRAVE)
end
function c72.drop(e,tp,eg,ep,ev,re,r,rp)
local sc=nil
local oc=nil
if (Duel.IsExistingMatchingCard(c72.filt,tp,LOCATION_GRAVE,0,1,nil,e,tp)
and Duel.GetLocationCount(tp,LOCATION_MZONE)>0) then
Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
local sg=Duel.SelectMatchingCard(tp,c72.filt,tp,LOCATION_GRAVE,0,1,1,nil,e,tp) 
sc=sg:GetFirst() end
if (Duel.IsExistingMatchingCard(c72.filt,1-tp,LOCATION_GRAVE,0,1,nil,e,1-tp)
and Duel.GetLocationCount(1-tp,LOCATION_MZONE,1-tp)>0) then
Duel.Hint(HINT_SELECTMSG,1-tp,HINTMSG_SPSUMMON)
local og=Duel.SelectMatchingCard(1-tp,c72.filt,1-tp,LOCATION_GRAVE,0,1,1,nil,e,1-tp) 
oc=og:GetFirst() end
if sc and Duel.GetLocationCount(tp,LOCATION_MZONE)>0 then
Duel.SpecialSummonStep(sc,0,tp,tp,false,false,POS_FACEUP)
end
if oc and Duel.GetLocationCount(1-tp,LOCATION_MZONE)>0 then
Duel.SpecialSummonStep(oc,0,1-tp,1-tp,false,false,POS_FACEUP)
end
Duel.SpecialSummonComplete()
end

function c72.rmtarget(e,c)
return not c:IsLocation(0x80) and not c:IsType(TYPE_SPELL+TYPE_TRAP)
end
