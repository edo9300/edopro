--Nightmare Binding
function c140000033.initial_effect(c)
	--remove
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_ATKCHANGE+CATEGORY_RECOVER)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_PLAYER_TARGET)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c140000033.target)
	e1:SetOperation(c140000033.operation)
	c:RegisterEffect(e1)
end
function c140000033.filter(c)
	return c:IsAbleToRemove()
end
function c140000033.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and c140000033.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c140000033.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	local g=Duel.SelectTarget(tp,c140000033.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,1,nil)
      Duel.SetOperationInfo(0,CATEGORY_RECOVER,nil,0,tp,800)
end
function c140000033.operation(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsFaceup() and tc:IsRelateToEffect(e) and not tc:IsImmuneToEffect(e) then
		local e1=Effect.CreateEffect(tc)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(-800)
		e1:SetReset(RESET_EVENT+0x1ff0000)
		tc:RegisterEffect(e1)

            local e2=Effect.CreateEffect(tc)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_UNRELEASABLE_SUM)
		e2:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
		e2:SetValue(1)
		e2:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e2)
            
            local e3=e2:Clone()
            e3:SetCode(EFFECT_UNRELEASABLE_NONSUM)
            tc:RegisterEffect(e3)
            Duel.Recover(tp,800,REASON_EFFECT)
	
            --disable
	      local e4=Effect.CreateEffect(c)
	      e4:SetType(EFFECT_TYPE_SINGLE)
	      e4:SetCode(EFFECT_DISABLE)
	      tc:RegisterEffect(e4)

	end
end
