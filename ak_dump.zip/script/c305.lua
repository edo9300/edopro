--グリフォンの羽根帚
function c305.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_RECOVER)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c305.target)
	e1:SetOperation(c305.activate)
	c:RegisterEffect(e1)
end
function c305.filter(c)
	return not c:IsType(TYPE_MONSTER) 
end
function c305.target(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return Duel.IsExistingMatchingCard(c305.filter,tp,LOCATION_GRAVE,0,1,c) end
	local g=Duel.GetMatchingGroup(c305.filter,tp,LOCATION_GRAVE,0,c)
	Duel.SetTargetPlayer(tp)
	Duel.SetOperationInfo(0,CATEGORY_RECOVER,nil,0,tp,g:GetCount()*500)
end
function c305.activate(e,tp,eg,ep,ev,re,r,rp)
      local p=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER)
	local g=Duel.GetMatchingGroup(c305.filter,tp,LOCATION_GRAVE,0,e:GetHandler())
	Duel.Recover(p,g:GetCount()*500,REASON_EFFECT)
end
