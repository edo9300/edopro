--Necroid 同步 (K)
function c396.initial_effect(c)
	--special summon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(72714392,0))
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c396.target)
	e1:SetOperation(c396.soperation)
	c:RegisterEffect(e1)
end

function c396.filter0(c)
	return c:IsFaceup() and c:IsCanBeSynchroMaterial()
end
function c396.filter(c,lv2,tp)
	local lv1=c:GetLevel()
	  local sg=Duel.GetMatchingGroup(c396.filter22,tp,LOCATION_GRAVE,0,c)
	return lv1>0 and c:IsType(TYPE_TUNER) and c:IsFaceup() and sg:GetCount()>0
			and sg:CheckWithSumEqual(c396.filter23,lv2-lv1,1,99)
end
function c396.filter22(c)
	local lv=c:GetLevel()
	return lv>0 and not c:IsType(TYPE_TUNER) and c:IsFaceup()
end
function c396.filter23(c)
	return c:GetLevel()
end
function c396.exfilter2(c,e,tp)
	return c:IsType(TYPE_SYNCHRO) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_SYNCHRO,tp,false,false)
	  and Duel.IsExistingMatchingCard(c396.filter,tp,LOCATION_GRAVE,0,1,nil,c:GetLevel(),tp) 
end
function c396.target(e,tp,eg,ep,ev,re,r,rp,chk)
	  local mg=Duel.GetMatchingGroup(c396.filter0,tp,LOCATION_GRAVE,0,nil)
	if chk==0 then return mg:GetCount()>0 and Duel.GetLocationCountFromEx(tp)>0 and Duel.IsExistingMatchingCard(Card.IsSynchroSummonable,tp,LOCATION_EXTRA,0,1,nil,nil,mg) end 
--and Duel.IsExistingMatchingCard(c396.exfilter2,tp,LOCATION_EXTRA,0,1,nil,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
end
function c396.soperation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	  local mg=Duel.GetMatchingGroup(c396.filter0,tp,LOCATION_GRAVE,0,nil)
	  if mg:GetCount()==0 or Duel.GetLocationCountFromEx(tp)<=0 then return end
	local g=Duel.GetMatchingGroup(Card.IsSynchroSummonable,tp,LOCATION_EXTRA,0,nil,nil,mg)
	if g:GetCount()>0 then
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local sg=g:Select(tp,1,1,nil)
	local sc=sg:GetFirst()
	  Duel.SynchroSummon(tp,sc,nil,mg)
	  local gg=sc:GetMaterial()
	  Duel.Remove(gg,POS_FACEUP,REASON_EFFECT+REASON_MATERIAL+REASON_SYNCHRO)
	  local e1=Effect.CreateEffect(c)
	  e1:SetType(EFFECT_TYPE_SINGLE)
	  e1:SetCode(EFFECT_DISABLE)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	sc:RegisterEffect(e1,true)
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_DISABLE_EFFECT)
	e2:SetReset(RESET_EVENT+0x1fe0000)
	sc:RegisterEffect(e2,true)
	--Duel.SpecialSummonComplete()
	  --sc:CompleteProcedure()
	end
end