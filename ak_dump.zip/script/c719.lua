function c719.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(55875323,0)) 
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(0,TIMING_END_PHASE)
	e1:SetTarget(c719.target)   
	e1:SetOperation(c719.operation) 
	c:RegisterEffect(e1)	
	local e2=e1:Clone() 
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetCode(EVENT_FREE_CHAIN)
	e2:SetRange(LOCATION_SZONE) 
	e2:SetCost(c719.atkcost)
	e2:SetTarget(c719.target2)  
	e2:SetOperation(c719.operation)
	c:RegisterEffect(e2)
	
	local e3=Effect.CreateEffect(c) 
	e3:SetDescription(aux.Stringid(19333131,0))
	e3:SetType(EFFECT_TYPE_ACTIVATE)
	e3:SetProperty(EFFECT_FLAG_DAMAGE_STEP)
	e3:SetCode(EVENT_BATTLE_START)
	e3:SetCondition(c719.condition)
	e3:SetTarget(c719.target3)	
	e3:SetOperation(c719.activate)
	c:RegisterEffect(e3)
	local e5=e3:Clone() 
	e5:SetType(EFFECT_TYPE_QUICK_O)
	e5:SetCode(EVENT_FREE_CHAIN)
	e5:SetRange(LOCATION_SZONE)  
	c:RegisterEffect(e5)	
	local e4=e3:Clone() 
	e4:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)  
	e4:SetCode(EVENT_CHAINING)  
	e4:SetCondition(c719.condition2)
	e4:SetTarget(c719.target4)  
	e4:SetOperation(c719.activate2)
	c:RegisterEffect(e4)
	local e6=e4:Clone() 
	e6:SetType(EFFECT_TYPE_QUICK_O)
	e6:SetCode(EVENT_FREE_CHAIN)
	e6:SetRange(LOCATION_SZONE)  
	e6:SetTarget(c719.target3)	
	c:RegisterEffect(e6)	
	
	local e7=Effect.CreateEffect(c)
	e7:SetDescription(aux.Stringid(100000053,1))	
	e7:SetType(EFFECT_TYPE_QUICK_O)
	e7:SetCode(EVENT_FREE_CHAIN)
	e7:SetRange(LOCATION_SZONE) 
	e7:SetCost(c719.cost)
	e7:SetTarget(c719.target8)  
	e7:SetOperation(c719.operation8)	
	c:RegisterEffect(e7)		
end

function c719.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.IsExistingMatchingCard(c719.filter30,tp,LOCATION_MZONE,0,1,nil)
end
function c719.filter30(c)
	return c:IsFaceup() and c:IsSetCard(0xf8) 
end
function c719.filter(c)
	return c:IsFaceup() and c:IsAttackable()
end
function c719.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local ph=Duel.GetCurrentPhase()
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(1-tp) and chkc:IsFaceup() end
	if chk==0 then return true end
	if Duel.IsExistingTarget(c719.filter,tp,0,LOCATION_MZONE,1,nil)
		 and Duel.GetTurnPlayer()==1-tp and ph>=0x8 and ph<=0x20
		 and Duel.IsExistingMatchingCard(c719.filter30,tp,LOCATION_MZONE,0,1,nil) 
		 and Duel.SelectYesNo(tp,aux.Stringid(13705,3)) then
	e:GetHandler():RegisterFlagEffect(7192,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE,0,1)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local cg=Duel.SelectTarget(tp,c719.filter,tp,0,LOCATION_MZONE,1,1,nil)
	else 
	e:SetProperty(0) 
	e:SetOperation(c719.niloperation)   
	end  
end

function c719.atkcost(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return c:GetFlagEffect(7192)==0 end
	c:RegisterFlagEffect(7192,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE,0,1)
end
function c719.niloperation(e,tp,eg,ep,ev,re,r,rp)
end
function c719.target2(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local ph=Duel.GetCurrentPhase()
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(1-tp) and chkc:IsFaceup() end
	if chk==0 then return Duel.IsExistingTarget(c719.filter,tp,0,LOCATION_MZONE,1,nil)
		 and Duel.GetTurnPlayer()==1-tp and ph>=0x8 and ph<=0x20
		 and Duel.IsExistingMatchingCard(c719.filter30,tp,LOCATION_MZONE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local cg=Duel.SelectTarget(tp,c719.filter,tp,0,LOCATION_MZONE,1,1,nil)
end
function c719.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if tc:IsFacedown() or not tc:IsRelateToEffect(e) then return end
	--must attack
	local e204=Effect.CreateEffect(c)
	e204:SetType(EFFECT_TYPE_SINGLE)
	e204:SetCode(EFFECT_MUST_ATTACK)
	e204:SetValue(1)
	e204:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
	tc:RegisterEffect(e204) 
	if tc:GetBattledGroupCount()>0 then
	--local val=math.max(tc:GetEffectCount(EFFECT_EXTRA_ATTACK)+1,tc:GetAttackAnnouncedCount())
	--if tc:GetEffectCount(EFFECT_EXTRA_ATTACK_MONSTER)>0 then
	--local val=math.max(tc:GetEffectCount(EFFECT_EXTRA_ATTACK)+tc:GetEffectCount(EFFECT_EXTRA_ATTACK_MONSTER)+1,tc:GetAttackAnnouncedCount())
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_EXTRA_ATTACK)
	e1:SetValue(10)
	e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_DAMAGE+PHASE_BATTLE)
	tc:RegisterEffect(e1) end 
end 

function c719.condition(e,tp,eg,ep,ev,re,r,rp)
	local a=Duel.GetAttacker()
	local d=Duel.GetAttackTarget()
	if a==nil or d==nil then return false end
	if d:IsControler(tp) and d:IsSetCard(0xf8) then a=d end
	return a:IsFaceup() and a:IsSetCard(0xf8) and not Duel.IsDamageCalculated()
end
function c719.target3(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():GetFlagEffect(719)~=1 end
	e:GetHandler():RegisterFlagEffect(719,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END,0,1)  
end
function c719.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not c:IsRelateToEffect(e) then return end
	local a=Duel.GetAttacker()
	local d=Duel.GetAttackTarget()
	if a==nil or d==nil then return false end
	if d:IsControler(tp) and d:IsSetCard(0xf8) then a=d end
	local c=e:GetHandler()
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
	e1:SetValue(1)
	e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_DAMAGE)
	a:RegisterEffect(e1)
end

function c719.filter20(c,tp)
	return c:IsFaceup() and c:IsSetCard(0xf8) and c:IsControler(tp) and c:IsOnField()
end
function c719.condition2(e,tp,eg,ep,ev,re,r,rp)
	local ex,tg,tc,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DESTROY)
	if ex and tg~=nil and tc+tg:FilterCount(c719.filter20,nil,tp)-tg:GetCount()>0 then 
	tg:KeepAlive()
	e:SetLabelObject(tg) end
	return ex and tg~=nil and tc+tg:FilterCount(c719.filter20,nil,tp)-tg:GetCount()>0 
end
function c719.target4(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return e:GetHandler():GetFlagEffect(719)~=1 end
	if Duel.SelectYesNo(tp,aux.Stringid(19333131,0)) then
	e:GetHandler():RegisterFlagEffect(719,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END,0,1)
	else e:SetOperation(c719.niloperation) end
end
function c719.activate2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tg=e:GetLabelObject()
	local g=tg:Filter(c719.filter20,nil,tp)
	tg:DeleteGroup()
	local gc=g:GetFirst()
	while gc do
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e1:SetRange(LOCATION_ONFIELD)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_INDESTRUCTABLE_EFFECT)
	e1:SetValue(1)
	e1:SetReset(RESET_CHAIN)
	gc:RegisterEffect(e1) 
	gc=g:GetNext() end
end

function c719.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsAbleToGraveAsCost() end
	Duel.SendtoGrave(e:GetHandler(),REASON_COST)
end
function c719.target8(e,tp,eg,ep,ev,re,r,rp,chk)
	local ph=Duel.GetCurrentPhase()
	if chk==0 then return Duel.GetTurnPlayer()==1-tp and ph>=0x8 and ph<=0x20 end
end
function c719.filter60(e,c)
	return c:IsFaceup() and c:GetAttackAnnouncedCount()==0
end
function c719.operation8(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	--must attack
	local e204=Effect.CreateEffect(c)
	e204:SetType(EFFECT_TYPE_FIELD)
	e204:SetCode(EFFECT_MUST_ATTACK)
	e204:SetTargetRange(0,LOCATION_MZONE)
	e204:SetTarget(c719.filter60)
	e204:SetValue(1)
	e204:SetReset(RESET_PHASE+PHASE_END)
	Duel.RegisterEffect(e204,tp)

	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_PATRICIAN_OF_DARKNESS)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetTargetRange(0,1)
	--e1:SetTarget(c719.filter60)   
	e1:SetReset(RESET_PHASE+PHASE_END)  
	Duel.RegisterEffect(e1,tp)  
end 