--混沌屏障 (K)
function c393.initial_effect(c)
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetTarget(c393.target)
	e1:SetOperation(c393.operation)
	c:RegisterEffect(e1)	
end

function c393.filter1(c,tp)
      local code=c:GetCode()
	return (c:IsSetCard(0x1048) or c:IsSetCard(0x1073)) and c:IsFaceup() 
      and Duel.IsExistingTarget(c393.filter2,tp,LOCATION_MZONE,0,1,c,code)
end
function c393.filter2(c,code)
	return (c:IsSetCard(0x1048) or c:IsSetCard(0x1073)) and c:IsFaceup() and code==c:GetCode()
end
function c393.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and c393.filter1(chkc,tp) end
	if chk==0 then return Duel.IsExistingTarget(c393.filter1,tp,LOCATION_MZONE,0,1,nil,tp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local tc1=Duel.SelectTarget(tp,c393.filter1,tp,LOCATION_MZONE,0,1,1,nil,tp):GetFirst()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	Duel.SelectTarget(tp,c393.filter2,tp,LOCATION_MZONE,0,1,1,tc1,tc1:GetCode())
end
function c393.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
	if g:GetCount()>0 then
            local tc=g:GetFirst()
            while tc do
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_CANNOT_BE_BATTLE_TARGET)
	      e1:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	      e1:SetRange(LOCATION_MZONE)
	      e1:SetValue(aux.imval1)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_CANNOT_REMOVE)
            e2:SetValue(1)
		e2:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e2)
            local e3=e2:Clone()
	      e3:SetCode(EFFECT_INDESTRUCTABLE_EFFECT)
		tc:RegisterEffect(e3) 
            tc=g:GetNext() end end
end
