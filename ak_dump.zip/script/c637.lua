--異界共鳴-同調融合 (K)
function c637.initial_effect(c)
	 --Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_FUSION_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c637.target)
	e1:SetOperation(c637.activate)
	c:RegisterEffect(e1)
end

function c637.filter0(c)
	return c:IsCanBeFusionMaterial() and c:IsCanBeSynchroMaterial()
end
function c637.filter1(c,e)
	return c:IsCanBeFusionMaterial() and c:IsCanBeSynchroMaterial() and not c:IsImmuneToEffect(e)
end

function c637.exfilterf(c,e,tp,m,f,chkf)
	return c:IsType(TYPE_FUSION) and (not f or f(c))
		and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_FUSION,tp,false,false) 
		and c:CheckFusionMaterial(m,nil,chkf)
		and Duel.IsExistingMatchingCard(c637.exfilters,tp,LOCATION_EXTRA,0,1,c,c,e,tp,m,f,chkf)
end
function c637.exfilters(c,fc,e,tp,m,f,chkf)
	if not (c:IsType(TYPE_SYNCHRO) and not c:IsSetCard(0x301) 
	and c:IsSynchroSummonable(nil,m) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_SYNCHRO,tp,false,false)
	and fc.min_material_count and fc.min_material_count==c.ct ) then return false end
	if c.tuner_filter2 and not c:IsSetCard(0x3f) then 
	  return m:FilterCount(c637.tfilter2,nil,c,fc,e,tp,m,f,chkf)>0
	  elseif c:IsSetCard(0x3f) then 
	  return m:FilterCount(c637.tfilter3,nil,c,fc,e,tp,m,f,chkf)>0
	else return m:FilterCount(c637.tfilter,nil,c,fc,e,tp,m,f,chkf)>0 end
end

function c637.filter22(c,sc,tc,e)
	local tlv=c:GetSynchroLevel(sc)
	local tp=sc:GetControler()
	if sc:IsCode(80896940) and not c:IsType(TYPE_SYNCHRO) then return false end
	return tlv>0 and not c:IsType(TYPE_TUNER) and c:IsFaceup()
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc))  
end
function c637.tfilter(c,sc,fc,e,tp,m,f,chkf)
	local lv1=c:GetSynchroLevel(sc)
	local sg=m:Filter(c637.filter22,c,sc,c,e)
	if not
	  (lv1>0 and c:IsType(TYPE_TUNER) and c:IsFaceup() 
	  and (sc.tuner_filter==nil or sc.tuner_filter(c)) and sg:GetCount()>0) then return false end   
	local m2=m:Clone()
	m2:RemoveCard(c)
	if m2:GetCount()<1 then return false end
	return m2:FilterCount(c637.ntfilter01,c,c,sc,fc,lv1,e,tp,m2,f,chkf)>0
end
function c637.ntfilter01(c,tc,sc,fc,lv1,e,tp,m,f,chkf)
   local lv01=c:GetSynchroLevel(sc)
   if Duel.GetLocationCountFromEx(tp,tp,Group.FromCards(c,tc),sc)<1 then return false end
   if not (lv01>0 and not c:IsType(TYPE_TUNER) and c:IsFaceup()
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc)) ) then return false end
   local g=Group.FromCards(c,tc)
   --if g:IsExists(Auxiliary.TuneMagXyzFilter,1,nil,g,tp) then return false end
	local m2=m:Clone()
	m2:RemoveCard(c)
	return ( (fc:CheckFusionMaterial(g,f,chkf) and Duel.GetLocationCountFromEx(tp,tp,g,sc)>1 and sc:GetLevel()-lv1-lv01==0 
	and (sc.req_filter==nil or (sc.req_filter and sc.req_filter(g)) )  )
		or (sc.maxntct>1 and fc.max_material_count>1 and sc:GetLevel()-lv1-lv01>0
		and m2:FilterCount(c637.ntfilter02,c,sc,fc,lv1+lv01,e,tp,m2,f,chkf,g)>0 ) )
end
function c637.ntfilter02(c,sc,fc,lv1,e,tp,m,f,chkf,g)
	local lv02=c:GetSynchroLevel(sc)
	if not (lv02>0 and not c:IsType(TYPE_TUNER) and c:IsFaceup()
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc)) ) then return false end
	local g2=g:Clone()
	g2:AddCard(c)
	local m2=m:Clone()
	m2:RemoveCard(c)
	if Duel.GetLocationCountFromEx(tp,tp,g2,sc)<2 then return false end
	--if g2:IsExists(Auxiliary.TuneMagXyzFilter,1,nil,g2,tp) then return false end
	local lv01=lv1+lv02
	return ( (fc:CheckFusionMaterial(g2,f,chkf) and sc:GetLevel()-lv01==0 
	and (sc.req_filter==nil or (sc.req_filter and sc.req_filter(g2)) ))
		or (sc.maxntct>g2:GetCount()-1 and fc.max_material_count>g2:GetCount()-1 and sc:GetLevel()-lv01>0 and m2:FilterCount(c637.ntfilter02,c,sc,fc,lv01,e,tp,m2,f,chkf,g2)>0) ) 
end

function c637.tfilter2(c,sc,fc,e,tp,m,f,chkf)
	local lv1=c:GetSynchroLevel(sc)
	if not (lv1>0 and c:IsType(TYPE_TUNER) and c:IsFaceup() 
	  and (sc.tuner_filter==nil or sc.tuner_filter(c)) ) then return false end
	local m2=m:Clone()
	m2:RemoveCard(c)
	if m2:GetCount()<1 then return false end
	return m2:FilterCount(c637.tfilter22,c,c,sc,fc,lv1,e,tp,m2,f,chkf)>0
end
function c637.tfilter22(c,tc,sc,fc,lv1,e,tp,m,f,chkf)
	local lv12=c:GetSynchroLevel(sc)
	local m2=m:Clone()
	m2:RemoveCard(c)
	return lv12>0 and c:IsType(TYPE_TUNER) and c:IsFaceup() 
	  and (sc.tuner_filter2==nil or sc.tuner_filter2(c))
	  and m:FilterCount(c637.ntfilter,c,tc,c,sc,fc,lv1+lv12,e,tp,m2,f,chkf)>0 
end
function c637.ntfilter(c,tc1,tc2,sc,fc,lv1,e,tp,m,f,chkf)
	local lv2=c:GetSynchroLevel(sc)
	if lv2<=0 then return false end 
	if Duel.GetLocationCountFromEx(tp,tp,Group.FromCards(c,tc1,tc2),sc)<2 then return false end
	local mg1=Group.CreateGroup()
	mg1:AddCard(tc1) mg1:AddCard(tc2) 
	--if mg1:IsExists(Auxiliary.TuneMagXyzFilter,1,nil,mg1,tp) then return false end
	local slv=lv1+lv2
	return not c:IsType(TYPE_TUNER) and c:IsFaceup() 
	  and (sc.nontuner_filter==nil or sc.nontuner_filter(c,sc))
	  and slv==sc:GetLevel()
end

function c637.tfilter3(c,sc,fc,e,tp,m,f,chkf)
	local lv1=c:GetSynchroLevel(sc)
	local m2=m:Clone()
	m2:RemoveCard(c)
	return lv1>0 and c:IsFaceup() 
	  and c:IsCode(21159309)
	  and m2:FilterCount(c637.tfilter32,c,c,sc,fc,lv1,e,tp,m2,f,chkf)>0 
end
function c637.tfilter32(c,tc,sc,fc,lv1,e,tp,m,f,chkf)
	local lv12=c:GetSynchroLevel(sc)
	local m2=m:Clone()
	m2:RemoveCard(c)
	return lv12>0 and (c:IsType(TYPE_TUNER) or tc:IsType(TYPE_TUNER)) and c:IsFaceup() 
	  and (sc.tuner_filter2==nil or sc.tuner_filter2(c,sc,tc))
	  and m2:FilterCount(c637.ntfilter3,c,tc,c,sc,fc,lv1+lv12,e,m2,f,chkf)>0 
end
function c637.ntfilter3(c,tc1,tc2,sc,fc,lv1,e,m,f,chkf)
	local tp=sc:GetControler()
	local lv2=c:GetSynchroLevel(sc)
	if lv2<=0 then return false end 
	local slv=lv1+lv2
	if Duel.GetLocationCountFromEx(tp,tp,Group.FromCards(c,tc1,tc2),sc)<2 then return false end
	--if Group.FromCards(c,tc1,tc2):IsExists(Auxiliary.TuneMagXyzFilter,1,nil,Group.FromCards(c,tc1,tc2),tp) then return false end
	return c~=tc1 and c~=tc2 and not c:IsType(TYPE_TUNER) and c:IsFaceup() 
	  and slv==sc:GetLevel()
end

function c637.target(e,tp,eg,ep,ev,re,r,rp,chk)
	local ect=c29724053 and Duel.IsPlayerAffectedByEffect(tp,29724053) and c29724053[tp]
	if chk==0 then
		local chkf=tp
		local mg1=Duel.GetMatchingGroup(c637.filter0,tp,LOCATION_MZONE,0,nil)
		local res=Duel.IsExistingMatchingCard(c637.exfilterf,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg1,nil,chkf)

		if not res then
		   local ce=Duel.GetChainMaterial(tp)
		   if ce~=nil then
		   local fgroup=ce:GetTarget()
		   local mg2=fgroup(ce,e,tp)
		   local mf=ce:GetValue()
		   res=Duel.IsExistingMatchingCard(c637.exfilterf,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg2,mf,chkf)
		   end
		end

		return (not ect or ect>=2) and res and not Duel.IsPlayerAffectedByEffect(tp,59822133)
	end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,2,tp,LOCATION_EXTRA)
end
function c637.activate(e,tp,eg,ep,ev,re,r,rp)
	local chkf=tp
	local c=e:GetHandler()
	local ect=c29724053 and Duel.IsPlayerAffectedByEffect(tp,29724053) and c29724053[tp]
	if Duel.IsPlayerAffectedByEffect(tp,59822133) or (ect and ect<2) then return end   
	local m=Duel.GetMatchingGroup(c637.filter1,tp,LOCATION_MZONE,0,nil,e)
	local sg1=Duel.GetMatchingGroup(c637.exfilterf,tp,LOCATION_EXTRA,0,nil,e,tp,m,nil,chkf)
	local mg2=nil
	local sg2=nil
	local ce=Duel.GetChainMaterial(tp)
	local mf=nil
	if ce~=nil then
		local fgroup=ce:GetTarget()
		mg2=fgroup(ce,e,tp)
		mf=ce:GetValue()
		sg2=Duel.GetMatchingGroup(c637.exfilterf,tp,LOCATION_EXTRA,0,nil,e,tp,mg2,mf,chkf)
	end
	if not (sg1:GetCount()>0 or (sg2~=nil and sg2:GetCount()>0)) then return end
	local sg=sg1:Clone()
	if sg2 then sg:Merge(sg2) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local tg=sg:Select(tp,1,1,nil)
	if tg:GetCount()<1 then return end
	local fc=tg:GetFirst()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local tg2=Duel.SelectMatchingCard(tp,c637.exfilters,tp,LOCATION_EXTRA,0,1,1,fc,fc,e,tp,m,mf,chkf)
	local sc=tg2:GetFirst()
	local g=Group.CreateGroup()
	local ans=false
	if sg1:IsContains(fc) and sg2~=nil and sg2:IsContains(fc) then ans=Duel.SelectYesNo(tp,ce:GetDescription()) end
	if sg1:IsContains(fc) and sg2~=nil and sg2:IsContains(fc) and ans then
	   m:Merge(mg2)
	end
	if not sg1:IsContains(fc) and sg2~=nil and sg2:IsContains(fc) then
	   m=mg2
	end
	if sg1:IsContains(fc) and (sg2==nil or not sg2:IsContains(fc) or not ans) then
	   mf=nil
	end

	if sc.tuner_filter2 and not sc:IsSetCard(0x3f) then 
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	g=m:FilterSelect(tp,c637.tfilter2,1,1,nil,sc,fc,e,tp,m,mf,chkf)  
	local lv11=g:GetFirst():GetSynchroLevel(sc)
	m:RemoveCard(g:GetFirst())
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local gg=m:FilterSelect(tp,c637.tfilter22,1,1,g:GetFirst(),g:GetFirst(),sc,fc,lv11,e,tp,m,mf,chkf)
	m:RemoveCard(gg:GetFirst())
	lv11=lv11+gg:GetFirst():GetSynchroLevel(sc)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local ng=m:FilterSelect(tp,c637.ntfilter,1,1,gg:GetFirst(),g:GetFirst(),gg:GetFirst(),sc,fc,lv11,e,tp,m,mf,chkf) 
	g:Merge(gg)
	g:Merge(ng)

	elseif sc:IsSetCard(0x3f) then 
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	g=m:FilterSelect(tp,c637.tfilter3,1,1,nil,sc,fc,e,tp,m,mf,chkf)
	sg1:RemoveCard(g:GetFirst())
	local lv11=g:GetFirst():GetSynchroLevel(sc)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local gg=m:FilterSelect(tp,c637.tfilter32,1,1,g:GetFirst(),g:GetFirst(),sc,fc,lv11,e,tp,m,mf,chkf)
	m:RemoveCard(gg:GetFirst())
	lv11=lv11+gg:GetFirst():GetSynchroLevel(sc)
	g:Merge(gg)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local ng=m:FilterSelect(tp,c637.ntfilter3,1,1,gg:GetFirst(),g:GetFirst(),gg:GetFirst(),sc,fc,lv11,e,m,mf,chkf)
	g:Merge(ng) 

	else
	local allg=Group.CreateGroup()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	g=m:FilterSelect(tp,c637.tfilter,1,1,nil,sc,fc,e,tp,m,mf,chkf) 
	m:RemoveCard(g:GetFirst())
	local lv11=g:GetFirst():GetSynchroLevel(sc)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local gg=m:FilterSelect(tp,c637.ntfilter01,1,1,g:GetFirst(),g:GetFirst(),sc,fc,lv11,e,tp,m,mf,chkf)
	m:RemoveCard(gg:GetFirst())
	lv11=lv11+gg:GetFirst():GetSynchroLevel(sc)
	allg:Merge(g) allg:Merge(gg)

	for i=1,3 do
	if sc.maxntct>allg:GetCount()-1 and sc:GetLevel()-lv11>0 and m:FilterCount(c637.ntfilter02,nil,sc,fc,lv11,e,tp,m,mf,chkf,allg)>0 then
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SMATERIAL)
	local ng=m:FilterSelect(tp,c637.ntfilter02,1,1,gg:GetFirst(),sc,fc,lv11,e,tp,m,mf,chkf,allg)
	m:RemoveCard(ng:GetFirst())
	lv11=lv11+ng:GetFirst():GetSynchroLevel(sc)
	allg:Merge(ng)  
	end 
	end
	g:Merge(allg)
	end

	if g:GetCount()<1 then return end
	Duel.SendtoGrave(g,REASON_EFFECT+REASON_MATERIAL+REASON_SYNCHRO+REASON_FUSION)
	sc:SetMaterial(g)
	fc:SetMaterial(g)
	Duel.SpecialSummonStep(fc,SUMMON_TYPE_FUSION,tp,tp,false,false,POS_FACEUP) 
	Duel.SpecialSummonStep(sc,SUMMON_TYPE_SYNCHRO,tp,tp,false,false,POS_FACEUP) 
	Duel.SpecialSummonComplete()
	fc:CompleteProcedure()
	sc:CompleteProcedure()
end