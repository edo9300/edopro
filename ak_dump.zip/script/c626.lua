--融合前台 (K)
function c626.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCondition(c626.cost)	
	c:RegisterEffect(e1)

	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetCode(EFFECT_CHANGE_DAMAGE)
	e2:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e2:SetRange(LOCATION_SZONE)
	e2:SetTargetRange(1,0)
	e2:SetValue(c626.damval)
	c:RegisterEffect(e2)	
	
	--selfdes
	local e7=Effect.CreateEffect(c)
	e7:SetType(EFFECT_TYPE_SINGLE)
	e7:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e7:SetRange(LOCATION_SZONE)
	e7:SetCode(EFFECT_SELF_DESTROY)
	e7:SetCondition(c626.descon)
	c:RegisterEffect(e7)	
end

function c626.cfilter(c)
	return c:IsType(TYPE_FUSION) and c:IsFaceup()
end
function c626.cost(e,tp,eg,ep,ev,re,r,rp)
	return Duel.IsExistingMatchingCard(c626.cfilter,tp,LOCATION_MZONE,0,1,nil)
end

function c626.damval(e,re,val,r,rp,rc)
	if bit.band(r,REASON_EFFECT)~=0 and rp~=e:GetHandlerPlayer() then return 0
	else return val end
end

function c626.descon(e)
	return not Duel.IsExistingMatchingCard(c626.cfilter,e:GetHandler():GetControler(),LOCATION_MZONE,0,1,nil)
end

