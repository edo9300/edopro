--Master Piece
function c11370119.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c11370119.target)
	e1:SetOperation(c11370119.activate)
	c:RegisterEffect(e1)
end
function c11370119.filter(c,e,tp,tid,g)
	if (c:IsHasEffect(73941492) or c:IsHasEffect(EFFECT_TUNE_MAGICIAN_X)) and c.xyzlimitfilter and g:IsExists(Auxiliary.TuneMagFilter2,1,c,c.xyzlimitfilter,tp) then return false end
	return c:IsReason(REASON_DESTROY) and c:IsType(TYPE_MONSTER) and aux.MustMaterialCheck(c,tp,EFFECT_MUST_BE_XMATERIAL) 
	  and c:GetTurnID()==tid and not c:IsHasEffect(EFFECT_NECRO_VALLEY) 
end
function c11370119.xyzfilter(c,e,tp,mg)
	if not c:IsType(TYPE_XYZ) then return false end
	if c:IsType(TYPE_PENDULUM) and c:IsFaceup() then return false end
	local mg2=mg:Filter(c11370119.mfilter3,nil,c)
	if c.minxyzct==nil or (c.minxyzct and c.minxyzct~=2) then return false end
	return c:IsXyzSummonable(mg) and mg2:GetCount()>1 
end
function c11370119.mfilter3(c,mc)
	  local tp=mc:GetControler()
	  if mc.xyz_filter~=nil then 
	  return c:IsFaceup() and mc.xyz_filter(c) and c:IsCanBeXyzMaterial(mc) end
	  if mc.xyz_filter==nil then 
	return c:IsFaceup() and c:IsCanBeXyzMaterial(mc) end
end
function c11370119.target(e,tp,eg,ep,ev,re,r,rp,chk)
	local mg=Duel.GetMatchingGroup(c11370119.filter,tp,LOCATION_GRAVE,0,nil,e,tp,Duel.GetTurnCount(),mg)
	if chk==0 then return Duel.GetLocationCountFromEx(tp)>0 and mg:GetCount()>1
		and Duel.IsExistingMatchingCard(c11370119.xyzfilter,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg) end
	  Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,0)
end
function c11370119.activate(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetLocationCountFromEx(tp)<1 then return end
	local mg=Duel.GetMatchingGroup(c11370119.filter,tp,LOCATION_GRAVE,0,nil,e,tp,Duel.GetTurnCount(),mg)
	if mg:GetCount()<2 or not Duel.IsExistingMatchingCard(c11370119.xyzfilter,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg) or not aux.MustMaterialCheck(mg,tp,EFFECT_MUST_BE_XMATERIAL)  then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local tc=Duel.SelectMatchingCard(tp,c11370119.xyzfilter,tp,LOCATION_EXTRA,0,1,1,nil,e,tp,mg):GetFirst()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
	local sg1=mg:FilterSelect(tp,c11370119.mfilter3,2,2,nil,tc)
	Duel.XyzSummon(tp,tc,sg1)
	--tc:SetMaterial(sg1)
	--Duel.Overlay(tc,sg1)
	--Duel.SpecialSummon(tc,SUMMON_TYPE_XYZ,tp,tp,false,false,POS_FACEUP)
	--tc:CompleteProcedure()
end