--グラヴィティ・ウォリアー
function c443.initial_effect(c)
	--synchro summon
	Synchro.AddProcedure(c,nil,1,1,Synchro.NonTuner(nil),1,99)
	c:EnableReviveLimit()

	--atkup
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(44035031,0))
	e1:SetType(EFFECT_TYPE_TRIGGER_F+EFFECT_TYPE_SINGLE)
	e1:SetCategory(CATEGORY_ATKCHANGE)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetCondition(c443.atkcon)
	e1:SetOperation(c443.atkop)
	c:RegisterEffect(e1)

	--pos
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(44035031,1))
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetCode(EVENT_FREE_CHAIN)
	e2:SetCountLimit(1)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCondition(c443.poscon)
	e2:SetTarget(c443.postg)
	e2:SetOperation(c443.posop)
	c:RegisterEffect(e2)
end

function c443.atkcon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetSummonType()==SUMMON_TYPE_SYNCHRO
end
function c443.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not c:IsFaceup() or not c:IsRelateToEffect(e) then return end
	local ct=Duel.GetFieldGroupCount(1-tp,LOCATION_ONFIELD,0)
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_UPDATE_ATTACK)
	e1:SetValue(ct*500)
	e1:SetReset(RESET_EVENT+0x1ff0000)
	c:RegisterEffect(e1)
end

function c443.poscon(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetTurnPlayer()~=tp and Duel.GetCurrentPhase()==PHASE_BATTLE
end
function c443.cfilter2(c)
	return c:IsType(TYPE_MONSTER) 
end
function c443.postg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return e:GetHandler():IsAttackPos()  
		  and Duel.IsExistingMatchingCard(c443.cfilter2,tp,0,LOCATION_MZONE,1,nil) end
end
function c443.posop(e,tp,eg,ep,ev,re,r,rp)
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	  local d=Duel.SelectMatchingCard(tp,c443.cfilter2,tp,0,LOCATION_MZONE,1,1,nil):GetFirst()
	  if d and d:IsFacedown() then Duel.ChangePosition(d,POS_FACEUP_DEFENSE) end
	  if e:GetHandler():IsAttackPos() and not d:IsImmuneToEffect(e) then
		  Duel.CalculateDamage(e:GetHandler(),d)
		  Duel.BreakEffect()
		  Duel.Destroy(e:GetHandler(),REASON_EFFECT)
	  end
end
