--Zero Gate of the Void (K)
function c310.initial_effect(c)
	local e18=Effect.CreateEffect(c)
	e18:SetType(EFFECT_TYPE_FIELD)
	e18:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e18:SetCode(EFFECT_CANNOT_LOSE_KOISHI)
	e18:SetRange(LOCATION_GRAVE)
	e18:SetCondition(c310.actcondition)
	e18:SetTargetRange(1,0)
	e18:SetValue(1)
	c:RegisterEffect(e18)
	
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_DELAY)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetCode(EVENT_BATTLE_DAMAGE)
	e1:SetRange(LOCATION_GRAVE)
	e1:SetCondition(c310.condition)
	e1:SetTarget(c310.target)
	e1:SetOperation(c310.activate)
	e1:SetCountLimit(1,310+EFFECT_COUNT_CODE_DUEL)
	c:RegisterEffect(e1)
	local e2=e1:Clone()
	e2:SetCode(317)
	e2:SetCondition(c310.condition2)
	c:RegisterEffect(e2)
end

function c310.actcondition(e,c)
	local c=e:GetHandler()
	local a,aeg,aep,aev,are,ar,arp=Duel.CheckEvent(317,true)
	return (a and c310.condition2(e,e:GetHandlerPlayer(),aeg,aep,aev,are,ar,arp) and c310.target(e,e:GetHandlerPlayer(),aeg,aep,aev,are,ar,arp,0) and c:GetFlagEffect(317)==0)
	or (c:GetFlagEffect(317)~=0)
	or (Duel.CheckEvent(EVENT_BATTLE_DAMAGE) and Duel.GetBattleDamage(e:GetHandlerPlayer())>0  and (Duel.GetFieldGroupCount(e:GetHandlerPlayer(),LOCATION_HAND,0)==0 or Duel.GetFieldGroupCount(e:GetHandlerPlayer(),LOCATION_MZONE+LOCATION_SZONE,0)==0) and c310.target(e,e:GetHandlerPlayer(),aeg,aep,aev,are,ar,arp,0) and c:GetFlagEffect(317)==0) 
end

function c310.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetBattleDamage(tp)>0 
	  and (Duel.GetFieldGroupCount(tp,LOCATION_HAND,0)==0 or Duel.GetFieldGroupCount(tp,LOCATION_MZONE+LOCATION_SZONE,0)==0)
end
function c310.condition2(e,tp,eg,ep,ev,re,r,rp)
	return ep==tp
	-- if re:GetHandler():IsDisabled() or not (Duel.GetFieldGroupCount(tp,LOCATION_HAND,0)==0 or Duel.GetFieldGroupCount(tp,LOCATION_MZONE+LOCATION_SZONE,0)==0) then return end
	-- local e1=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_DAMAGE)
	-- local e2=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_RECOVER)
	-- local rd=e1 and not e2
	-- local rr=not e1 and e2
	-- local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	-- if ex and (cp==tp or cp==PLAYER_ALL) and not rd and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) then 
		-- return true 
	-- end
	-- ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_RECOVER)
	-- return ex and (cp==tp or cp==PLAYER_ALL) and rr and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) 
end
function c310.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c310.filter,tp,LOCATION_EXTRA,0,1,nil,e,tp)
			and Duel.GetLocationCount(tp,LOCATION_MZONE)>0 end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
	e:GetHandler():RegisterFlagEffect(317,RESET_CHAIN,0,1)
end
function c310.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler() 
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local sg=Duel.SelectMatchingCard(tp,c310.filter,tp,LOCATION_EXTRA,0,1,1,nil,e,tp)
	if sg:GetCount()==0 then return end
	local tc=sg:GetFirst()
	if Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP)>0 then
	local e18=Effect.CreateEffect(c)
	e18:SetType(EFFECT_TYPE_FIELD)
	e18:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_PLAYER_TARGET)
	e18:SetCode(EFFECT_CANNOT_LOSE_LP)
	e18:SetRange(LOCATION_MZONE)
	e18:SetTargetRange(1,0)
	e18:SetValue(1)
	tc:RegisterEffect(e18,true)
	local e19=e18:Clone()
	e19:SetCode(EFFECT_CANNOT_LOSE_DECK)
	tc:RegisterEffect(e19,true)
	local e20=e18:Clone()
	e20:SetCode(EFFECT_CANNOT_LOSE_EFFECT)
	tc:RegisterEffect(e20,true)

	local e1=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_DAMAGE)
	local e2=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_RECOVER)
	local rd=e1 and not e2
	local rr=not e1 and e2
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if ex and (cp==tp or cp==PLAYER_ALL) and not rd and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) then 
	--local e3=Effect.CreateEffect(c)
	--e3:SetType(EFFECT_TYPE_FIELD)
	--e3:SetCode(EFFECT_CHANGE_DAMAGE)
	--e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	--e3:SetTargetRange(1,0)
	--e3:SetValue(Duel.GetLP(tp)-1)
	--e3:SetReset(RESET_CHAIN)
	--Duel.RegisterEffect(e3,tp) 
	end
	ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_RECOVER)
	if ex and (cp==tp or cp==PLAYER_ALL) and rr and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) then
	--local e3=Effect.CreateEffect(c)
	--e3:SetType(EFFECT_TYPE_FIELD)
	--e3:SetCode(EFFECT_CHANGE_DAMAGE)
	--e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	--e3:SetTargetRange(1,0)
	--e3:SetValue(Duel.GetLP(tp)-1)
	--e3:SetReset(RESET_CHAIN)
	--Duel.RegisterEffect(e3,tp) 
	end 
	--if Duel.GetBattleDamage(tp)>=Duel.GetLP(tp) then
	--Duel.SetLP(tp,4)
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CHANGE_DAMAGE)
	e3:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_PLAYER_TARGET)
	e3:SetTargetRange(1,0)
	e3:SetValue(0)
	--Duel.RegisterEffect(e3,tp)
	--end   
	local e004=Effect.GlobalEffect()  
	e004:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_PLAYER_TARGET)
	e004:SetType(EFFECT_TYPE_CONTINUOUS+EFFECT_TYPE_FIELD)
	e004:SetCode(EVENT_ADJUST)
	e004:SetCondition(c310.lpcon)
	e004:SetOperation(c310.lpop)
	e004:SetTargetRange(1,0)
	--Duel.RegisterEffect(e004,tp) 
	local e0043=e004:Clone()
	e0043:SetCode(EVENT_CHAIN_SOLVED)
	--Duel.RegisterEffect(e0043,tp)


			local e102=Effect.CreateEffect(c)
			e102:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
			e102:SetCode(EVENT_PRE_DAMAGE_CALCULATE)
			e102:SetOperation(c310.rdop)
			--Duel.RegisterEffect(e102,tp)
			local e103=e102:Clone()
			e103:SetCode(EVENT_CHAINING)
			e103:SetCondition(c310.rdcon)
			e103:SetOperation(c310.rdop2)
			--Duel.RegisterEffect(e103,tp)
			local e02=Effect.CreateEffect(c)
			e02:SetType(EFFECT_TYPE_FIELD)
			e02:SetCode(EFFECT_DRAW_COUNT)
			e02:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_PLAYER_TARGET)
			e02:SetTargetRange(1,0)
			e02:SetCondition(c310.dc)
			e02:SetValue(0)
			--Duel.RegisterEffect(e02,tp)
	
	   local e115=Effect.CreateEffect(c)
	   e115:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	   e115:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	   e115:SetCode(EVENT_LEAVE_FIELD)
	   e115:SetOperation(c310.lose)
	   tc:RegisterEffect(e115,true) end
end
function c310.filter(c,e,tp)
	return c:IsCanBeSpecialSummoned(e,0,tp,false,false) and c:IsCode(81020646)
end

function c310.lpcon(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetLP(e:GetHandlerPlayer())~=4
end
function c310.lpop(e,tp,eg,ep,ev,re,r,rp) 
	Duel.SetLP(e:GetHandlerPlayer(),4)
end 

function c310.rdop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local ttp=c:GetControler()
	if Duel.GetBattleDamage(ttp)>=Duel.GetLP(ttp) then
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CHANGE_DAMAGE)
	e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e3:SetTargetRange(1,0)
	e3:SetValue(Duel.GetLP(ttp)-1)
	e3:SetReset(RESET_PHASE+PHASE_DAMAGE)
	Duel.RegisterEffect(e3,ttp) end
end
function c310.rdcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tp=c:GetControler()
	local e1=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_DAMAGE)
	local e2=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_RECOVER)
	local rd=e1 and not e2
	local rr=not e1 and e2
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if ex and (cp==tp or cp==PLAYER_ALL) and not rd and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) then 
		return true 
	end
	ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_RECOVER)
	return ex and (cp==tp or cp==PLAYER_ALL) and rr and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) 
end
function c310.rdop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tp=c:GetControler()
	local e1=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_DAMAGE)
	local e2=Duel.IsPlayerAffectedByEffect(tp,EFFECT_REVERSE_RECOVER)
	local rd=e1 and not e2
	local rr=not e1 and e2
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if ex and (cp==tp or cp==PLAYER_ALL) and not rd and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) then 
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CHANGE_DAMAGE)
	e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e3:SetTargetRange(1,0)
	e3:SetValue(Duel.GetLP(tp)-1)
	e3:SetReset(RESET_CHAIN)
	Duel.RegisterEffect(e3,tp) 
	end
	ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_RECOVER)
	if ex and (cp==tp or cp==PLAYER_ALL) and rr and not Duel.IsPlayerAffectedByEffect(tp,EFFECT_NO_EFFECT_DAMAGE) and cv>=Duel.GetLP(tp) then
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CHANGE_DAMAGE)
	e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e3:SetTargetRange(1,0)
	e3:SetValue(Duel.GetLP(tp)-1)
	e3:SetReset(RESET_CHAIN)
	Duel.RegisterEffect(e3,tp) 
	end 
end
function c310.dc(e)
local tp=e:GetOwner():GetControler()
return Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)<1
end
function c310.losecon(e,tp,eg,ep,ev,re,r,rp)
	  local tc=e:GetHandler() 
	return tc:IsFacedown()  or tc:IsDisabled() 
end
function c310.lose(e,tp,eg,ep,ev,re,r,rp)
	local WIN_REASON_VOID=0x53
	Duel.Win(1-tp,WIN_REASON_VOID)
end
