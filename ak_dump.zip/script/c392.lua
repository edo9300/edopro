--分身鯊魚 (K)
function c392.initial_effect(c)
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(89312388,0))
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e2:SetCode(EVENT_SUMMON_SUCCESS)
	e2:SetTarget(c392.target)
	e2:SetOperation(c392.operation)
	c:RegisterEffect(e2)	
end

function c392.filter(c)
	return c:IsFaceup() and c:IsAttribute(ATTRIBUTE_WATER)
end
function c392.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsControler(tp) and chkc:IsLocation(LOCATION_MZONE) and c392.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c392.filter,tp,LOCATION_MZONE,0,1,e:GetHandler()) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	Duel.SelectTarget(tp,c392.filter,tp,LOCATION_MZONE,0,1,1,e:GetHandler()) 
end
function c392.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if tc and c:IsRelateToEffect(e) and c:IsFaceup() and tc:IsFaceup() and tc:IsRelateToEffect(e) 
            and not tc:IsImmuneToEffect(e) and tc:IsCanBeEffectTarget(e) then
		local code=tc:GetOriginalCode()
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_CHANGE_CODE)
		e1:SetValue(code)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		c:RegisterEffect(e1)
	      local e2=Effect.CreateEffect(c)
	      e2:SetType(EFFECT_TYPE_SINGLE)
            e2:SetCode(EFFECT_DIRECT_ATTACK)
	      e2:SetReset(RESET_EVENT+0x1fe0000)
	      tc:RegisterEffect(e2)
	end
end
