--真紅優越 (K)
function c447.initial_effect(c)
	--remove
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(52971944,1))
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetType(EFFECT_TYPE_ACTIVATE)
	e2:SetCode(EVENT_FREE_CHAIN)
	e2:SetHintTiming(0,TIMING_END_PHASE)
	e2:SetCost(c447.cost2)
	e2:SetTarget(c447.target2)
	e2:SetOperation(c447.operation)
	c:RegisterEffect(e2)
end

function c447.cfilter(c)
	return c:IsFaceup() 
--and (c:IsSetCard(0x911) or c:IsCode(39765958) or c:IsCode(70902743) or c:IsCode(77336644)) and c:IsAbleToRemoveAsCost()
end
function c447.cost2(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c447.cfilter,tp,LOCATION_GRAVE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
	local cg=Duel.SelectMatchingCard(tp,c447.cfilter,tp,LOCATION_GRAVE,0,1,1,nil)
	Duel.Remove(cg,POS_FACEUP,REASON_COST)
      e:SetLabel(cg:GetFirst():GetCode())
end
function c447.target2(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsAbleToRemove() end
	if chk==0 then return Duel.IsExistingTarget(Card.IsFaceup,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g=Duel.SelectTarget(tp,Card.IsFaceup,tp,LOCATION_MZONE,LOCATION_MZONE,1,1,nil)
end
function c447.operation(e,tp,eg,ep,ev,re,r,rp)
	if not e:GetHandler():IsRelateToEffect(e) then return end
	local tc=Duel.GetFirstTarget()
	if tc and tc:IsRelateToEffect(e) then
		tc:CopyEffect(e:GetLabel(),RESET_EVENT+0x1fe0000)
	      local e1=Effect.CreateEffect(e:GetHandler())
	      e1:SetType(EFFECT_TYPE_SINGLE)
	      e1:SetCode(EFFECT_CANNOT_DISABLE)
            e1:SetReset(RESET_EVENT+0x1fe0000)
	      tc:RegisterEffect(e1)
	end
end
