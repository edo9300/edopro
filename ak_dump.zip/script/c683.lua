--地縛囚人 大地防禦士 (K)
function c683.initial_effect(c)
	
end
