--拇指朝下 (K)
function c690.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCategory(CATEGORY_TOGRAVE)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCondition(c690.condition)
	c:RegisterEffect(e1)	

   --damage
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(18158397,0))
	e2:SetCategory(CATEGORY_DAMAGE)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e2:SetRange(LOCATION_SZONE)
	e2:SetCode(EVENT_DESTROY)
	e2:SetTarget(c690.target)
	e2:SetOperation(c690.operation)
	c:RegisterEffect(e2)
end

function c690.filter(c)
	return c:IsFaceup() and c:IsSetCard(0x19)
end
function c690.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.IsExistingMatchingCard(c690.filter,tp,LOCATION_MZONE,0,1,nil)
end

function c690.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsRelateToEffect(e) end
	local g1=eg:FilterCount(Card.IsControler,nil,tp)
	local g2=eg:FilterCount(Card.IsControler,nil,1-tp)
	local p=2
	if g1:GetCount()>0 then p=tp end
	if g2:GetCount()>0 then p=1-tp end
	if g1:GetCount()>0 and g2:GetCount()>0 then p=PLAYER_ALL end
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,PLAYER_ALL,eg:GetCount()*500)
end
function c690.operation(e,tp,eg,ep,ev,re,r,rp)
	if not e:GetHandler():IsRelateToEffect(e) then return end
	local g1=eg:FilterCount(Card.IsControler,nil,tp)
	local g2=eg:FilterCount(Card.IsControler,nil,1-tp)
	local p=2
	if g1:GetCount()>0 and g2:GetCount()==0 then Duel.Damage(tp,eg:GetCount()*500,REASON_EFFECT) end
	if g2:GetCount()>0 and g1:GetCount()==0 then Duel.Damage(1-tp,eg:GetCount()*500,REASON_EFFECT) end
	if g1:GetCount()>0 and g2:GetCount()>0 then
	Duel.Damage(tp,g1:GetCount()*500,REASON_EFFECT) 
	Duel.Damage(1-tp,g2:GetCount()*500,REASON_EFFECT) end
end