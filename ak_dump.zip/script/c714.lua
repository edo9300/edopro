--
function c714.initial_effect(c)
	--xyz summon
	Synchro.AddProcedure(c,aux.FilterBoolFunction(Card.IsAttribute,ATTRIBUTE_DARK),1,1,Synchro.NonTuner(nil),1,99)
	c:EnableReviveLimit()
	
	--spsummon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(80208158,0))
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_DELAY)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_TOGRAVE)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetRange(LOCATION_EXTRA+LOCATION_GRAVE)
	e1:SetCondition(c714.condition)
	e1:SetTarget(c714.target)
	e1:SetOperation(c714.activate)
	c:RegisterEffect(e1)
	
	--destroy all
	local e5=Effect.CreateEffect(c)
	e5:SetDescription(aux.Stringid(13331639,1))
	e5:SetProperty(EFFECT_FLAG_DELAY)   
	e5:SetCategory(CATEGORY_DESTROY)
	e5:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e5:SetCode(EVENT_SPSUMMON_SUCCESS)
	e5:SetTarget(c714.destg)
	e5:SetOperation(c714.desop)
	c:RegisterEffect(e5)	

	local e2=Effect.CreateEffect(c)
	e2:SetCategory(CATEGORY_DESTROY+CATEGORY_DAMAGE)	
	e2:SetDescription(aux.Stringid(84013237,0))
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e2:SetCode(EVENT_ATTACK_ANNOUNCE)
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCountLimit(1)
	e2:SetCondition(c714.atkcon)
	e2:SetTarget(c714.atktg)
	e2:SetOperation(c714.atkop)
	c:RegisterEffect(e2)

	--cannot be target
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CANNOT_SELECT_BATTLE_TARGET)
	e3:SetRange(LOCATION_MZONE)
	e3:SetTargetRange(0,LOCATION_MZONE)
	e3:SetValue(c714.atlimit)
	c:RegisterEffect(e3)	
	
	local e4=Effect.CreateEffect(c)
	e4:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_ATKCHANGE)  
	e4:SetType(EFFECT_TYPE_QUICK_O)
	e4:SetCode(EVENT_FREE_CHAIN)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCost(c714.cost)
	e4:SetTarget(c714.tg)
	e4:SetOperation(c714.op)
	c:RegisterEffect(e4)	
end

--Sp Summon
function c714.filter(c,tp)
	return c:IsType(TYPE_SYNCHRO) and c:IsControler(tp) and bit.band(c:GetSummonType(),SUMMON_TYPE_SYNCHRO)~=0
end
function c714.filter2(c)
	return c:IsFaceup() and c:IsCode(703)
end
function c714.filter5(c,sc,loopchk)
	local tp=c:GetControler()
	if loopchk and loopchk==0 and Duel.GetLocationCountFromEx(tp,tp,c,sc)<1 then return false end
	return c:IsFaceup() and c:IsSetCard(0x20f8) and c:IsReleasableByEffect()
	and Duel.IsExistingMatchingCard(c714.filter5,tp,LOCATION_MZONE,0,1,c,sc) 
end
function c714.condition(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()  
	if c:IsType(TYPE_PENDULUM) and c:IsFaceup() then return false end
	return eg:IsExists(c714.filter,1,nil,1-tp) and not c:IsStatus(STATUS_CHAINING)
	and Duel.IsExistingMatchingCard(c714.filter2,tp,LOCATION_MZONE,0,1,nil)
end
function c714.target(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()  
	local ft=Duel.GetLocationCount(c:GetControler(),LOCATION_MZONE)
	local ct=-ft
	if chk==0 then return Duel.IsExistingMatchingCard(c714.filter5,tp,LOCATION_MZONE,0,1,nil,c,0)  
		and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_SYNCHRO,tp,false,false) end  
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,c,1,0,LOCATION_EXTRA)
	Duel.SetOperationInfo(0,CATEGORY_TOGRAVE,nil,2,0,LOCATION_MZONE)
end
function c714.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()  
	if c:IsRelateToEffect(e) then
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RELEASE)
	local g=Duel.SelectMatchingCard(tp,c714.filter5,tp,LOCATION_MZONE,0,1,1,nil,c,0)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RELEASE)
	local g2=Duel.SelectMatchingCard(tp,c714.filter5,tp,LOCATION_MZONE,0,1,1,g:GetFirst(),c)
	g:Merge(g2)
	if g:GetCount()<2 then return end
	Duel.Release(g,REASON_EFFECT)  
	Duel.SpecialSummon(c,SUMMON_TYPE_SYNCHRO,tp,tp,false,false,POS_FACEUP)
	end
end

function c714.destg(e,tp,eg,ep,ev,re,r,rp,chk)
	local g=Duel.GetMatchingGroup(Card.IsFaceup,tp,0,LOCATION_MZONE,nil)
	if chk==0 then return g:GetCount()>0 end
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,g:GetCount(),0,0)
end
function c714.desop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Duel.GetMatchingGroup(Card.IsFaceup,tp,0,LOCATION_MZONE,nil)
	if g:GetCount()>0 then
		local tc=g:GetFirst()
		while tc do
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE)
		e2:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e2)
		local e3=Effect.CreateEffect(c)
		e3:SetType(EFFECT_TYPE_SINGLE)
		e3:SetCode(EFFECT_DISABLE_EFFECT)
		e3:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e3)
		Duel.AdjustInstantly(tc)		
		tc=g:GetNext() end  
		Duel.Destroy(g,REASON_EFFECT)   
	end
end

function c714.atkcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local at=c:GetBattleTarget()
	return at and at:IsFaceup()
end
function c714.cfilter(c,tp)
	return c:IsControler(1-tp) and c:IsLocation(LOCATION_MZONE) and c:IsFaceup() 
end
function c714.atktg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return false end
	local c=e:GetHandler()
	local bc=c:GetBattleTarget()
	if chk==0 and not c:IsHasEffect(715) then return bc and bc:IsOnField() and bc:IsCanBeEffectTarget(e) end
	if chk==0 and c:IsHasEffect(715) then return Duel.GetMatchingGroup(c714.cfilter,tp,0,LOCATION_MZONE,nil,tp):GetCount()>0 end
	if not c:IsHasEffect(715) then Duel.SetTargetCard(bc) 
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,bc,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,bc:GetAttack()) end
	if c:IsHasEffect(715) then
	e:SetProperty(0)	
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,Duel.GetMatchingGroup(c714.cfilter,tp,0,LOCATION_MZONE,nil,tp),Duel.GetMatchingGroup(c714.cfilter,tp,0,LOCATION_MZONE,nil,tp):GetCount(),0,0)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,Duel.GetMatchingGroup(c714.cfilter,tp,0,LOCATION_MZONE,nil,tp):GetSum(Card.GetAttack())) end 
end
function c714.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Group.CreateGroup() 
	if not c:IsHasEffect(715) then  
	g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
	else
	g=Duel.GetMatchingGroup(c714.cfilter,tp,0,LOCATION_MZONE,nil,tp) end
	if g:GetCount()<1 then return end
	Duel.NegateAttack()
	Duel.Destroy(g,REASON_EFFECT)   
	local g2=Duel.GetOperatedGroup()
	Duel.BreakEffect()
	local tc=g2:GetFirst()
	local tatk=0
	while tc do
		local atk=tc:GetPreviousAttackOnField()
		if atk<0 then atk=0 end
		tatk=tatk+atk
		tc=g2:GetNext() 
	end 
	Duel.Damage(1-tp,tatk,REASON_EFFECT)
end

function c714.atlimit(e,c)
	return c:IsFaceup() and c:IsType(TYPE_SYNCHRO) and c~=e:GetHandler()
end

function c714.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsAbleToExtraAsCost() end
	Duel.SendtoDeck(e:GetHandler(),nil,2,REASON_COST)
end
function c714.filter3(c,e,tp)
	return c:IsSetCard(0x20f8) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and c:IsType(TYPE_PENDULUM)
end
function c714.tg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()  
	if chk==0 then return Duel.IsExistingMatchingCard(c714.filter3,tp,LOCATION_EXTRA,0,2,nil,e,tp) 
		and not Duel.IsPlayerAffectedByEffect(tp,59822133) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,2,0,LOCATION_EXTRA)
end
function c714.xyz(c)
	return c:IsFaceup() and c:IsType(TYPE_SYNCHRO) 
end
function c714.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not Duel.IsExistingMatchingCard(c714.filter3,tp,LOCATION_EXTRA,0,2,nil,e,tp) then return end
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then return end   
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(tp,c714.filter3,tp,LOCATION_EXTRA,0,2,2,nil,e,tp)
	Duel.SpecialSummon(g,0,tp,tp,false,false,POS_FACEUP)		
	local tg=Duel.GetMatchingGroup(c714.xyz,tp,0,LOCATION_MZONE,nil)
	local tc=tg:GetFirst()
	while tc do
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_SET_ATTACK_FINAL)
		e1:SetValue(0)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
		tc=tg:GetNext()
	end
end