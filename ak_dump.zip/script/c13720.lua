--Evil 1
function c13720.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_BATTLE_CONFIRM)
	  e1:SetCondition(c13720.condition)
	  e1:SetOperation(c13720.operation)
	c:RegisterEffect(e1)
	
	  local e2=Effect.CreateEffect(c)
	  e2:SetType(EFFECT_TYPE_IGNITION)
	  e2:SetCategory(CATEGORY_DESTROY)
	  e2:SetRange(LOCATION_SZONE)
	  e2:SetCountLimit(1)
	  e2:SetCondition(c13720.con) 
	e2:SetCost(c13720.cost)
	  e2:SetTarget(c13720.tg)
	e2:SetOperation(c13720.op)
	  c:RegisterEffect(e2)
end

function c13720.condition(e,tp,eg,ep,ev,re,r,rp)
	  return Duel.GetAttackTarget()~=nil and Duel.GetAttacker()~=nil and Duel.GetAttackTarget():GetControler()~=Duel.GetAttacker():GetControler()
end
function c13720.filter(c)
	  if Duel.GetAttackTarget()~=nil and Duel.GetAttacker()~=nil then
	  return Duel.GetAttackTarget()==c or Duel.GetAttacker()==c  end
end
function c13720.operation(e,tp,eg,ep,ev,re,r,rp)
	 local c=e:GetHandler()
	 local g=Duel.GetFirstMatchingCard(c13720.filter,tp,LOCATION_MZONE,0,nil)
	 local e1=Effect.CreateEffect(c)
	 e1:SetType(EFFECT_TYPE_SINGLE)
	 e1:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
	 e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_DAMAGE) 
	 e1:SetValue(1)
	 g:RegisterEffect(e1)
	 local e2=Effect.CreateEffect(c)
	 e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	 e2:SetCode(EVENT_PRE_DAMAGE_CALCULATE)
	 e2:SetRange(LOCATION_SZONE)
	 e2:SetOperation(c13720.rdop)
	 e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_DAMAGE)
	 c:RegisterEffect(e2)
end
function c13720.rdop(e,tp,eg,ep,ev,re,r,rp)
	  local c=e:GetHandler()
	  local ttp=c:GetControler()
	  if Duel.GetBattleDamage(ttp)>=Duel.GetLP(ttp) then
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_CHANGE_DAMAGE)
	e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e3:SetTargetRange(1,0)
	e3:SetValue(Duel.GetLP(tp)-1)
	e3:SetReset(RESET_PHASE+PHASE_DAMAGE)
	Duel.RegisterEffect(e3,ttp) end
	  --Duel.ChangeBattleDamage(tp,Duel.GetLP(tp)-1) end 
end

function c13720.con(e,tp,eg,ep,ev,re,r,rp)
	  return Duel.GetCurrentPhase()==PHASE_MAIN1
end
function c13720.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return c:IsAbleToGraveAsCost() end
	Duel.SendtoGrave(c,REASON_COST)
end
function c13720.tg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then
		return Duel.IsExistingMatchingCard(aux.TRUE,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,1,nil) end
end
function c13720.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	  local g=Duel.GetMatchingGroup(aux.TRUE,tp,LOCATION_ONFIELD,LOCATION_ONFIELD,nil)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_DESTROY)
	local dg=g:Select(tp,1,1,e:GetHandler())
	if Duel.Destroy(dg,REASON_EFFECT)>0 then
	  Duel.SkipPhase(tp,PHASE_BATTLE,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END,1) end
end
