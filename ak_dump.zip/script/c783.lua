--機炮魔人 (K)
function c783.initial_effect(c)
	local e2=Effect.CreateEffect(c)
	  e2:SetProperty(EFFECT_FLAG_PLAYER_TARGET) 
	e2:SetCategory(CATEGORY_TOGRAVE+CATEGORY_DAMAGE)
	e2:SetType(EFFECT_TYPE_IGNITION)
	--e2:SetCountLimit(1)
	e2:SetRange(LOCATION_MZONE)
	e2:SetTarget(c783.tg)
	e2:SetOperation(c783.op)
	c:RegisterEffect(e2)
end

function c783.filter(c)
	return aux.TRUE and c:IsFacedown() and c:IsAbleToGrave()
end
function c783.tg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return Duel.IsExistingMatchingCard(c783.filter,tp,LOCATION_SZONE,0,1,nil) end
	local g=Duel.GetMatchingGroup(c783.filter,tp,LOCATION_SZONE,0,nil)
	Duel.SetOperationInfo(0,CATEGORY_TOGRAVE,g,g:GetCount(),0,0)
	  Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,g:GetCount()*800) 
end
function c783.op(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetMatchingGroup(c783.filter,tp,LOCATION_SZONE,0,nil)
	if g:GetCount()~=0 then
		Duel.SendtoGrave(g,REASON_EFFECT)
			local og=Duel.GetOperatedGroup()
		local ct=og:FilterCount(Card.IsLocation,nil,LOCATION_GRAVE)
		if ct>0 then
				  Duel.BreakEffect()
				Duel.Damage(1-tp,ct*800,REASON_EFFECT)
		end
	end
end
