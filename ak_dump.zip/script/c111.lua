--Relay Soul
function c111.initial_effect(c)
	local e18=Effect.CreateEffect(c)
	e18:SetType(EFFECT_TYPE_FIELD)
	e18:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_PLAYER_TARGET)
	e18:SetCode(EFFECT_CANNOT_LOSE_KOISHI)
	e18:SetCondition(c111.actcondition)
	e18:SetTargetRange(1,0)
	e18:SetValue(1)
	Duel.RegisterEffect(e18,0)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_DELAY)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetCode(EVENT_BATTLE_DAMAGE)
	e1:SetCondition(c111.condition)
	e1:SetTarget(c111.target)
	e1:SetOperation(c111.activate)
	c:RegisterEffect(e1)
end

function c111.actcondition(e,c)
	local c=e:GetOwner()
	return (c:GetFlagEffect(317)~=0)
	or (Duel.CheckEvent(EVENT_BATTLE_DAMAGE) and Duel.GetBattleDamage(e:GetHandlerPlayer())>0 
	  and Duel.IsExistingMatchingCard(c111.filter,e:GetHandlerPlayer(),LOCATION_HAND,0,1,nil,e,tp) and Duel.GetLocationCount(e:GetHandlerPlayer(),LOCATION_MZONE)>0 
	  and c:GetFlagEffect(317)==0) 
end

function c111.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetBattleDamage(tp)>0 
end
function c111.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c111.filter,tp,LOCATION_HAND,0,1,nil,e,tp)
			and Duel.GetLocationCount(tp,LOCATION_MZONE)>0 end
	e:GetHandler():RegisterFlagEffect(317,RESET_CHAIN,0,1)		  
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_HAND)
end
function c111.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if Duel.GetLocationCount(tp,LOCATION_MZONE)==0 then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local sg=Duel.SelectMatchingCard(tp,c111.filter,tp,LOCATION_HAND,0,1,1,nil,e,tp)
	if sg:GetCount()==0 then return end
	local tc=sg:GetFirst()
	if Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP)>0 then
	local e18=Effect.CreateEffect(c)
	e18:SetType(EFFECT_TYPE_FIELD)
	e18:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_PLAYER_TARGET)
	e18:SetCode(EFFECT_CANNOT_LOSE_LP)
	e18:SetRange(LOCATION_MZONE)
	e18:SetTargetRange(1,0)
	e18:SetValue(1)
	tc:RegisterEffect(e18,true)
	local e19=e18:Clone()
	e19:SetCode(EFFECT_CANNOT_LOSE_DECK)
	tc:RegisterEffect(e19,true)
	local e20=e18:Clone()
	e20:SetCode(EFFECT_CANNOT_LOSE_EFFECT)
	tc:RegisterEffect(e20,true)

			local e02=Effect.CreateEffect(c)
			e02:SetType(EFFECT_TYPE_FIELD)
			e02:SetCode(EFFECT_DRAW_COUNT)
			e02:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_PLAYER_TARGET)
			e02:SetRange(LOCATION_MZONE)
			e02:SetTargetRange(1,0)
			e02:SetCondition(c111.dc)
			e02:SetValue(0)
			--tc:RegisterEffect(e02,true)
			
	   local e115=Effect.CreateEffect(c)
	   e115:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	   e115:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	   e115:SetCode(EVENT_LEAVE_FIELD)
	   e115:SetOperation(c111.lose)
	   tc:RegisterEffect(e115,true) end
end

function c111.filter(c,e,tp)
	return c:IsCanBeSpecialSummoned(e,0,tp,false,false)
end
function c111.dc(e)
local tp=e:GetOwner():GetControler()
return Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)<1
end
function c111.losecon(e,tp,eg,ep,ev,re,r,rp)
	  local tc=e:GetHandler() 
	return tc:IsFacedown() or tc:IsDisabled() or not c:IsLocation(LOCATION_MZONE)
end
function c111.lose(e,tp,eg,ep,ev,re,r,rp)
	  local tc=e:GetLabelObject()
	  local ttp=tc:GetControler()
	local WIN_REASON_RELAY_SOUL=0x100
	Duel.Win(1-ttp,WIN_REASON_RELAY_SOUL)
end
