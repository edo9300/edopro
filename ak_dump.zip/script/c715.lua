--霸王烈氣 (K)
function c715.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_EQUIP)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetTarget(c715.target)
	e1:SetOperation(c715.operation)
	c:RegisterEffect(e1)
	
	--Equip limit
	local e8=Effect.CreateEffect(c)
	e8:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e8:SetType(EFFECT_TYPE_SINGLE)
	e8:SetCode(EFFECT_EQUIP_LIMIT)
	e8:SetValue(c715.eqlimit)
	c:RegisterEffect(e8)	

	local e30=Effect.CreateEffect(c)
	e30:SetType(EFFECT_TYPE_EQUIP)
	e30:SetCode(715)
	c:RegisterEffect(e30)		
	
	local e4=Effect.CreateEffect(c)
	e4:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)	
	e4:SetType(EFFECT_TYPE_QUICK_F)
	e4:SetCode(EVENT_CHAINING)
	e4:SetRange(LOCATION_SZONE)
	e4:SetCondition(c715.damcon)
	e4:SetTarget(c715.damtg)
	e4:SetOperation(c715.damop)
	--c:RegisterEffect(e4)
end

function c715.eqlimit(e,c)
	return c:IsSetCard(0xf8) and c:IsType(TYPE_MONSTER)
end

function c715.filter(c)
	return c:IsFaceup() and c:IsSetCard(0xf8) and c:IsType(TYPE_MONSTER)
end
function c715.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and c715.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c715.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_EQUIP)
	Duel.SelectTarget(tp,c715.filter,tp,LOCATION_MZONE,LOCATION_MZONE,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_EQUIP,e:GetHandler(),1,0,0)
end
function c715.operation(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if e:GetHandler():IsRelateToEffect(e) and tc:IsRelateToEffect(e) and tc:IsFaceup() then
		Duel.Equip(tp,e:GetHandler(),tc)
	end
end

function c715.cfilter(c,tp)
	return c:IsControler(1-tp) and c:IsLocation(LOCATION_MZONE) and c:IsFaceup()
end
function c715.damcon(e,tp,eg,ep,ev,re,r,rp)
    local ec=e:GetHandler():GetEquipTarget()
	if ec==nil or not (re:IsHasProperty(EFFECT_FLAG_CARD_TARGET)
		and re:IsActiveType(TYPE_MONSTER) and re:GetHandler()==ec) then return false end
	local g=Duel.GetChainInfo(ev,CHAININFO_TARGET_CARDS)
	if not g or g:GetCount()~=1 then return false end
	local tc=g:GetFirst()
	e:SetLabelObject(tc)	
	return c715.cfilter(tc,tp)
end
function c715.damtg(e,tp,eg,ep,ev,re,r,rp,chk)
	local tc=e:GetLabelObject()
	if chk==0 then return tc end
end
function c715.damop(e,tp,eg,ep,ev,re,r,rp)
	Duel.ChangeTargetCard(ev,Duel.GetMatchingGroup(c715.cfilter,tp,0,LOCATION_MZONE,nil,tp))
end
