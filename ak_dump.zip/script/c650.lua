--魔玩具・聖域 (K)
function c650.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCost(c650.cost)   
	c:RegisterEffect(e1)	
	
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetRange(LOCATION_SZONE)
	e2:SetTargetRange(LOCATION_MZONE,0)
	e2:SetCode(EFFECT_ADD_SETCODE)
	e2:SetTarget(aux.TargetBoolFunction(Card.IsType,TYPE_FUSION))
	e2:SetValue(0xad)
	c:RegisterEffect(e2)	
end

function c650.cfilter(c)
	return c:IsAbleToGraveAsCost()
end
function c650.cfilter2(c)
	return c:IsAbleToGraveAsCost() and c:IsSetCard(0xad)
end
function c650.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c650.cfilter,tp,LOCATION_HAND,0,1,e:GetHandler())
				   and Duel.IsExistingMatchingCard(c650.cfilter2,tp,LOCATION_EXTRA,0,2,nil) end
	Duel.DiscardHand(tp,c650.cfilter,1,1,REASON_COST)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TOGRAVE)
	local g=Duel.SelectMatchingCard(tp,c650.cfilter2,tp,LOCATION_EXTRA,0,2,2,nil)   
	if g:GetCount()>0 then
		Duel.SendtoGrave(g,REASON_COST)
	end 
end


