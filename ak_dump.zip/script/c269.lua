--フォトン・カイザー
function c269.initial_effect(c)
	--xyz
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(511001225)
	e2:SetValue(1)
	c:RegisterEffect(e2)
end

