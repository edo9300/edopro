--マアト
function c216.initial_effect(c)
	--pendulum summon
	aux.EnablePendulumAttribute(c)

	--announce 3 cards
	local e3=Effect.CreateEffect(c)
	e3:SetDescription(aux.Stringid(18631392,0))
	e3:SetType(EFFECT_TYPE_IGNITION)
	e3:SetRange(LOCATION_PZONE)
	--e3:SetCountLimit(1)
	e3:SetTarget(c216.anctg)
	c:RegisterEffect(e3)

	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(18631392,0))
	e1:SetType(EFFECT_TYPE_IGNITION)
      e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCountLimit(1)
	e1:SetTarget(c216.target)
	e1:SetOperation(c216.operation)
	c:RegisterEffect(e1)
end

function c216.anctg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)>=1 
                     and Duel.IsExistingMatchingCard(c216.filter,tp,LOCATION_HAND+LOCATION_GRAVE+LOCATION_REMOVED+LOCATION_EXTRA,0,1,nil)
                     and e:GetHandler():GetFlagEffect(216)==0 and Duel.GetFlagEffect(tp,217)<3 end
	Duel.Hint(HINT_SELECTMSG,tp,0)
	--local ac1=Duel.AnnounceCard(tp)
      local ac1=Duel.SelectOption(tp,aux.Stringid(13707,0),aux.Stringid(13707,1),aux.Stringid(13707,2),aux.Stringid(13707,3),aux.Stringid(13707,4))
      local opt=0
      if ac1==0 then opt=0x3008 end
      if ac1==1 then opt=0x6008 end
      if ac1==2 then opt=0xc008 end
      if ac1==3 then opt=0x5008 end
      if ac1==4 then opt=0xa008 end
      e:GetHandler():RegisterFlagEffect(216,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END,0,1)
      Duel.RegisterFlagEffect(tp,217,0,0,0)
	e:SetOperation(c216.retop(opt))
end
function c216.filter(c)
	return c:IsSetCard(0x3008) or c:IsSetCard(0x5008) or c:IsSetCard(0x6008) or c:IsSetCard(0xa008) or c:IsSetCard(0xc008) or
             c:IsCode(23204029) or c:IsCode(501000018)
end
function c216.hfilter(c,opt)
	return c:IsSetCard(opt)
end
function c216.retop(opt)
	return
		function (e,tp,eg,ep,ev,re,r,rp)
			local c=e:GetHandler()
                  local g=Duel.GetDecktopGroup(tp,1)
			local hg=g:Filter(c216.hfilter,nil,opt)
			if hg:GetCount()~=0 then
				Duel.ConfirmCards(1-tp,hg)
				Duel.ShuffleHand(tp)
               	      Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
                        local a=Duel.SelectMatchingCard(tp,c216.filter,tp,LOCATION_HAND+LOCATION_GRAVE+LOCATION_REMOVED+LOCATION_EXTRA,0,1,1,nil)
                        if a:GetCount()~=1 then return end
                        local ac1=Duel.SelectOption(tp,aux.Stringid(13707,0),aux.Stringid(13707,1),aux.Stringid(13707,2),aux.Stringid(13707,3),aux.Stringid(13707,4),aux.Stringid(13707,5)) 
                        local opt=0
                        if ac1==0 then opt=0x3008 end
                        if ac1==1 then opt=0x6008 end
                        if ac1==2 then opt=0xc008 end
                        if ac1==3 then opt=0x5008 end
                        if ac1==4 then opt=0xa008 end
                        if ac1==5 then opt=0x908 end
                        if not a:GetFirst():IsSetCard(opt) then
                        local e1=Effect.CreateEffect(c)
                        e1:SetType(EFFECT_TYPE_SINGLE)
                        e1:SetCode(EFFECT_ADD_SETCODE)
                        e1:SetValue(opt)
                        e1:SetReset(RESET_PHASE+PHASE_END)
                        a:GetFirst():RegisterEffect(e1) end
                        e:GetHandler():ResetFlagEffect(216)
			end
			if hg:GetCount()==0 then
				Duel.ConfirmCards(1-tp,g)
				Duel.ShuffleHand(tp)
				Duel.SendtoGrave(g:GetFirst(),REASON_EFFECT+REASON_REVEAL)
			end
		end
end

function c216.filter1(c,e)
	return c:IsCanBeFusionMaterial() and not c:IsImmuneToEffect(e)
end
function c216.filter2(c,e,tp,m,f,chkf)
	return c:IsType(TYPE_FUSION) and (not f or f(c))
		and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_FUSION,tp,false,false) and c:CheckFusionMaterial(m,nil,chkf)
end
function c216.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then
		local chkf=Duel.GetLocationCount(tp,LOCATION_MZONE)>0 and PLAYER_NONE or tp
		local mg1=Duel.GetMatchingGroup(c216.filter1,tp,LOCATION_HAND+LOCATION_MZONE,0,nil,e)
		local res=Duel.IsExistingMatchingCard(c216.filter2,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg1,nil,chkf)
		if not res then
			local ce=Duel.GetChainMaterial(tp)
			if ce~=nil then
				local fgroup=ce:GetTarget()
				local mg2=fgroup(ce,e,tp)
				local mf=ce:GetValue()
				res=Duel.IsExistingMatchingCard(c216.filter2,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg2,mf,chkf)
			end
		end
		return res
	end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
end
function c216.operation(e,tp,eg,ep,ev,re,r,rp)
	local chkf=Duel.GetLocationCount(tp,LOCATION_MZONE)>0 and PLAYER_NONE or tp
	if not e:GetHandler():IsRelateToEffect(e) then return end
	local mg1=Duel.GetMatchingGroup(c216.filter1,tp,LOCATION_HAND+LOCATION_MZONE,0,nil,e)
	local sg1=Duel.GetMatchingGroup(c216.filter2,tp,LOCATION_EXTRA,0,nil,e,tp,mg1,nil,chkf)
	local mg2=nil
	local sg2=nil
	local ce=Duel.GetChainMaterial(tp)
	if ce~=nil then
		local fgroup=ce:GetTarget()
		mg2=fgroup(ce,e,tp)
		local mf=ce:GetValue()
		sg2=Duel.GetMatchingGroup(c216.filter2,tp,LOCATION_EXTRA,0,nil,e,tp,mg2,mf,chkf)
	end
	if sg1:GetCount()>0 or (sg2~=nil and sg2:GetCount()>0) then
		local sg=sg1:Clone()
		if sg2 then sg:Merge(sg2) end
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local tg=sg:Select(tp,1,1,nil)
		local tc=tg:GetFirst()
		if sg1:IsContains(tc) and (sg2==nil or not sg2:IsContains(tc) or not Duel.SelectYesNo(tp,ce:GetDescription())) then
			local mat1=Duel.SelectFusionMaterial(tp,tc,mg1,nil,chkf)
			tc:SetMaterial(mat1)
			Duel.SendtoGrave(mat1,REASON_EFFECT+REASON_MATERIAL+REASON_FUSION)
			Duel.BreakEffect()
			Duel.SpecialSummon(tc,SUMMON_TYPE_FUSION,tp,tp,false,false,POS_FACEUP)
		else
			local mat2=Duel.SelectFusionMaterial(tp,tc,mg2,nil,chkf)
			local fop=ce:GetOperation()
			fop(ce,e,tp,tc,mat2)
		end
		tc:CompleteProcedure()
	end
end
