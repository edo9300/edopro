--Overlay Accel
function c11370093.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
      e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(0,TIMING_END_PHASE)
	e1:SetTarget(c11370093.target1)
	e1:SetOperation(c11370093.drop)
	c:RegisterEffect(e1)
	--draw
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(72989439,2))
	e2:SetCategory(CATEGORY_DRAW)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	--e2:SetProperty(EFFECT_FLAG_DAMAGE_STEP)
	e2:SetCode(EVENT_BATTLE_DESTROYING)
	e2:SetRange(LOCATION_SZONE)
      e2:SetLabel(1)
	e2:SetCondition(c11370093.drcon)
	e2:SetOperation(c11370093.drop)
	c:RegisterEffect(e2)
end

function c11370093.target1(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return true end
	local tc=Duel.GetAttacker()
      if tc~=nil then
	local bc=tc:GetBattleTarget()
	if bc~=nil and bc:IsType(TYPE_MONSTER) and bc:IsControler(1-tp) and bc:IsStatus(STATUS_BATTLE_DESTROYED)
       and tc:IsRelateToBattle() and tc:IsControler(tp) and tc:IsType(TYPE_XYZ) and tc:GetOverlayCount()>=1 and tc:IsStatus(STATUS_OPPO_BATTLE) and tc:IsChainAttackable(100,false) 
       and Duel.SelectYesNo(tp,aux.Stringid(24696097,0)) then
	e:SetLabel(1) end end
end
function c11370093.drcon(e,tp,eg,ep,ev,re,r,rp)
	local tc=eg:GetFirst()
	local bc=tc:GetBattleTarget()
	return eg:GetCount()==1 and bc:IsType(TYPE_MONSTER) and bc:IsControler(1-tp) 
       and tc:IsRelateToBattle() and tc:IsControler(tp) and tc:IsType(TYPE_XYZ) and tc:GetOverlayCount()>=1 and tc:IsStatus(STATUS_OPPO_BATTLE) and tc:IsChainAttackable(100,false) 
end
function c11370093.drop(e,tp,eg,ep,ev,re,r,rp)
      if e:GetLabel()~=1 then return end
	local tc=eg:GetFirst()
      if tc:GetOverlayCount()<1 then return end
	tc:RemoveOverlayCard(tp,1,1,REASON_EFFECT)
	Duel.ChainAttack()
end
