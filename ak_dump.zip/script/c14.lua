--特殊系統卡 風暴連線 (K)
function c14.initial_effect(c)
	
end
