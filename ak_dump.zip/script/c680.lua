--地縛戒隸 地鬼 (K)
function c680.initial_effect(c)
	--synchro summon
	aux.AddSynchroProcedure(c,aux.FilterBoolFunction(c680.spfilter),1,1,aux.NonTuner(c680.spfilter),1,99)
	c:EnableReviveLimit()   

	local e2=Effect.CreateEffect(c)
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetCategory(CATEGORY_DESTROY+CATEGORY_RECOVER)
	e2:SetType(EFFECT_TYPE_IGNITION)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCondition(c680.descon)
	e2:SetTarget(c680.atktg)
	e2:SetCountLimit(1)
	e2:SetOperation(c680.damop)
	c:RegisterEffect(e2)  
end

function c680.spfilter(c)
	return c:IsSetCard(0x901) or c:IsSetCard(0x21)
end


function c680.descon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local myfield=Duel.GetFieldCard(tp,LOCATION_SZONE,5)
	local oppfield=Duel.GetFieldCard(1-tp,LOCATION_SZONE,5)
	return ((myfield~=nil and myfield:IsFaceup())
	or (oppfield~=nil and oppfield:IsFaceup()))
	and c:GetTurnID()==Duel.GetTurnCount() and bit.band(c:GetSummonType(),SUMMON_TYPE_SPECIAL)==SUMMON_TYPE_SPECIAL  
	and Duel.GetCurrentPhase()==PHASE_MAIN_1
end
function c680.atkfilter(c)
	return c:IsFaceup() and aux.TRUE
end
function c680.atktg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(1-tp) and c680.atkfilter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c680.atkfilter,tp,0,LOCATION_MZONE,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	local g=Duel.SelectTarget(tp,c680.atkfilter,tp,0,LOCATION_MZONE,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_RECOVER,nil,0,tp,g:GetFirst():GetAttack())
end
function c680.damop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc and tc:IsRelateToEffect(e) and tc:IsFaceup() then
	   if Duel.SelectYesNo(1-tp,aux.Stringid(5975022,0)) then
		  if Duel.Destroy(tc,REASON_EFFECT)>0 then
	local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetTargetRange(1,0)
	e1:SetCode(EFFECT_SKIP_BP) 
	e1:SetReset(RESET_PHASE+PHASE_END)
	Duel.RegisterEffect(e1,tp)
	end
	   else Duel.Recover(tp,tc:GetAttack(),REASON_EFFECT) end end
end