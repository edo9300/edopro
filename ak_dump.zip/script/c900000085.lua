--��֮�����ƻ�����
function c900000085.initial_effect(c)
	
	--�ƻ��Է�1500���Ϲ����Ĺ���
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCategory(CATEGORY_DESTROY)
	e1:SetCode(EVENT_BATTLE_END)
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP)
	e1:SetCondition(c900000085.condition)
	e1:SetTarget(c900000085.target)
	e1:SetOperation(c900000085.activate)
	c:RegisterEffect(e1)
end
-------------------------------------------------------------------------------------------------------------------------------------------
	function c900000085.condition(e,tp,eg,ep,ev,re,r,rp)
	local d=Duel.GetAttackTarget()
	local a=Duel.GetAttacker()
	if Duel.GetAttackTarget()==nil or Duel.GetAttacker()==nil then return end
	return d:IsControler(tp) and d:IsAttribute(ATTRIBUTE_DARK) and d:IsAttackBelow(1000) and d:IsStatus(STATUS_BATTLE_DESTROYED)
	or (a:IsControler(tp) and a:IsAttribute(ATTRIBUTE_DARK) and a:IsAttackBelow(1000) and a:IsStatus(STATUS_BATTLE_DESTROYED))
end

function c900000085.tgfilter(c)
	return c:IsType(TYPE_MONSTER) and c:IsAttackAbove(1500)
end

function c900000085.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	local g=Duel.GetMatchingGroup(c900000085.tgfilter,tp,0,LOCATION_MZONE+LOCATION_HAND+LOCATION_DECK,nil)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,g,g:GetCount(),0,0)
end

function c900000085.activate(e,tp,eg,ep,ev,re,r,rp)
	local g=Duel.GetMatchingGroup(c900000085.tgfilter,tp,0,LOCATION_MZONE+LOCATION_HAND+LOCATION_DECK,nil)
	local c=e:GetHandler()
	local tc=g:GetFirst()
	while tc do
	Duel.Destroy(tc,REASON_EFFECT)
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_SINGLE_RANGE)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetRange(LOCATION_GRAVE)
	e1:SetCode(EFFECT_SPSUMMON_CONDITION)
	e1:SetValue(aux.FALSE)
	tc:RegisterEffect(e1)
	tc=g:GetNext()
	end
end
