--Dimension Xyz
function c51370058.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCondition(c51370058.condition)
	  e1:SetTarget(c51370058.target)
	e1:SetOperation(c51370058.activate)
	c:RegisterEffect(e1)
end

function c51370058.cfilter(c)
	  local loc=c:GetLocation()
	return Duel.IsExistingMatchingCard(c51370058.cfilter2,tp,LOCATION_MZONE+LOCATION_HAND+LOCATION_GRAVE,0,1,c,c:GetCode(),c) and not c:IsHasEffect(EFFECT_NECRO_VALLEY) and aux.MustMaterialCheck(c,tp,EFFECT_MUST_BE_XMATERIAL)
end
function c51370058.cfilter2(c,code,tc)
	  local loc=tc:GetLocation()
	  local loc2=c:GetLocation()
	return c:GetCode()==code and loc2~=loc
	  and Duel.IsExistingMatchingCard(c51370058.cfilter3,tp,LOCATION_MZONE+LOCATION_HAND+LOCATION_GRAVE,0,1,c,code,tc,c) and not c:IsHasEffect(EFFECT_NECRO_VALLEY) and aux.MustMaterialCheck(c,tp,EFFECT_MUST_BE_XMATERIAL)
end
function c51370058.cfilter3(c,code,tc,tc2)
	  local loc=tc:GetLocation()
	  local loc2=tc2:GetLocation()
	  local loc3=c:GetLocation()
	  local mg=Group.CreateGroup()
	  mg:AddCard(tc)
	  mg:AddCard(tc2)
	  mg:AddCard(c) 
	return c:GetCode()==code and loc3~=loc and loc3~=loc2 and not c:IsHasEffect(EFFECT_NECRO_VALLEY) and aux.MustMaterialCheck(c,tp,EFFECT_MUST_BE_XMATERIAL)
	  --and Duel.IsExistingMatchingCard(c51370058.xyzfilter,tp,LOCATION_EXTRA,0,1,nil,mg,e,tp)
end
function c51370058.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetLP(tp)<=1000
end
function c51370058.xyzfilter(c,mg,e,tp)
	  if not c:IsType(TYPE_XYZ) then return end
	  if c:IsType(TYPE_PENDULUM) and c:IsFaceup() then return false end
	if c.minxyzct==nil or (c.minxyzct and c.minxyzct~=3) then return false end
	return c:IsXyzSummonable(mg) 
--and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,false,false) 
end
function c51370058.xyzfilter2(c,tc,e,tp)
	if c.minxyzct~=3 then return false end
	  local mg=Group.CreateGroup()
	  local tc2=tc  local tc3=tc
	  mg:AddCard(tc)
	  mg:AddCard(tc2)
	  mg:AddCard(tc3)	 
	return c:IsXyzSummonable(mg) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,false,false) 
end
function c51370058.target(e,tp,eg,ep,ev,re,r,rp,chk)
	  local mg=Duel.GetMatchingGroup(c51370058.cfilter,tp,LOCATION_MZONE+LOCATION_HAND+LOCATION_GRAVE,0,nil)
	if chk==0 then return Duel.IsExistingMatchingCard(c51370058.xyzfilter,tp,LOCATION_EXTRA,0,1,nil,mg) and Duel.GetLocationCountFromEx(tp)>0 end
--Duel.IsExistingMatchingCard(c51370058.cfilter,tp,LOCATION_MZONE+LOCATION_HAND+LOCATION_GRAVE,0,1,nil,e,tp) end
	  Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,LOCATION_EXTRA)
end
function c51370058.activate(e,tp,eg,ep,ev,re,r,rp)
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
	local g=Duel.SelectMatchingCard(tp,c51370058.cfilter,tp,LOCATION_MZONE,0,1,1,nil,e,tp)
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
	local g2=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_HAND,0,1,1,g:GetFirst(),g:GetFirst():GetCode())
	  g:Merge(g2)
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
	local g3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_GRAVE,0,1,1,g:GetFirst(),g:GetFirst():GetCode())
	  g:Merge(g3)
	if g:GetCount()~=3 or not aux.MustMaterialCheck(g,tp,EFFECT_MUST_BE_XMATERIAL) or Duel.GetLocationCountFromEx(tp)<1 then return end
	local xyzg=Duel.GetMatchingGroup(c51370058.xyzfilter,tp,LOCATION_EXTRA,0,nil,g)
	if xyzg:GetCount()>0 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local xyz=xyzg:Select(tp,1,1,nil):GetFirst()
		Duel.XyzSummon(tp,xyz,g)
	end
end
