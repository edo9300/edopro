--No.系存在 (K)
function c395.initial_effect(c)
	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_ATKCHANGE)
	e3:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e3:SetType(EFFECT_TYPE_ACTIVATE)
	e3:SetCode(EVENT_FREE_CHAIN)
	e3:SetTarget(c395.tg)
	e3:SetOperation(c395.op)
	c:RegisterEffect(e3)
end

function c395.eqfilter(c,tp)
	return c:IsControler(tp) and c:IsFaceup() and c:IsSetCard(0x48)
end
function c395.eqfilter2(c,tp)
	return c:IsControler(tp) and c:IsFaceup() and c:IsSetCard(0x48) and c:GetAttack()>0
end
function c395.tg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local c=e:GetHandler()
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and c395.eqfilter(chkc,tp) end
	if chk==0 then return Duel.IsExistingTarget(c395.eqfilter,tp,LOCATION_MZONE,0,2,nil,tp) 
      and Duel.IsExistingTarget(c395.eqfilter,tp,LOCATION_MZONE,0,1,nil,tp) end
      Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g2=Duel.SelectTarget(tp,c395.eqfilter2,tp,LOCATION_MZONE,0,1,1,nil)
      local tc=g2:GetFirst()
      Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g=Duel.SelectTarget(tp,c395.eqfilter,tp,LOCATION_MZONE,0,1,1,tc,tp)
      g2:Merge(g)
	Duel.SetOperationInfo(0,CATEGORY_ATKCHANGE,g2,2,0,0)
end
function c395.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS):Filter(Card.IsRelateToEffect,nil,e)
      if g:GetCount()<=0 then return end
      local tc2=g:GetFirst()
	local tc1=g:GetNext()
      if tc1~=nil and tc2~=nil then
            local atk=tc1:GetAttack()
	      if tc1:IsFaceup() and tc1:IsRelateToEffect(e) and tc2:IsFaceup() and tc2:IsRelateToEffect(e) and atk>0 then
			local e1=Effect.CreateEffect(c)
			e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetCode(EFFECT_SET_ATTACK_FINAL)
			e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
			e1:SetValue(0)
			tc1:RegisterEffect(e1)
                  if not tc1:IsImmuneToEffect(e) then
			local e2=Effect.CreateEffect(c)
			e2:SetType(EFFECT_TYPE_SINGLE)
			e2:SetCode(EFFECT_UPDATE_ATTACK)
			e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
			e2:SetValue(atk)
			tc2:RegisterEffect(e2) end
            end end
end
