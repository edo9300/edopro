--エッジインプ・シザー
function c656.initial_effect(c)
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET) 
	e1:SetCategory(CATEGORY_TOHAND+CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e1:SetCode(EVENT_SUMMON_SUCCESS)
	e1:SetTarget(c656.target)
	e1:SetOperation(c656.operation)
	c:RegisterEffect(e1)
	local e2=e1:Clone()
	e2:SetCode(EVENT_SPSUMMON_SUCCESS)
	c:RegisterEffect(e2)	
end

function c656.filter(c)
	return c:IsFaceup() and c:IsSetCard(0xa9) and c:IsAbleToHand()
end
function c656.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsControler(tp) and chkc:IsLocation(LOCATION_MZONE) and c656.filter(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c656.filter,tp,LOCATION_MZONE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)
	local g=Duel.SelectTarget(tp,c656.filter,tp,LOCATION_MZONE,0,1,1,nil)
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,g,g:GetCount(),0,0)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,0)
end
function c656.operation(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsFaceup() and tc:IsRelateToEffect(e) then
		if Duel.SendtoHand(tc,nil,REASON_EFFECT)>0 and tc:IsLocation(LOCATION_HAND) then
		Duel.ConfirmCards(1-tp,sg)
		Duel.BreakEffect()
		local mg=Duel.GetMatchingGroup(c656.spfilter,tp,LOCATION_HAND,0,nil,e,tp)
		if mg:GetCount()==0 then return end
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local sc2=mg:Select(tp,1,1,nil):GetFirst()
		Duel.SpecialSummon(sc2,0,tp,tp,false,false,POS_FACEUP)
	end end
end
function c656.spfilter(c,e,tp)
	return c:IsSetCard(0xa9) and c:IsCanBeSpecialSummoned(e,0,tp,false,false)
end