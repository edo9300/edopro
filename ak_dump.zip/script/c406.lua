--風來覇王 野風 (K)
function c406.initial_effect(c)
	
end
