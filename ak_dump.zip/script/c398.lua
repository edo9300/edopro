--Junk Armor (K)
function c398.initial_effect(c)
	
end
