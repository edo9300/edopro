--XX 剑斗兽 罪斗 (K)
function c695.initial_effect(c)
	--spsummon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(80208158,0))
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e1:SetCode(EVENT_ATTACK_ANNOUNCE)
	e1:SetRange(LOCATION_HAND)
	e1:SetCondition(c695.condition)
	e1:SetTarget(c695.target)
	e1:SetOperation(c695.activate)
	c:RegisterEffect(e1)	
end

--Sp Summon
function c695.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetFieldGroupCount(tp,LOCATION_MZONE+LOCATION_SZONE,0)==0 
      and Duel.GetAttacker():IsControler(1-tp)
end
function c695.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and e:GetHandler():IsCanBeSpecialSummoned(e,0,tp,false,false) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,e:GetHandler(),1,0,0)
end
function c695.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if c:IsRelateToEffect(e) then
      if Duel.SpecialSummon(c,0,tp,tp,false,false,POS_FACEUP)~=0 then 
	  Duel.ChangeAttackTarget(c) end
	end
end
