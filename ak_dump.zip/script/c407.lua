--王者之陣營 (K)
function c407.initial_effect(c)
	--disable attack
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
      e1:SetHintTiming(TIMING_BATTLE_PHASE)
      e1:SetCondition(c407.atkcon)
	e1:SetTarget(c407.target)
	e1:SetOperation(c407.atkop)
	c:RegisterEffect(e1)
end

function c407.filter1(c,e,tp)
	return c:IsLevelBelow(4) and c:IsSetCard(0x910) and c:IsCanBeSpecialSummoned(e,0,tp,false,false,POS_FACEUP_ATTACK)
end
function c407.atkcon(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	return Duel.GetCurrentPhase()==PHASE_BATTLE
      and Duel.GetAttacker()~=nil and Duel.GetAttacker():IsAttackable() 
      and Duel.GetAttackTarget()~=nil and Duel.GetAttackTarget():IsSetCard(0x910)
end
function c407.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>2 
	and not Duel.IsPlayerAffectedByEffect(tp,59822133)
      and Duel.IsExistingMatchingCard(c407.filter1,tp,LOCATION_DECK,0,3,nil,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,3,tp,LOCATION_DECK)
end
function c407.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then return end
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<2 then return end	
	if not Duel.NegateAttack() then return end
	Duel.BreakEffect()
	if not c:IsRelateToEffect(e) then return end
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<3 then return end
	local g=Duel.SelectMatchingCard(tp,c407.filter1,tp,LOCATION_DECK,0,3,3,nil,e,tp)
	local sc=g:GetFirst()
      while sc do
	if sc then
		Duel.SpecialSummonStep(sc,0,tp,tp,false,false,POS_FACEUP_ATTACK)
            local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_DISABLE)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		sc:RegisterEffect(e1,true)
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_DISABLE_EFFECT)
		e2:SetReset(RESET_EVENT+0x1fe0000)
		sc:RegisterEffect(e2,true)
 	local de=Effect.CreateEffect(c)
	de:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE)
	de:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	de:SetRange(LOCATION_MZONE)
	de:SetCode(EVENT_PHASE+PHASE_END)
	de:SetCountLimit(1)
	de:SetOperation(c407.desop)
	de:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	sc:RegisterEffect(de,true)
            Duel.SpecialSummonComplete()
	end
      sc=g:GetNext() end
end
function c407.desop(e,tp,eg,ep,ev,re,r,rp)
	Duel.Destroy(e:GetHandler(),REASON_EFFECT)
end
