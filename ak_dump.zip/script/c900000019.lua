--阿图姆·失去的王之名
function c900000019.initial_effect(c)
	
	--特殊召唤光之创造神
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_CANNOT_INACTIVATE)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCondition(c900000019.condition)
	e1:SetTarget(c900000019.target)
	e1:SetOperation(c900000019.activate)
	c:RegisterEffect(e1)
	
	--效果不会被无效化
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_CANNOT_DISABLE)
	c:RegisterEffect(e2)

	local e8=Effect.CreateEffect(c)
	e8:SetProperty(EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_DELAY)
	e8:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e8:SetCode(EVENT_SUMMON_SUCCESS)
	e8:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
	e8:SetOperation(c900000019.spoperation)
	Duel.RegisterEffect(e8,0)
end
-------------------------------------------------------------------------------------------------------------------------------------------
function c900000019.condition(e,tp,eg,ep,ev,re,r,rp) 
	local c=e:GetHandler()
	return c:GetFlagEffect(709)~=0 and c:GetFlagEffect(708)~=0 and c:GetFlagEffect(707)~=0
end

function c900000019.tffilter(c)
	local code=c:GetCode()
	return code==10000000 or code==10000010 or code==10000020 
end

function c900000019.tfilter(c,e,tp)
	return c:IsCode(10000040,10000042) and c:IsCanBeSpecialSummoned(e,0,tp,true,false)
end

function c900000019.filter(c,tp)
	return c:IsCode(10000020) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
	and Duel.IsExistingMatchingCard(c900000019.filter2,tp,LOCATION_ONFIELD+LOCATION_GRAVE,0,1,nil,c,tp)
end
function c900000019.filter2(c,tc,tp)
	return c:IsCode(10000010) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
	and Duel.IsExistingMatchingCard(c900000019.filter3,tp,LOCATION_ONFIELD+LOCATION_GRAVE,0,1,nil,c,tc,tp)
end
function c900000019.filter3(c,tc,tc2,tp)
	local g=Group.FromCards(c,tc,tc2) 
	return c:IsCode(10000000) and not c:IsHasEffect(EFFECT_NECRO_VALLEY) and Duel.GetLocationCountFromEx(tp,tp,g)>0
end
function c900000019.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c900000019.filter,tp,LOCATION_ONFIELD+LOCATION_GRAVE,0,1,nil,tp) 
	and Duel.IsExistingMatchingCard(c900000019.tfilter,tp,LOCATION_EXTRA,0,1,nil,e,tp) end
end

function c900000019.activate(e,tp,eg,ep,ev,re,r,rp)
	if not (Duel.IsExistingMatchingCard(c900000019.filter,tp,LOCATION_ONFIELD+LOCATION_GRAVE,0,1,nil,tp)
	 and Duel.IsExistingMatchingCard(c900000019.tfilter,tp,LOCATION_EXTRA,0,1,nil,e,tp) ) then return end
	local sg=Duel.GetMatchingGroup(c900000019.tffilter,tp,LOCATION_ONFIELD+LOCATION_GRAVE,0,nil)
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
	local g1=sg:Select(tp,1,1,nil)
	sg:Remove(Card.IsCode,nil,g1:GetFirst():GetCode())
	local ft=2
	local g2=nil
	while ft>0 do
		g2=sg:Select(tp,1,1,nil)
		g1:Merge(g2)
		sg:Remove(Card.IsCode,nil,g2:GetFirst():GetCode())
		ft=ft-1
	end
	Duel.Remove(g1,POS_FACEUP,REASON_RULE)
	if Duel.GetLocationCountFromEx(tp)<1 then return end
	local sg=Duel.SelectMatchingCard(tp,c900000019.tfilter,tp,LOCATION_EXTRA,0,1,1,nil,e,tp)
	if sg:GetCount()>0 then
		Duel.BreakEffect()
		Duel.SpecialSummon(sg,0,tp,tp,true,false,POS_FACEUP)
		local WIN_REASON_CREATORGOD = 0x13
		Duel.Win(tp,WIN_REASON_CREATORGOD)
	end
end

function c900000019.spoperation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tg=eg:GetFirst()
	while tg do
	  if tg:IsCode(10000000) and ep==c:GetControler() then c:RegisterFlagEffect(707,0,0,0) end
	  if tg:IsCode(10000010) and ep==c:GetControler() then c:RegisterFlagEffect(708,0,0,0)  end
	  if tg:IsCode(10000020) and ep==c:GetControler() then c:RegisterFlagEffect(709,0,0,0)  end
	  tg=eg:GetNext() end
end
