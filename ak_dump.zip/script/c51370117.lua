--Booby Trap E
function c51370117.initial_effect(c)
	--copy trap
	local e1=Effect.CreateEffect(c)
      e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(0x1e1,0x1e1)
	e1:SetTarget(c51370117.target)
	e1:SetOperation(c51370117.operation)
	c:RegisterEffect(e1)
end
function c51370117.filter(c)
	return c:GetType()==0x20004 and not c:IsCode(51370117) and c:IsFacedown() and c:CheckActivateEffect(false,false,false)~=nil
end
function c51370117.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then
		local te=e:GetLabelObject()
		local tg=te:GetTarget()
		return tg and tg(e,tp,eg,ep,ev,re,r,rp,1,true)
	end
	if chk==0 then return Duel.IsExistingTarget(c51370117.filter,tp,LOCATION_SZONE,0,1,nil) end
	e:SetProperty(EFFECT_FLAG_CARD_TARGET)
	local g=Duel.SelectTarget(tp,c51370117.filter,tp,LOCATION_SZONE,0,1,1,nil)
	if not g then return false end
	Duel.ConfirmCards(1-tp,g)
	local te,eg,ep,ev,re,r,rp=g:GetFirst():CheckActivateEffect(false,true,true)
	e:SetLabelObject(te)
      e:SetLabel(g:GetFirst():GetCode())
	Duel.ClearTargetCard()
            local cost=te:GetCost()
	local tg=te:GetTarget()
	e:SetCategory(te:GetCategory())
	e:SetProperty(te:GetProperty())
            if cost then cost(e,tep,eg,ep,ev,re,r,rp,1) end
	if tg then tg(e,tp,eg,ep,ev,re,r,rp,1) end
end
function c51370117.operation(e,tp,eg,ep,ev,re,r,rp)
	local te=e:GetLabelObject()
	local code=e:GetLabel()
	if not te then return end
	local op=te:GetOperation()
	if op then op(e,tp,eg,ep,ev,re,r,rp) end
      e:GetHandler():CopyEffect(code,RESET_EVENT+0x1fe0000,1)
end

