--易容覇王 造型凝膠 (K)
function c416.initial_effect(c)
      if not c416.global_check then
		c416.global_check=true
	local ch=Effect.CreateEffect(c)
	ch:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE)
	ch:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	ch:SetCode(EVENT_SUMMON_SUCCESS)
	ch:SetOperation(c416.checkop)
	c:RegisterEffect(ch) end

	--lvchange
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(94203886,0))
	e2:SetType(EFFECT_TYPE_IGNITION)
	e2:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e2:SetCategory(CATEGORY_RECOVER)
      e2:SetRange(LOCATION_MZONE)
	e2:SetCondition(c416.condition)
	e2:SetTarget(c416.lvtg)
	e2:SetOperation(c416.lvop)
	c:RegisterEffect(e2)
end

function c416.checkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
      c:RegisterFlagEffect(416,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END,0,1)
end

function c416.lvfilter(c,lv)
	local clv=c:GetLevel()
	return c:IsFaceup() and clv>0 and clv~=lv
end
function c416.condition(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetFlagEffect(416)~=0
end
function c416.lvtg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(tp) and c416.lvfilter(chkc,e:GetHandler():GetLevel()) end
	if chk==0 then return Duel.IsExistingTarget(c416.lvfilter,tp,LOCATION_MZONE,0,1,e:GetHandler(),e:GetHandler():GetLevel()) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	local g=Duel.SelectTarget(tp,c416.lvfilter,tp,LOCATION_MZONE,0,1,1,e:GetHandler(),e:GetHandler():GetLevel())
      local lv=e:GetHandler():GetLevel()
      local tlv=g:GetFirst():GetLevel()
      local diff=tlv-lv
      if diff<0 then diff=0 end
	Duel.SetOperationInfo(0,CATEGORY_RECOVER,nil,0,tp,diff*200)
end
function c416.lvop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if c:IsRelateToEffect(e) and c:IsFaceup() and tc:IsRelateToEffect(e) and tc:IsFaceup() then
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_CHANGE_LEVEL)
		e1:SetValue(tc:GetLevel())
		e1:SetReset(RESET_EVENT+0x1fe0000)
		c:RegisterEffect(e1)
            local lv=c:GetLevel()
            local tlv=tc:GetLevel()
            local diff=tlv-lv
            if diff<0 then return end
            Duel.Recover(tp,diff*200,REASON_EFFECT)
	end
end
