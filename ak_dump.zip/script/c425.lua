--九十九斬擊 (K)
function c425.initial_effect(c)
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
      e1:SetCategory(CATEGORY_ATKCHANGE)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_CHAINING)
      e1:SetCondition(c425.con)
      e1:SetTarget(c425.target)
      e1:SetOperation(c425.op)
	c:RegisterEffect(e1)
end

function c425.con(e,tp,eg,ep,ev,re,r,rp)
      if not re:IsHasCategory(CATEGORY_ATKCHANGE) or not re:IsHasProperty(EFFECT_FLAG_CARD_TARGET) then return false end
	local g=Duel.GetChainInfo(ev,CHAININFO_TARGET_CARDS)
	if not g or g:GetCount()==0 then return false end
	return g:IsExists(Card.IsControler,1,nil,1-tp) and Duel.GetLP(tp)<=100 and Duel.GetLP(1-tp)<=100
end
function c425.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(tp) and chkc:IsFaceup() end
	if chk==0 then return Duel.IsExistingTarget(Card.IsFaceup,tp,LOCATION_MZONE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	Duel.SelectTarget(tp,Card.IsFaceup,tp,LOCATION_MZONE,0,1,1,nil)
end
function c425.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
      local a=Duel.GetLP(tp)
      local b=Duel.GetLP(1-tp)
      local diff=(a-b)*100
      if diff<0 then diff=diff*(-1) end
	if tc and tc:IsRelateToEffect(e) and tc:IsFaceup() and diff>0 then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		e1:SetValue(diff)
		tc:RegisterEffect(e1)
	end
end
