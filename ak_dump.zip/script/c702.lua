--覇王眷竜ダークヴルム
--Supreme King Servant Dragon Darkvrm
function c702.initial_effect(c)
	Pendulum.AddProcedure(c)

	--disable attack
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(84013237,0))
	e1:SetProperty(EFFECT_FLAG_DELAY)	
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e1:SetRange(LOCATION_PZONE)
	e1:SetCode(EVENT_BE_BATTLE_TARGET)
    e1:SetCountLimit(1)
	e1:SetCondition(c702.condition)	
	e1:SetOperation(c702.atkop)
	c:RegisterEffect(e1)

	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(84013237,0))
	e2:SetProperty(EFFECT_FLAG_DELAY)
	e2:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e2:SetCode(EVENT_BE_BATTLE_TARGET)
	e2:SetCondition(c702.condition2)	
	e2:SetOperation(c702.atkop)
	c:RegisterEffect(e2)	
end	

function c702.condition(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetAttackTarget()
	return tc and tc:IsFaceup() and tc:IsControler(tp) and tc:IsSetCard(0xf8)
end
function c702.atkop(e,tp,eg,ep,ev,re,r,rp)
	Duel.NegateAttack()
end

function c702.ndcfilter(c)
	return c:IsFaceup() and c:IsSetCard(0xf8)
end
function c702.condition2(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetAttackTarget()
	return tc and tc:IsFaceup() and tc==e:GetHandler() 
	and Duel.IsExistingMatchingCard(c702.ndcfilter,tp,LOCATION_MZONE,0,1,e:GetHandler())
end

