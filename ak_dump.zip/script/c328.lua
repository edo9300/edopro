--霞の谷の祭壇
function c328.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	c:RegisterEffect(e1)

	--special summon
	local e2=Effect.CreateEffect(c)
	  e2:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e2:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e2:SetDescription(aux.Stringid(4215636,0))
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e2:SetRange(LOCATION_FZONE)
	e2:SetCode(EVENT_DESTROYED)
	e2:SetCountLimit(1)
	e2:SetCondition(c328.condition)
	e2:SetCost(c328.spcost)
	e2:SetTarget(c328.target)
	e2:SetOperation(c328.operation)
	c:RegisterEffect(e2)
end

function c328.cfilter(c,tp)
	return c:IsControler(tp) and c:GetRank()>=8 and (c:IsSetCard(0x48) or c:IsSetCard(0x1048) or c:IsSetCard(0x2048)) and c:IsLocation(LOCATION_GRAVE)
end
function c328.condition(e,tp,eg,ep,ev,re,r,rp)
	return eg:IsExists(c328.cfilter,1,nil,tp)
end
function c328.spfilter(c,e,tp)
	return (c:IsSetCard(0x48) or c:IsSetCard(0x1048) or c:IsSetCard(0x2048)) and c:IsCanBeSpecialSummoned(e,0,tp,false,false)
end
function c328.spcost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetMatchingGroupCount(Card.IsDiscardable,tp,LOCATION_HAND,0,nil)>0 end
	  local g=Duel.GetFieldGroup(tp,LOCATION_HAND,0)
	Duel.SendtoGrave(g,REASON_EFFECT+REASON_DISCARD)
end
function c328.target(e,tp,eg,ep,ev,re,r,rp,chk)
	  local ft=Duel.GetLocationCountFromEx(tp)
	  local g=Duel.GetMatchingGroupCount(c328.spfilter,tp,LOCATION_EXTRA,0,nil,e,tp)
	  local ft2=Duel.GetLocationCountFromEx(1-tp)
	  local g2=Duel.GetMatchingGroupCount(c328.spfilter,1-tp,LOCATION_EXTRA,0,nil,e,1-tp)
	if chk==0 then return e:GetHandler():IsRelateToEffect(e) and not e:GetHandler():IsStatus(STATUS_CHAINING)
					 and ((g>0 and ft>0) or (g2>0 and ft2>0)) end
	  if ft>g then ft=g end
	  if ft2>g2 then ft2=g2 end
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then ft=1 end	   
	if Duel.IsPlayerAffectedByEffect(1-tp,59822133) then ft2=1 end	  
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,ft+ft2,PLAYER_ALL,LOCATION_EXTRA)
end
function c328.operation(e,tp,eg,ep,ev,re,r,rp)
	  if not e:GetHandler():IsRelateToEffect(e) then return end
	  local ft=Duel.GetLocationCountFromEx(tp)
	  local gcount=Duel.GetMatchingGroupCount(c328.spfilter,tp,LOCATION_EXTRA,0,nil,e,tp)
	if ft>0 and gcount>0 then
	  if ft>gcount then ft=gcount end
		if Duel.IsPlayerAffectedByEffect(tp,59822133) then ft=1 end   
	local ect=c29724053 and Duel.IsPlayerAffectedByEffect(tp,29724053) and c29724053[tp]
	if ect~=nil then ft=math.min(ft,ect) end		
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(tp,c328.spfilter,tp,LOCATION_EXTRA,0,ft,ft,nil,e,tp)
	if g:GetCount()>0 then Duel.SpecialSummon(g,0,tp,tp,false,false,POS_FACEUP) end end

	  local ft2=Duel.GetLocationCountFromEx(1-tp)
	  local gcount2=Duel.GetMatchingGroupCount(c328.spfilter,1-tp,LOCATION_EXTRA,0,nil,e,1-tp)
	if ft2>0 and gcount2>0 then
	  if ft2>gcount2 then ft2=gcount2 end  
	local ect2=c29724053 and Duel.IsPlayerAffectedByEffect(1-tp,29724053) and c29724053[1-tp]
	if ect2~=nil then ft2=math.min(ft2,ect) end	 
	if Duel.IsPlayerAffectedByEffect(1-tp,59822133) then ft2=1 end		
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g2=Duel.SelectMatchingCard(1-tp,c328.spfilter,1-tp,LOCATION_EXTRA,0,ft2,ft2,nil,e,1-tp)
	if g2:GetCount()>0 then Duel.SpecialSummon(g2,0,1-tp,1-tp,false,false,POS_FACEUP) end end
end
