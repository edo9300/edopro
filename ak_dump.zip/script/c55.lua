--
function c55.initial_effect(c)
	--pendulum summon
	Pendulum.AddProcedure(c)

	--tohand
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(93149655,0))
	e2:SetCategory(CATEGORY_ATKCHANGE)
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetCode(EVENT_BATTLE_START)
	e2:SetRange(LOCATION_PZONE)
	e2:SetCondition(c55.thcon)
	e2:SetTarget(c55.thtg)
	e2:SetOperation(c55.thop)
	c:RegisterEffect(e2)

	--remove
	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_REMOVE)
    e3:SetDescription(aux.Stringid(85121942,1))
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e3:SetCode(EVENT_SPSUMMON_SUCCESS)
	e3:SetCondition(c55.condition)
	e3:SetOperation(c55.operation)
	c:RegisterEffect(e3)
end

function c55.thcon(e,tp,eg,ep,ev,re,r,rp)
	local seq=e:GetHandler():GetSequence()
	local tc=Duel.GetFieldCard(tp,LOCATION_SZONE,13-seq)
	if not tc or not tc:IsSetCard(0x99) then return end
	local a=Duel.GetAttacker()
	local d=Duel.GetAttackTarget()
	if d and a:GetControler()~=d:GetControler() then
		if a:IsControler(tp) and a:IsFaceup() then e:SetLabelObject(a)
		elseif d:IsFaceup() then e:SetLabelObject(d)
		else return false end
		return true
	else e:SetLabelObject(a) return a:IsControler(tp) end
end
function c55.thtg(e,tp,eg,ep,ev,re,r,rp,chk)
	local tc=e:GetLabelObject()
	if chk==0 then return tc:IsOnField() and tc:GetFlagEffect(55)==0 end
	tc:RegisterFlagEffect(55,RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_DAMAGE_CAL,0,1)
end
function c55.thop(e,tp,eg,ep,ev,re,r,rp)
	if not e:GetHandler():IsRelateToEffect(e) then return end
	local seq=e:GetHandler():GetSequence()
	local tc2=Duel.GetFieldCard(tp,LOCATION_SZONE,13-seq)
	if not tc2 or not tc2:IsSetCard(0x99) then return end	
	local tc=e:GetLabelObject()
	if tc:IsFaceup() and tc:IsControler(tp) then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(tc2:GetAttack())
		e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_BATTLE)
		tc:RegisterEffect(e1)
	end
end

function c55.condition(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetSummonType()==SUMMON_TYPE_PENDULUM
end
function c55.operation(e,tp,eg,ep,ev,re,r,rp)
      local c=e:GetHandler()
	local e3=Effect.CreateEffect(c)
	e3:SetDescription(aux.Stringid(85121942,1))
      e3:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
      e3:SetCategory(CATEGORY_DAMAGE)
      e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_F)
	e3:SetCode(EVENT_BATTLE_DAMAGE)
	e3:SetTarget(c55.cd2)
	e3:SetOperation(c55.op)
      e3:SetReset(RESET_EVENT+0x1ff0000+RESET_PHASE+PHASE_END)
	c:RegisterEffect(e3)
end
function c55.scfilter(c)
	return (c:GetSequence()==6 and c:GetTextAttack()>0)
		or (c:GetSequence()==7 and c:GetTextAttack()>0)
end
function c55.cd2(e,tp,eg,ep,ev,re,r,rp,chk)
      local c=e:GetHandler()
	if chk==0 then return ep==1-tp and Duel.IsExistingMatchingCard(c55.scfilter,tp,LOCATION_SZONE,0,1,nil) end
	Duel.SetTargetPlayer(1-tp)
	local g=Duel.GetMatchingGroup(c55.scfilter,tp,LOCATION_SZONE,0,nil)
	local tc=g:GetFirst()      
      local tatk=0
      while tc do
      local atk=tc:GetTextAttack()
      if atk<0 then atk=0 end
      tatk=tatk+atk
      tc=g:GetNext() end     
      Duel.SetTargetParam(tatk)
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,1-tp,tatk)
end
function c55.op(e,tp,eg,ep,ev,re,r,rp)
	local p,d=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER)
	local g=Duel.GetMatchingGroup(c55.scfilter,tp,LOCATION_SZONE,0,nil)
	local tc=g:GetFirst()      
      local tatk=0
      while tc do
      local atk=tc:GetTextAttack()
      if atk<0 then atk=0 end
      tatk=tatk+atk
      tc=g:GetNext() end   
	Duel.Damage(p,tatk,REASON_EFFECT)
end
