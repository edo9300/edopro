--破滅之實 (K)
function c697.initial_effect(c)
	--Activate
    local e1=Effect.CreateEffect(c)
    e1:SetType(EFFECT_TYPE_ACTIVATE)
    e1:SetCode(EVENT_FREE_CHAIN)
    e1:SetCost(c697.cost)
    c:RegisterEffect(e1) 	

	local e2=Effect.CreateEffect(c)
	e2:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DELAY+EFFECT_FLAG_CARD_TARGET)
	e2:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
	e2:SetRange(LOCATION_SZONE)
	e2:SetCode(EVENT_DESTROYED)
	e2:SetCondition(c697.spcon)
	e2:SetCost(c697.cost2)	
	e2:SetTarget(c697.sptg)
	e2:SetOperation(c697.spop)
	c:RegisterEffect(e2)
	
	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_DAMAGE+CATEGORY_TOGRAVE)
	e3:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e3:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e3:SetRange(LOCATION_SZONE)
	e3:SetCode(EVENT_PHASE+PHASE_STANDBY)
	e3:SetCountLimit(1)
	e3:SetCondition(c697.con)
	e3:SetTarget(c697.target)
	e3:SetOperation(c697.operation)
	c:RegisterEffect(e3)	
end

function c697.filter(c)
    return c:IsType(TYPE_SPELL) and c:IsType(TYPE_CONTINUOUS) and c:IsAbleToGraveAsCost()
end
function c697.cost(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then return Duel.IsExistingMatchingCard(c697.filter,tp,LOCATION_SZONE,LOCATION_SZONE,1,e:GetHandler()) end
    Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TOGRAVE)
	local g=Duel.SelectMatchingCard(tp,c697.filter,tp,LOCATION_SZONE,LOCATION_SZONE,1,1,e:GetHandler())
	Duel.SendtoGrave(g,REASON_COST)
end

function c697.filter3(c,e,tp)
    return c:IsType(TYPE_MONSTER) and c:IsControler(tp) and c:GetAttack()>=3000 and not c:IsImmuneToEffect(e)
end
function c697.cost2(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then return Duel.IsExistingMatchingCard(c697.filter3,tp,LOCATION_MZONE,0,1,nil,e,tp) end
    Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g=Duel.SelectMatchingCard(tp,c697.filter3,tp,LOCATION_MZONE,0,1,1,nil,e,tp):GetFirst()
    local e1=Effect.CreateEffect(e:GetHandler())
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_UPDATE_ATTACK)
	e1:SetValue(-3000)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	g:RegisterEffect(e1)		
end
function c697.spcfilter(c,e,tp)
	return c:IsReason(REASON_EFFECT) and c:IsCanBeSpecialSummoned(e,0,tp,false,false) and not c:IsHasEffect(EFFECT_NECRO_VALLEY)
		and c:GetPreviousControler()==tp and c:IsPreviousLocation(LOCATION_MZONE) and c:IsLocation(LOCATION_GRAVE)
end
function c697.spcon(e,tp,eg,ep,ev,re,r,rp)
	return eg and eg:GetCount()==1 and eg:IsExists(c697.spcfilter,1,nil,e,tp)
end
function c697.sptg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local c=e:GetHandler()
	if chkc then return true end	
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0 
		and eg:FilterCount(c697.spcfilter,nil,e,tp)==1 end
	Duel.SetTargetCard(eg:Filter(c697.spcfilter,nil,e,tp))
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,eg:Filter(c697.spcfilter,nil,e,tp),1,0,0)
end
function c697.spop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if not tc:IsRelateToEffect(e) or tc:IsFacedown() then return end
	Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP)
end

function c697.con(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetTurnPlayer()==tp
end
function c697.filter2(c)
	return c:IsType(TYPE_SPELL) and c:IsType(TYPE_CONTINUOUS) and c:IsAbleToGrave()
end
function c697.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsControler(tp) and chkc:IsLocation(LOCATION_SZONE) and c697.filter2(chkc) and chkc~=e:GetHandler()	end
	if chk==0 then return true end
	local op=1
	if Duel.IsExistingTarget(c697.filter2,tp,LOCATION_SZONE,0,1,e:GetHandler()) then
	op=Duel.SelectOption(tp,aux.Stringid(12174035,0),aux.Stringid(37209439,1)) end
	if op==0 then
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TOGRAVE)
	local g=Duel.SelectTarget(tp,c697.filter2,tp,LOCATION_SZONE,0,1,1,e:GetHandler())
	Duel.SetOperationInfo(0,CATEGORY_TOGRAVE,g,1,0,0)
	else
	Duel.SetTargetPlayer(tp)
	Duel.SetTargetParam(1000)	
	Duel.SetOperationInfo(0,CATEGORY_DAMAGE,nil,0,tp,1000) end	
	e:SetLabel(op)
end
function c697.operation(e,tp,eg,ep,ev,re,r,rp)
	local op=e:GetLabel()
	if op==0 then
	local tc=Duel.GetFirstTarget()
    Duel.SendtoGrave(tc,REASON_EFFECT)
	else
	local p,d=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER,CHAININFO_TARGET_PARAM)
	Duel.Damage(p,d,REASON_EFFECT)
    end	
end
