--邁向明日的現身 (K)
function c426.initial_effect(c)
	local ch=Effect.CreateEffect(c)
	ch:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	ch:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	ch:SetCode(EVENT_BATTLE_DESTROYED)
      ch:SetCondition(c426.checkcon)
	ch:SetOperation(c426.checkop)
	Duel.RegisterEffect(ch,0)

	local ge2=Effect.CreateEffect(c) 
      ge2:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE)
	ge2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS) 
      ge2:SetCode(EVENT_PHASE+PHASE_END)
      ge2:SetCountLimit(1)
	ge2:SetOperation(c426.checkop2) 
      ge2:SetLabelObject(ch)
      Duel.RegisterEffect(ge2,0)

	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
      e1:SetCategory(CATEGORY_ATKCHANGE)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
      e1:SetTarget(c426.target)
      e1:SetOperation(c426.op)
      e1:SetLabelObject(ch)
	c:RegisterEffect(e1)
end

function c426.ddfilter(c)
	return c:IsSetCard(0x48)
end
function c426.checkcon(e,tp,eg,ep,ev,re,r,rp)
      return eg:FilterCount(c426.ddfilter,nil)>0
end
function c426.checkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
      local g=eg:Filter(c426.ddfilter,nil)
      local tc=g:GetFirst()
      local tatk=e:GetLabel()
      while tc do
      local atk=tc:GetBaseAttack()
      tatk=tatk+atk
      tc=g:GetNext() end
	e:SetLabel(tatk)
end

function c426.checkop2(e,tp,eg,ep,ev,re,r,rp)
      e:GetLabelObject():SetLabel(0)
end

function c426.ddfilter2(c)
	return c:IsSetCard(0x48) and c:IsFaceup()
end
function c426.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(tp) and c426.ddfilter2(chkc) end
	if chk==0 then return Duel.IsExistingTarget(c426.ddfilter2,tp,LOCATION_MZONE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	Duel.SelectTarget(tp,c426.ddfilter2,tp,LOCATION_MZONE,0,1,1,nil)
end
function c426.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
      local tatk=e:GetLabelObject():GetLabel()
	if tc and tc:IsRelateToEffect(e) and tc:IsFaceup() and tatk>0 then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		e1:SetValue(tatk)
		tc:RegisterEffect(e1)
	end
end
