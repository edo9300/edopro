--惡夢的往昔輪回
function c220.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	c:RegisterEffect(e1)

	local e2=Effect.CreateEffect(c) 
	e2:SetCategory(CATEGORY_REMOVE) 
	e2:SetType(EFFECT_TYPE_IGNITION)	
	e2:SetRange(LOCATION_SZONE)
	e2:SetCountLimit(1)
	e2:SetTarget(c220.tg)   
	e2:SetOperation(c220.activate)
	c:RegisterEffect(e2)
end

function c220.filter(c)
	return c:IsReleasableByEffect()
end
function c220.tg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return Duel.IsExistingMatchingCard(c220.filter,tp,LOCATION_MZONE,0,1,nil) end
	Duel.SetOperationInfo(0,CATEGORY_REMOVE,nil,1,0,0)   
end
function c220.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RELEASE)
	local g=Duel.SelectMatchingCard(tp,c220.filter,tp,LOCATION_MZONE,0,1,1,nil)
	if Duel.Release(g,REASON_EFFECT)<1 then return end  

	local e4=Effect.CreateEffect(c)
	e4:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)	  
	e4:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e4:SetCode(EVENT_SPSUMMON_SUCCESS)
	e4:SetRange(LOCATION_SZONE)
	e4:SetTargetRange(LOCATION_MZONE,0)
	e4:SetCondition(c220.con)
	e4:SetOperation(c220.op)
	e4:SetReset(RESET_PHASE+PHASE_END)
	--c:RegisterEffect(e4) 

	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetRange(LOCATION_SZONE)
	e1:SetCondition(c220.condition2)		   
	e1:SetCost(c220.cost2)
	e1:SetTarget(c220.target2)
	e1:SetOperation(c220.activate2)
	e1:SetReset(RESET_EVENT+0x1ff0000+RESET_PHASE+PHASE_END)
	c:RegisterEffect(e1)
end

function c220.condition2(e,tp,eg,ep,ev,re,r,rp)
	local ph=Duel.GetCurrentPhase()
	return ph==PHASE_MAIN1 or ph==PHASE_MAIN2 
	or (ph>=PHASE_BATTLE_START and ph<=PHASE_BATTLE)
end
function c220.filter2(c)
	local sumtype=c:GetSummonType()
	return (sumtype==SUMMON_TYPE_XYZ or sumtype==SUMMON_TYPE_FUSION or sumtype==SUMMON_TYPE_SYNCHRO)
	and c:GetMaterial():IsExists(Card.IsCode,1,nil,51370066)  and c:IsReleasable()
end
function c220.cost2(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c220.filter2,tp,LOCATION_MZONE,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RELEASE)
	local g=Duel.SelectMatchingCard(tp,c220.filter2,tp,LOCATION_MZONE,0,1,1,nil)
	Duel.Release(g,REASON_COST)
end
function c220.tgfilter(c,e,tp)
	return c:IsCode(51370066) and c:IsCanBeSpecialSummoned(e,0,tp,false,false)
end
function c220.target2(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0 and Duel.IsExistingMatchingCard(c220.tgfilter,tp,LOCATION_GRAVE,0,1,nil,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,0)
end
function c220.activate2(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0 then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local sg=Duel.SelectMatchingCard(tp,c220.tgfilter,tp,LOCATION_GRAVE,0,1,1,nil,e,tp)
			Duel.SpecialSummon(sg,0,tp,tp,false,false,POS_FACEUP) 
end

function c220.con(e,tp,eg,ep,ev,re,r,rp)
	local sumtype=eg:GetFirst():GetSummonType()
	return (sumtype==SUMMON_TYPE_XYZ or sumtype==SUMMON_TYPE_FUSION or sumtype==SUMMON_TYPE_SYNCHRO) 
	and eg:GetFirst():GetMaterial():IsExists(Card.IsCode,1,nil,51370066) 
end
function c220.op(e,tp,eg,ep,ev,re,r,rp)
	local tc=eg:GetFirst()
	tc:RegisterFlagEffect(96,RESET_EVENT+0x1ff0000+RESET_PHASE+PHASE_END,0,1)
end
