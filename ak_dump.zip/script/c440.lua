--Shock Draw (K)
function c440.initial_effect(c)
	local ge1=Effect.CreateEffect(c)
	ge1:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE)
	ge1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS) 
	ge1:SetCode(EVENT_DAMAGE)
      ge1:SetCondition(c440.checkcon)
	ge1:SetOperation(c440.checkop)
      Duel.RegisterEffect(ge1,0)

	local ge2=Effect.CreateEffect(c)
	ge2:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE)
	ge2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS) 
	ge2:SetCode(EVENT_TURN_END)
      ge2:SetCountLimit(1)
      ge2:SetLabelObject(ge1)
	ge2:SetOperation(c440.checkop2)
      Duel.RegisterEffect(ge2,0)

	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_DRAW)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetCode(EVENT_FREE_CHAIN)
      e1:SetLabelObject(ge1)
      e1:SetHintTiming(0,0x1e0)
	e1:SetTarget(c440.target)
	e1:SetOperation(c440.activate)
	c:RegisterEffect(e1)
end

function c440.checkcon(e,tp,eg,ep,ev,re,r,rp)
      return ep==e:GetHandler():GetControler()
end
function c440.checkop(e,tp,eg,ep,ev,re,r,rp)
      local val=e:GetLabel()+ev
	e:SetLabel(val)
end
function c440.checkop2(e,tp,eg,ep,ev,re,r,rp)
      e:GetLabelObject():SetLabel(0)
end

function c440.target(e,tp,eg,ep,ev,re,r,rp,chk)
      local d=math.floor(e:GetLabelObject():GetLabel()/1000)
	if chk==0 then return d>0 and Duel.IsPlayerCanDraw(tp) end
	Duel.SetTargetPlayer(tp)
	Duel.SetTargetParam(d)
	Duel.SetOperationInfo(0,CATEGORY_DRAW,nil,0,tp,d)
end
function c440.activate(e,tp,eg,ep,ev,re,r,rp)
	local p,d=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER,CHAININFO_TARGET_PARAM)
	Duel.Draw(p,d,REASON_EFFECT)
end
