--光速速攻 (K)
function c53.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
      e1:SetHintTiming(0,TIMING_END_PHASE)
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e1:SetTarget(c53.target)
	e1:SetOperation(c53.activate)
	c:RegisterEffect(e1)	
end

function c53.filter(c)
      local te,eg,ep,ev,re,r,rp=c:CheckActivateEffect(false,false,true)
	return c:IsType(TYPE_QUICKPLAY) and c:CheckActivateEffect(false,false,false)~=nil 
end
function c53.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chk==0 then return Duel.IsExistingMatchingCard(c53.filter,tp,LOCATION_HAND,0,1,nil) end
end
function c53.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g=Duel.SelectMatchingCard(tp,c53.filter,tp,LOCATION_HAND,0,1,1,nil)
      if g:GetCount()>0 then
            local tc=g:GetFirst()
		local te,eg,ep,ev,re,r,rp=tc:CheckActivateEffect(false,false,true)
		local tep=tc:GetControler()
		local condition=te:GetCondition()
		local cost=te:GetCost()
            Duel.ClearTargetCard()
		local target=te:GetTarget()
		local operation=te:GetOperation()
            e:SetCategory(te:GetCategory())
		e:SetProperty(te:GetProperty())
		if not Duel.MoveToField(tc,tp,tp,LOCATION_SZONE,POS_FACEUP,true) then return end
            Duel.Hint(HINT_CARD,0,tc:GetCode())
		tc:CreateEffectRelation(te)
		if cost then cost(e,tep,eg,ep,ev,re,r,rp,1) end
		if target then target(e,tep,eg,ep,ev,re,r,rp,1) end
	      local gg=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS)
	      if gg then
		      local etc=gg:GetFirst()
		      while etc do
		            etc:CreateEffectRelation(te)
			      etc=gg:GetNext()
		      end
	      end
	      Duel.BreakEffect()
	     if operation then operation(te,tep,eg,ep,ev,re,r,rp) end
	     tc:ReleaseEffectRelation(te)
	     if etc then	
		      etc=gg:GetFirst()
		      while etc do
			      etc:ReleaseEffectRelation(te)
			      etc=gg:GetNext()
		      end
	      end 
            Duel.SendtoGrave(tc,REASON_RULE) 
	end
end

