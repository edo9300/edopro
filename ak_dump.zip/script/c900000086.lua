--����è
function c900000086.initial_effect(c)
	
	--���ƶԷ����ϻ�Ĺ��һ�ſ�Ƭ
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(900000086,2))
	e1:SetCategory(CATEGORY_ATKCHANGE+CATEGORY_DEFCHANGE+CATEGORY_LVCHANGE)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c900000086.target)
	e1:SetOperation(c900000086.operation)
	c:RegisterEffect(e1)
end
-------------------------------------------------------------------------------------------------------------------------------------------
function c900000086.filter(c,tp)
	return c:IsFaceup() and not c:IsType(TYPE_FIELD) and not (c:IsLocation(LOCATION_SZONE) and (c:GetSequence()==6 or c:GetSequence()==7) )
		   and ((c:IsType(TYPE_MONSTER) and Duel.IsPlayerCanSpecialSummonMonster(tp,c:GetCode(),0,0x0,c:GetAttack(),c:GetDefense(),c:GetLevel(),c:GetRace(),c:GetAttribute()))
		   or ((c:IsType(TYPE_SPELL) or c:IsType(TYPE_TRAP)) and c:CheckActivateEffect(false,true,false)~=nil))
end

function c900000086.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return (chkc:IsLocation(LOCATION_GRAVE) or chkc:IsLocation(LOCATION_ONFIELD)) and chkc:GetControler()~=tp and c900000086.filter(chkc,tp) end
	if chk==0 then return Duel.IsExistingTarget(c900000086.filter,tp,0,LOCATION_ONFIELD+LOCATION_GRAVE,1,nil,tp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local g=Duel.SelectTarget(tp,c900000086.filter,tp,0,LOCATION_ONFIELD+LOCATION_GRAVE,1,1,nil,tp)
end

function c900000086.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	local code=tc:GetCode()
	local tpe=tc:GetType()
	if not tc:IsRelateToEffect(e) or not c:IsRelateToEffect(e) or c:IsFacedown() then return end
	if tc:IsType(TYPE_MONSTER) and Duel.IsPlayerCanSpecialSummonMonster(tp,code,0,0x0,tc:GetAttack(),tc:GetDefense(),tc:GetLevel(),tc:GetRace(),tc:GetAttribute()) and Duel.GetLocationCount(tp,LOCATION_MZONE)>0 then
				c:AddTrapMonsterAttribute(TYPE_EFFECT,tc:GetAttribute(),tc:GetRace(),tc:GetLevel(),tc:GetAttack(),tc:GetDefense())
				if Duel.SpecialSummon(c,0,tp,tp,true,false,POS_FACEUP)==0 then return end
				c:AddMonsterAttributeComplete()
		c:CopyEffect(code,RESET_EVENT+0x1ff0000,1)
		local atk=tc:GetBaseAttack()
		local def=tc:GetBaseDefense()
		local Race=tc:GetRace()
		local Attribute=tc:GetAttribute()
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_CHANGE_CODE)
		e1:SetValue(code)
		e1:SetReset(RESET_EVENT+0x1ff0000)
		c:RegisterEffect(e1)
	end
		  
		if not tc:IsType(TYPE_MONSTER) and tc:CheckActivateEffect(false,true,false)~=nil then
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_CHANGE_TYPE)
		e1:SetValue(tpe)
		e1:SetReset(RESET_EVENT+0x1fc0000)
		--c:RegisterEffect(e1)
		local e2=Effect.CreateEffect(c)
		e2:SetType(EFFECT_TYPE_SINGLE)
		e2:SetCode(EFFECT_CHANGE_CODE)
		e2:SetValue(code)
		e2:SetReset(RESET_EVENT+0x1fc0000)
		c:RegisterEffect(e2)
		local te,eg,ep,ev,re,r,rp=tc:CheckActivateEffect(false,true,true)
		--local te=tc:GetActivateEffect()
		local target=te:GetTarget()
		local operation=te:GetOperation()
		e:SetCategory(te:GetCategory())
		e:SetProperty(te:GetProperty())
		Duel.ClearTargetCard()
		c:CopyEffect(code,RESET_EVENT+0x1ff0000,1)

		tc:CreateEffectRelation(te)
		if cost then cost(te,tep,eg,ep,ev,re,r,rp,1) end
		if target then target(te,tep,eg,ep,ev,re,r,rp,1) end
		local gg=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS)
		if gg then
			local etc=gg:GetFirst()
			while etc do
					etc:CreateEffectRelation(te)
				etc=gg:GetNext()
			end
		end
		Duel.BreakEffect()
		if operation then operation(te,tep,eg,ep,ev,re,r,rp) end
		tc:ReleaseEffectRelation(te)
		if etc then 
			 etc=gg:GetFirst()
			 while etc do
				 etc:ReleaseEffectRelation(te)
				 etc=gg:GetNext()
			 end
		end 
        if not (bit.band(tpe,TYPE_EQUIP+TYPE_CONTINUOUS+TYPE_FIELD)~=0 or tc:IsHasEffect(EFFECT_REMAIN_FIELD)) then
        Duel.SendtoGrave(tc,REASON_RULE) end
		end  
end

function c900000086.descon(e,tp,eg,ep,ev,re,r,rp)
	return tp~=Duel.GetTurnPlayer()
end
