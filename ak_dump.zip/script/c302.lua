--漆黑的太陽
function c302.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	c:RegisterEffect(e1)

	--adjust
	local e2=Effect.CreateEffect(c)
	e2:SetCategory(CATEGORY_RECOVER)
	e2:SetProperty(EFFECT_FLAG_PLAYER_TARGET+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e2:SetCode(EVENT_DESTROYED)
	e2:SetRange(LOCATION_SZONE)
	e2:SetTarget(c302.tg)
	e2:SetOperation(c302.op)
	c:RegisterEffect(e2)

	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_ATKCHANGE)
	e3:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
	e3:SetCode(EVENT_SPSUMMON_SUCCESS)
	e3:SetRange(LOCATION_SZONE)
	e3:SetCondition(c302.condition)
	e3:SetOperation(c302.activate)
	c:RegisterEffect(e3)
end

function c302.filter(g,tp)
	local c=g:GetFirst()
	if c:IsControler(1-tp) or c:GetPreviousAttackOnField()==0 then c=g:GetNext() end
	if c and c:IsLocation(LOCATION_GRAVE) then return c end
	return nil
end
function c302.tg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then 
		local rc=c302.filter(eg,tp)
		return rc end
      local rc=c302.filter(eg,tp)
	e:SetLabel(rc:GetPreviousAttackOnField())
	Duel.SetTargetPlayer(tp)
	Duel.SetOperationInfo(0,CATEGORY_RECOVER,nil,0,tp,e:GetLabel())
end
function c302.op(e,tp,eg,ep,ev,re,r,rp)
	if not e:GetHandler():IsRelateToEffect(e) then return end
      local rc=c302.filter(eg,tp)
	local p=Duel.GetChainInfo(0,CHAININFO_TARGET_PLAYER)
	Duel.Recover(p,rc:GetPreviousAttackOnField(),REASON_EFFECT)
end

function c302.cfilter(c,tp)
	return c:IsPreviousLocation(LOCATION_GRAVE) and c:GetOwner()==tp
		and c:IsPreviousPosition(POS_FACEUP) 
end
function c302.condition(e,tp,eg,ep,ev,re,r,rp)
	return eg:IsExists(c302.cfilter,1,nil,tp)
end
function c302.activate(e,tp,eg,ep,ev,re,r,rp)
      local g=eg:Filter(c302.cfilter,nil,tp)
	local tc=g:GetFirst()
      while tc do
	if tc then
		local e1=Effect.CreateEffect(e:GetHandler())
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetValue(1000)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		tc:RegisterEffect(e1)
	end 
      tc=g:GetNext() end
end
