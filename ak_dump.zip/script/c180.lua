--Cards Descended from Creation of Ascension
function c180.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e1:SetCategory(CATEGORY_TOHAND)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetCost(c180.cost)
	e1:SetTarget(c180.target)
	e1:SetOperation(c180.activate)
	c:RegisterEffect(e1)
end

function c180.costfilter(c)
	return c:IsAbleToGraveAsCost() and c:IsType(TYPE_MONSTER)
end
function c180.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c180.costfilter,tp,LOCATION_HAND,0,1,nil) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TOGRAVE)
	local g=Duel.SelectTarget(tp,c180.costfilter,tp,LOCATION_HAND,0,1,1,nil)
	Duel.SendtoGrave(g,REASON_COST)
end
function c180.filter(c,e,tp)
	return c:IsSetCard(0x904) and c:IsAbleToHand()
end
function c180.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c180.filter,tp,LOCATION_DECK,0,1,nil,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,nil,1,tp,LOCATION_DECK)
end
function c180.activate(e,tp,eg,ep,ev,re,r,rp)
      local c=e:GetHandler()
      local level=Duel.GetFirstTarget():GetLevel()
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TODECK)
	local g=Duel.SelectMatchingCard(tp,c180.filter,tp,LOCATION_DECK,0,1,1,nil,e,tp)
	Duel.SendtoHand(g,nil,REASON_EFFECT)
	Duel.ConfirmCards(1-tp,g)
      local e6=Effect.CreateEffect(c)
      e6:SetType(EFFECT_TYPE_FIELD)
      e6:SetCode(EFFECT_UPDATE_ATTACK)
      e6:SetRange(LOCATION_GRAVE+LOCATION_REMOVED+LOCATION_HAND+LOCATION_DECK)
      e6:SetTargetRange(LOCATION_MZONE,0)
      e6:SetValue(100*level)
      e6:SetReset(RESET_PHASE+PHASE_END)
      c:RegisterEffect(e6)
end
