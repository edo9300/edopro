--時間融合
function c107.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_FUSION_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	  e1:SetCost(c107.cost)
	e1:SetTarget(c107.target)
	e1:SetOperation(c107.activate)
	c:RegisterEffect(e1)
end

function c107.cost(e,tp,eg,ep,ev,re,r,rp,chk)
		if chk==0 then return Duel.IsExistingMatchingCard(Card.IsAbleToRemoveAsCost,tp,LOCATION_HAND,0,1,e:GetHandler()) end
		local g=Duel.SelectMatchingCard(tp,Card.IsAbleToRemoveAsCost,tp,LOCATION_HAND,0,1,1,e:GetHandler()) 
		Duel.Remove(g,0,REASON_COST+REASON_EFFECT)
end
function c107.filter1(c,e)
	return c:IsCanBeFusionMaterial() and not c:IsImmuneToEffect(e)
end
function c107.filter2(c,e,tp)
	return c:IsType(TYPE_FUSION) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_FUSION,tp,false,false)
end
function c107.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then
		return Duel.IsExistingMatchingCard(c107.filter2,tp,LOCATION_EXTRA,0,1,nil,e,tp)
	end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
end
function c107.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not c:IsRelateToEffect(e) then return end
	e:GetHandler():SetTurnCounter(0) 
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(tp,c107.filter2,tp,LOCATION_EXTRA,0,1,1,nil,e,tp)
	local tc=g:GetFirst()
	Duel.ConfirmCards(1-tp,tc)
		local code=tc:GetCode()
		local fg=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_EXTRA,0,nil,code)
		local tc=fg:GetFirst()

		--special summon
		local e1=Effect.CreateEffect(c) 
		e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS) 
		e1:SetCode(EVENT_PHASE+PHASE_STANDBY) 
		e1:SetCountLimit(1) 
		  e1:SetReset(RESET_PHASE+PHASE_STANDBY+RESET_SELF_TURN,1) 
		e1:SetOperation(c107.proc) 
		e1:SetLabel(code) 
		e1:SetLabelObject(e) 
		Duel.RegisterEffect(e1,tp) 
end

function c107.procfilter(c,code,e,tp)
	return c:IsCode(code) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_FUSION,tp,false,false)
end
function c107.proc(e,tp,eg,ep,ev,re,r,rp)
	if tp~=Duel.GetTurnPlayer() then return end
	local c=e:GetHandler()
	local ct=c:GetTurnCounter()
	ct=ct+1
	c:SetTurnCounter(ct)
	if ct==1 then
		local code=e:GetLabel()
		local tc=Duel.GetFirstMatchingCard(c107.procfilter,tp,LOCATION_EXTRA,0,nil,code,e,tp)
		if not tc then return end
		if Duel.GetLocationCountFromEx(tp)<=0 then
			Duel.SendtoGrave(tc,REASON_EFFECT)
		else
			Duel.SpecialSummon(tc,SUMMON_TYPE_FUSION,tp,tp,false,false,POS_FACEUP)
			tc:CompleteProcedure()
						 local e1=Effect.CreateEffect(c)
						 e1:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE)
						 e1:SetType(EFFECT_TYPE_SINGLE)
						 e1:SetCode(EFFECT_CANNOT_ATTACK)
						 e1:SetReset(RESET_EVENT+0x1ff0000+RESET_PHASE+PHASE_END)
						 tc:RegisterEffect(e1,true)
		end
	end
end
