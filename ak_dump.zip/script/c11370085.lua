--Heat & Heal
function c11370085.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_RECOVER)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetHintTiming(0,TIMING_END_PHASE)
	e1:SetTarget(c11370085.target)
	e1:SetOperation(c11370085.activate)
	c:RegisterEffect(e1)
end
function c11370085.cfilter(c,rk)
	return c:IsFaceup() and c:GetRank()<rk
end
function c11370085.filter1(c,e,tp)
	local rk=c:GetRank()
	return rk>0 and c:IsFaceup() and (c:IsSetCard(0x48) or c:IsSetCard(0x1048) or c:IsSetCard(0x2048)) 
		and not Duel.IsExistingMatchingCard(c11370085.cfilter,tp,LOCATION_MZONE,0,1,nil,rk)
end

function c11370085.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsControler(tp) and chkc:IsLocation(LOCATION_MZONE) and c11370085.filter1(chkc,e,tp) end
	if chk==0 then return Duel.IsExistingTarget(c11370085.filter1,tp,LOCATION_MZONE,0,1,nil,e,tp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	local tc=Duel.SelectTarget(tp,c11370085.filter1,tp,LOCATION_MZONE,0,1,1,nil,e,tp):GetFirst()
	Duel.SetOperationInfo(0,CATEGORY_RECOVER,nil,0,tp,tc:GetAttack())
end
function c11370085.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if tc and tc:IsRelateToEffect(e) and tc:IsFaceup() and not tc:IsImmuneToEffect(e) and c:IsRelateToEffect(e) then
		if Duel.Recover(tp,tc:GetAttack(),REASON_EFFECT)>0 then
		c:CancelToGrave()
		Duel.Overlay(tc,Group.FromCards(c)) end
	end
end
