--ガーベージ·ロード
function c239.initial_effect(c)
	--special summon
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_SPSUMMON_PROC)
	e1:SetProperty(EFFECT_FLAG_UNCOPYABLE)
	e1:SetRange(LOCATION_HAND)
	e1:SetCondition(c239.spcon)
	e1:SetOperation(c239.spop)
	c:RegisterEffect(e1)
end

function c239.spcon(e,c)
	if c==nil then return true end
	return Duel.GetLocationCount(c:GetControler(),LOCATION_MZONE)>0 and
		Duel.CheckLPCost(c:GetControler(),1000)
end
function c239.spop(e,tp,eg,ep,ev,re,r,rp,c)
      local c=e:GetHandler()
	Duel.PayLPCost(tp,1000)   
end
