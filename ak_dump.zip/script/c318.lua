--無限地獄Des Gunman (K)
function c318.initial_effect(c)

      local e2=Effect.CreateEffect(c)
      e2:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
      e2:SetType(EFFECT_TYPE_CONTINUOUS+EFFECT_TYPE_FIELD)
	e2:SetCode(EVENT_DAMAGE)
      e2:SetCondition(c318.addcondition)
	e2:SetOperation(c318.addcount)
	Duel.RegisterEffect(e2,0)

	local ge2=Effect.CreateEffect(c) 
      ge2:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_CANNOT_DISABLE)
	ge2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS) 
      ge2:SetCode(EVENT_TURN_END)
      ge2:SetCountLimit(1)
      ge2:SetCondition(c318.checkcon)
	ge2:SetOperation(c318.checkop) 
      ge2:SetLabelObject(e2)
	Duel.RegisterEffect(ge2,0)

	--Negate
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(15240238,0))
	e1:SetCategory(CATEGORY_NEGATE+CATEGORY_DESTROY)
	e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_QUICK_O)
	e1:SetCode(EVENT_CHAINING)
	e1:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e1:SetRange(LOCATION_GRAVE)
	e1:SetCondition(c318.condition)
	e1:SetCost(c318.spcost)
	e1:SetTarget(c318.target)
	e1:SetOperation(c318.operation)
      e1:SetLabelObject(e2)
	c:RegisterEffect(e1)
end

function c318.condition(e,tp,eg,ep,ev,re,r,rp)
      if re:GetHandler():IsDisabled() then return end
	--if re:IsActiveType(TYPE_SPELL+TYPE_TRAP) and not re:IsHasType(EFFECT_TYPE_ACTIVATE) then return false end
	if not Duel.IsChainNegatable(ev) then return false end
	if re:IsHasCategory(CATEGORY_NEGATE)
		and Duel.GetChainInfo(ev-1,CHAININFO_TRIGGERING_EFFECT):IsHasType(EFFECT_TYPE_ACTIVATE) then return false end
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	if not ex then return false end
	return (cp==tp or PLAYER_ALL) and Duel.GetFieldGroupCount(tp,LOCATION_HAND,0)==0
end
function c318.spcost(e,tp,eg,ep,ev,re,r,rp,chk)
      local c=e:GetHandler()
	if chk==0 then return e:GetHandler():IsAbleToRemove() end
	Duel.Remove(c,POS_FACEUP,REASON_COST+REASON_EFFECT)
end
function c318.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)>0 end
	Duel.SetOperationInfo(0,CATEGORY_NEGATE,eg,1,0,0)
end
function c318.operation(e,tp,eg,ep,ev,re,r,rp)
      if re:GetHandler():IsDisabled() then return end
	if Duel.GetFieldGroupCount(tp,LOCATION_HAND,0)~=0 then return end
      local c=e:GetHandler()
      local dam1=e:GetLabelObject():GetLabel()
      if dam1==nil then dam1=0 end
	local ex,cg,ct,cp,cv=Duel.GetOperationInfo(ev,CATEGORY_DAMAGE)
	Duel.NegateActivation(ev)
      local opt=Duel.SelectOption(1-tp,aux.Stringid(51370033,2),aux.Stringid(51370033,3))
      if opt==0 then
      local dam=e:GetLabelObject():GetLabel()+cv
	local g=Duel.GetDecktopGroup(tp,1)
	local tc=g:GetFirst()
	if tc then
		Duel.ConfirmCards(1-tp,tc)
		Duel.BreakEffect()
		if tc:IsType(TYPE_MONSTER) then
			Duel.Damage(1-tp,dam,REASON_EFFECT)
		else
			Duel.Damage(tp,cv,REASON_EFFECT)
		end
	end end
      if opt==1 then
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_CHANGE_DAMAGE)
	e1:SetProperty(EFFECT_FLAG_PLAYER_TARGET)
	e1:SetTargetRange(1,0)
	e1:SetValue(c318.damval)
	e1:SetReset(RESET_PHASE+PHASE_END,1)
	Duel.RegisterEffect(e1,tp) end
end
function c318.damval(e,re,val,r,rp,rc)
	if bit.band(r,REASON_EFFECT)~=0 then return 0
	else return val end
end

function c318.addcondition(e,tp,eg,ep,ev,re,r,rp)
      return ep==tp and bit.band(r,REASON_EFFECT)~=0
end
function c318.addcount(e,tp,eg,ep,ev,re,r,rp)
      local val=e:GetLabel()+ev
	e:SetLabel(val)
end

function c318.checkcon(e,tp,eg,ep,ev,re,r,rp)
      return e:GetLabelObject():GetLabel()>0
end
function c318.checkop(e,tp,eg,ep,ev,re,r,rp)
      e:GetLabelObject():SetLabel(0)
end
