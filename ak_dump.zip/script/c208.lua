--TG ハルバード·キャノン
function c208.initial_effect(c)
	--synchro summon
	Synchro.AddProcedure(c,aux.FilterBoolFunction(Card.IsType,TYPE_SYNCHRO),1,1,Synchro.NonTuner(Card.IsType,TYPE_SYNCHRO),2,99)
	c:EnableReviveLimit()

	--cannot special summon
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_SPSUMMON_CONDITION)
	e1:SetValue(aux.synlimit)
	c:RegisterEffect(e1)

	  local e2=Effect.CreateEffect(c)   
	  e2:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	  e2:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	  e2:SetCode(EVENT_SPSUMMON_SUCCESS)
	  e2:SetOperation(c208.spop2)
	  c:RegisterEffect(e2)

	--Special Summon
	local e5=Effect.CreateEffect(c)
	e5:SetDescription(aux.Stringid(97836203,3))
	e5:SetType(EFFECT_TYPE_TRIGGER_O+EFFECT_TYPE_SINGLE)
	e5:SetProperty(EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_DAMAGE_STEP)
	e5:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e5:SetCode(EVENT_LEAVE_FIELD)
	e5:SetCondition(c208.spcon)
	e5:SetTarget(c208.sptg)
	e5:SetOperation(c208.spop)
	c:RegisterEffect(e5)

	  local e6=Effect.CreateEffect(c)
	e6:SetDescription(aux.Stringid(2061963,0))
	  e6:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	  e6:SetCategory(CATEGORY_ATKCHANGE+CATEGORY_NEGATE)
	  e6:SetType(EFFECT_TYPE_QUICK_O)
	  e6:SetCode(EVENT_CHAINING)
	  e6:SetRange(LOCATION_MZONE) 
	  e6:SetCondition(c208.negcon)
	e6:SetTarget(c208.negtg)
	  e6:SetOperation(c208.negop) 
	  --e6:SetCountLimit(1)
	  c:RegisterEffect(e6)
end

function c208.discon(e,tp,eg,ep,ev,re,r,rp)
	return not e:GetHandler():IsStatus(STATUS_CHAINING)
--Duel.GetCurrentChain()==0
end
function c208.distg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetOperationInfo(0,CATEGORY_DISABLE_SUMMON,eg,eg:GetCount(),0,0)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,eg,eg:GetCount(),0,0)
end
function c208.disop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if c:IsFacedown() or not c:IsRelateToEffect(e) then return end
	Duel.NegateSummon(eg)
	Duel.Destroy(eg,REASON_EFFECT)
end

function c208.spop2(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	  local matcount=c:GetMaterialCount()
	--Negate summon
	local e2=Effect.CreateEffect(c)
	e2:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e2:SetCategory(CATEGORY_DISABLE_SUMMON+CATEGORY_DESTROY)
	e2:SetDescription(aux.Stringid(97836203,0))
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCode(EVENT_SUMMON_SUCCESS)
	e2:SetCountLimit(matcount,EFFECT_COUNT_CODE_SINGLE)
	e2:SetCondition(c208.discon)
	e2:SetTarget(c208.distg)
	e2:SetOperation(c208.disop)
	e2:SetReset(RESET_EVENT+0x1ff0000)
	c:RegisterEffect(e2)
	local e3=e2:Clone()
	e3:SetDescription(aux.Stringid(97836203,1))
	e3:SetCode(EVENT_FLIP_SUMMON_SUCCESS)
	c:RegisterEffect(e3)
	local e4=e2:Clone()
	e4:SetDescription(aux.Stringid(97836203,2))
	e4:SetCode(EVENT_SPSUMMON_SUCCESS)
	c:RegisterEffect(e4)
end

function c208.spcon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():IsPreviousLocation(LOCATION_ONFIELD)
end
function c208.filter(c,e,tp)
	return c:IsSetCard(0x27) and c:IsCanBeSpecialSummoned(e,0,tp,true,false)
end
function c208.sptg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_EXTRA) and chkc:IsControler(tp) and c208.filter(chkc,e,tp) end
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and Duel.IsExistingTarget(c208.filter,tp,LOCATION_EXTRA,0,1,nil,e,tp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectTarget(tp,c208.filter,tp,LOCATION_EXTRA,0,1,1,nil,e,tp)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,g,1,0,0)
end
function c208.spop(e,tp,eg,ep,ev,re,r,rp)
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) then
		Duel.SpecialSummon(tc,0,tp,tp,true,false,POS_FACEUP)
	end
end

function c208.negcon(e,tp,eg,ep,ev,re,r,rp)
	  local ex,tg,count,tc,value=Duel.GetOperationInfo(ev,CATEGORY_REMOVE)
	return ex and re:GetHandler():IsType(TYPE_MONSTER) and tg:GetCount()==1
	  and tg:GetFirst():IsType(TYPE_MONSTER) and rp~=tp and Duel.IsChainNegatable(ev)
end
function c208.negtg(e,tp,eg,ep,ev,re,r,rp,chk)
	  local ex,tg,count,tc,value=Duel.GetOperationInfo(ev,CATEGORY_REMOVE)
	if chk==0 then return ex and re:GetHandler():IsType(TYPE_MONSTER) and tg:GetCount()==1
					 and tg:GetFirst():IsType(TYPE_MONSTER) and rp~=tp end
	Duel.SetOperationInfo(0,CATEGORY_NEGATE,eg,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_ATKCHANGE,eg,1,0,0)
end
function c208.negop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	Duel.NegateActivation(ev)
	  if not eg:GetFirst():IsLocation(LOCATION_MZONE) then return end
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCode(EFFECT_UPDATE_ATTACK)
	e2:SetValue(-800)
	e2:SetReset(RESET_EVENT+0x1ff0000)
	eg:GetFirst():RegisterEffect(e2)
end
