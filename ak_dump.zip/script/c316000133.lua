--Jammer Slime
function c316000133.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_NEGATE+CATEGORY_DESTROY)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_CHAINING)
	e1:SetCondition(c316000133.condition)
	e1:SetCost(c316000133.cost)
	e1:SetTarget(c316000133.target)
	e1:SetOperation(c316000133.activate)
	c:RegisterEffect(e1)
end
function c316000133.condition(e,tp,eg,ep,ev,re,r,rp)
	return re:IsHasType(EFFECT_TYPE_ACTIVATE) and rp~=tp and Duel.IsChainNegatable(ev)
end
function c316000133.cfilter(c)
	return c:IsSetCard(0x13d) or c:GetCode()==150000108 and c:IsType(TYPE_MONSTER) and c:IsDiscardable()
end
function c316000133.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c316000133.cfilter,tp,LOCATION_HAND,0,1,nil) end
	Duel.DiscardHand(tp,c316000133.cfilter,1,1,REASON_COST+REASON_DISCARD,nil)
end
function c316000133.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsPlayerCanDraw(1-tp,1) end
	Duel.SetOperationInfo(0,CATEGORY_NEGATE,eg,1,0,0)
	if re:GetHandler():IsDestructable() and re:GetHandler():IsRelateToEffect(re) then
		Duel.SetOperationInfo(0,CATEGORY_DESTROY,eg,1,0,0)
	end
end
function c316000133.activate(e,tp,eg,ep,ev,re,r,rp)
	Duel.NegateActivation(ev)
	if re:GetHandler():IsRelateToEffect(re) then
		Duel.Destroy(eg,REASON_EFFECT)
	end
end
