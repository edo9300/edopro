--王魂調和 (K)
function c418.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_ATTACK_ANNOUNCE)
	  e1:SetCondition(c418.condition)
	e1:SetTarget(c418.target)
	e1:SetOperation(c418.activate)
	c:RegisterEffect(e1)
end

function c418.condition(e,tp,eg,ep,ev,re,r,rp)
	  return ep~=tp and Duel.GetAttackTarget()==nil
end
function c418.filter(c,e,tp)
	return c:IsLevelBelow(8) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_SYNCHRO,tp,false,false) and c:IsType(TYPE_SYNCHRO)
end
function c418.filter2(c)
	return c:IsFaceup() and c:IsSetCard(0x910) and c:IsAbleToRemove() 
end
function c418.filter3(c,tp)
	return c:IsFaceup() and c:IsSetCard(0x910) and c:IsAbleToRemove() and c:IsType(TYPE_TUNER)
	  and Duel.IsExistingMatchingCard(c418.filter2,tp,LOCATION_GRAVE,0,3,c)
end
function c418.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCountFromEx(tp)>0 
			and Duel.IsExistingMatchingCard(c418.filter3,tp,LOCATION_GRAVE,0,1,nil,tp)
		and Duel.IsExistingMatchingCard(c418.filter,tp,LOCATION_EXTRA,0,1,nil,e,tp) end
	Duel.SetOperationInfo(0,CATEGORY_REMOVE,nil,4,0,LOCATION_GRAVE)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,0,LOCATION_EXTRA)
end
function c418.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if not Duel.NegateAttack() then return end
	Duel.BreakEffect()
	if not c:IsRelateToEffect(e) then return end
	if Duel.GetLocationCountFromEx(tp)<=0
		or not Duel.IsExistingMatchingCard(c418.filter3,tp,LOCATION_GRAVE,0,1,nil,tp)
			or not Duel.IsExistingMatchingCard(c418.filter,tp,LOCATION_EXTRA,0,1,nil,e,tp) then return end
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
	local g1=Duel.SelectTarget(tp,c418.filter3,tp,LOCATION_GRAVE,0,1,1,nil,tp)
	  local tc=g1:GetFirst()
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_REMOVE)
	local g2=Duel.SelectTarget(tp,c418.filter2,tp,LOCATION_GRAVE,0,3,3,tc)
	  g1:Merge(g2)
	  if Duel.Remove(g1,POS_FACEUP,REASON_EFFECT)~=4 then return end
	  Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g3=Duel.SelectTarget(tp,c418.filter,tp,LOCATION_EXTRA,0,1,1,nil,e,tp)
	  Duel.SpecialSummon(g3,SUMMON_TYPE_SYNCHRO,tp,tp,false,false,POS_FACEUP) 
	  g3:GetFirst():CompleteProcedure()
end
