--DDD Tell the Sniper Overlord
function c51370195.initial_effect(c)
	--xyz summon
	aux.AddFusionProcFunRep(c,aux.FilterBoolFunction(Card.IsFusionSetCard,0x10af),2,true)
	c:EnableReviveLimit()

	local e3=Effect.CreateEffect(c)
	e3:SetCategory(CATEGORY_EQUIP+CATEGORY_TOHAND)
	e3:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e3:SetCode(EVENT_BATTLE_CONFIRM)
      --e3:SetCountLimit(1)
	e3:SetCondition(c51370195.condition)
	e3:SetTarget(c51370195.tg)
	e3:SetOperation(c51370195.op)
	c:RegisterEffect(e3)
end

function c51370195.condition(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	return Duel.GetAttackTarget()==c
end
function c51370195.eqfilter(c,tp,tc)
	return ((c:IsControler(1-tp) and c:IsAbleToChangeControler()) or (c:IsControler(tp))) and c:IsFaceup() and c~=tc
end
function c51370195.tg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	local c=e:GetHandler()
      local atker=e:GetHandler():GetBattleTarget()
      if not atker then return end
	if chkc then return chkc:IsLocation(LOCATION_ONFIELD) and chkc:IsControler(tp) and chkc:IsAbleToHand() end
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_SZONE)>0 
      and Duel.IsExistingTarget(Card.IsAbleToHand,tp,LOCATION_ONFIELD,0,1,c) and Duel.IsExistingMatchingCard(c51370195.eqfilter,tp,LOCATION_MZONE,LOCATION_MZONE,1,atker,tp,c) end
      Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_RTOHAND)
	local g2=Duel.SelectTarget(tp,Card.IsAbleToHand,tp,LOCATION_ONFIELD,0,1,1,c)
	Duel.SetOperationInfo(0,CATEGORY_TOHAND,g2,1,0,0)
	Duel.SetOperationInfo(0,CATEGORY_EQUIP,nil,1,nil,LOCATION_MZONE)
end
function c51370195.op(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if tc:IsRelateToEffect(e) and Duel.SendtoHand(tc,nil,REASON_EFFECT)~=0 then
	      Duel.ConfirmCards(1-tp,tc)
		local g=Duel.GetMatchingGroup(c51370195.eqfilter,tp,LOCATION_MZONE,LOCATION_MZONE,c:GetBattleTarget(),tp,c)
		if c:IsFaceup() and c:IsRelateToEffect(e) and g:GetCount()>0 then
			Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_EQUIP)
			local ec=g:Select(tp,1,1,nil):GetFirst()
			local atk=ec:GetTextAttack()
			if atk<0 then atk=0 end
			if not Duel.Equip(tp,ec,c,false) then return end
			--Add Equip limit
			local e1=Effect.CreateEffect(c)
			e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetProperty(EFFECT_FLAG_COPY_INHERIT+EFFECT_FLAG_OWNER_RELATE)
			e1:SetCode(EFFECT_EQUIP_LIMIT)
			e1:SetReset(RESET_EVENT+0x1fe0000)
			e1:SetValue(c51370195.eqlimit)
			ec:RegisterEffect(e1)
			if atk>0 then
				local e2=Effect.CreateEffect(c)
				e2:SetType(EFFECT_TYPE_EQUIP)
				e2:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_OWNER_RELATE)
				e2:SetCode(EFFECT_UPDATE_ATTACK)
				e2:SetReset(RESET_EVENT+0x1fe0000)
				e2:SetValue(atk)
				ec:RegisterEffect(e2)
			end
		end
	end
end
function c51370195.eqlimit(e,c)
	return e:GetOwner()==c
end
