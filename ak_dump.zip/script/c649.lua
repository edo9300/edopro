--融合塹壕-融合戰壕 (K)
function c649.initial_effect(c)
	--activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	c:RegisterEffect(e1)

	--cannot attack
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetCode(EFFECT_CANNOT_ATTACK_ANNOUNCE)
	e2:SetRange(LOCATION_SZONE)
	e2:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
	e2:SetTarget(c649.atktarget)
	c:RegisterEffect(e2)

	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_FIELD)
	e3:SetCode(EFFECT_DIRECT_ATTACK)
	e3:SetRange(LOCATION_SZONE)
	e3:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
	e3:SetTarget(c649.atktarget2)
	c:RegisterEffect(e3) 
	Duel.AddCustomActivityCounter(649,ACTIVITY_SPSUMMON,c649.counterfilter)

	local e4=Effect.CreateEffect(c)
	e4:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	e4:SetCode(EVENT_BATTLED)
	e4:SetOperation(c649.thop)
	Duel.RegisterEffect(e4,0)
end

function c649.atktarget(e,c)
	return not c:IsType(TYPE_FUSION)
end

function c649.counterfilter(c)
	return not c:IsType(TYPE_FUSION)
end

function c649.atktarget2(e,c)
	local tp=c:GetControler()
	return c:IsType(TYPE_FUSION) and Duel.GetCustomActivityCount(649,tp,ACTIVITY_SPSUMMON)==0 and Duel.GetActivityCount(tp,ACTIVITY_SUMMON)==0
	and Duel.GetFlagEffect(tp,649)==0
end

function c649.thop(e,tp,eg,ep,ev,re,r,rp)
	local ttp=Duel.GetTurnPlayer()
	local atker=Duel.GetAttacker()
	if atker:IsDirectAttacked() and atker:IsType(TYPE_FUSION) then
	Duel.RegisterFlagEffect(ttp,649,RESET_PHASE+PHASE_END,nil,1) end
end