--絶對覇王 歸來的杰克 (K)
function c415.initial_effect(c)

	local e2=Effect.CreateEffect(c)
      e2:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DAMAGE_CAL)
	e2:SetCategory(CATEGORY_DRAW)
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetCode(EVENT_FREE_CHAIN)
	e2:SetRange(LOCATION_GRAVE)
	e2:SetCondition(c415.condition)
	e2:SetCost(c415.spcost)
	e2:SetTarget(c415.sptg)
	e2:SetOperation(c415.spop)
	c:RegisterEffect(e2)

	--sort
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e3:SetCode(EVENT_TO_GRAVE)
	e3:SetProperty(EFFECT_FLAG_DAMAGE_STEP+EFFECT_FLAG_DELAY)
	e3:SetCondition(c415.sdcon)
	e3:SetTarget(c415.sdtg)
	e3:SetOperation(c415.sdop)
	c:RegisterEffect(e3)
end

function c415.condition(e,tp,eg,ep,ev,re,r,rp)
	return Duel.GetTurnPlayer()==1-tp
end
function c415.spcost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return e:GetHandler():IsAbleToRemoveAsCost() end
	Duel.Remove(e:GetHandler(),POS_FACEUP,REASON_COST)
end
function c415.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsPlayerCanDraw(tp,1) and Duel.GetLocationCount(tp,LOCATION_SZONE)>0 end
	Duel.SetOperationInfo(0,CATEGORY_DRAW,nil,0,tp,1)
end
function c415.spop(e,tp,eg,ep,ev,re,r,rp)
	if Duel.Draw(tp,1,REASON_EFFECT)==0 then return end
	local tc=Duel.GetOperatedGroup():GetFirst()
	Duel.ConfirmCards(1-ep,tc2)
	Duel.ShuffleHand(ep)
	Duel.BreakEffect()
	if tc:IsType(TYPE_TRAP) then
		if Duel.GetLocationCount(tp,LOCATION_SZONE)<=0 or tc:CheckActivateEffect(false,true,false)==nil then return end
            local te,eg,ep,ev,re,r,rp=tc:CheckActivateEffect(false,true,true)
            local tpe=tc:GetType()
	      local te=tc:GetActivateEffect()
		local tep=tc:GetControler()
		local condition=te:GetCondition()
		local cost=te:GetCost()
            Duel.ClearTargetCard()
		local target=te:GetTarget()
		local operation=te:GetOperation()
            e:SetCategory(te:GetCategory())
		e:SetProperty(te:GetProperty())

		if bit.band(tpe,TYPE_CONTINUOUS)==0  then
		Duel.MoveToField(tc,tp,tp,LOCATION_SZONE,POS_FACEUP,true)
		tc:CreateEffectRelation(te)
		if cost then cost(e,tep,eg,ep,ev,re,r,rp,1) end
		if target then target(e,tep,eg,ep,ev,re,r,rp,1) end
		if operation then operation(e,tep,eg,ep,ev,re,r,rp) end
		tc:ReleaseEffectRelation(te)
        	Duel.SendtoGrave(tc,REASON_EFFECT) end

            if bit.band(tpe,TYPE_CONTINUOUS)~=0 then
            Duel.MoveToField(tc,tp,tp,LOCATION_SZONE,POS_FACEUP,true) 
		tc:CreateEffectRelation(te)
		if cost then cost(e,tep,eg,ep,ev,re,r,rp,1) end
		if target then target(e,tep,eg,ep,ev,re,r,rp,1) end
		if operation then operation(e,tep,eg,ep,ev,re,r,rp) end
		tc:ReleaseEffectRelation(te) end
	end
end

function c415.sdcon(e,tp,eg,ep,ev,re,r,rp)
	return not e:GetHandler():IsReason(REASON_RETURN)
end
function c415.sdtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetFieldGroupCount(tp,0,LOCATION_DECK)>2 end
end
function c415.sdop(e,tp,eg,ep,ev,re,r,rp)
	Duel.SortDecktop(tp,tp,3)
end
