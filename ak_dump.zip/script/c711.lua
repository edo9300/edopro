--�ĦX
function c711.initial_effect(c)
    --Activate
    local e1=Effect.CreateEffect(c)
    e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_FUSION_SUMMON)
    e1:SetType(EFFECT_TYPE_ACTIVATE)
    e1:SetCode(EVENT_FREE_CHAIN)
    e1:SetTarget(c711.target)
    e1:SetOperation(c711.activate)
    c:RegisterEffect(e1)
end
function c711.filter1(c,e)
    return c:IsType(TYPE_PENDULUM)
end
function c711.filter11(c,e)
    return c:IsType(TYPE_PENDULUM) and not c:IsImmuneToEffect(e)
end
function c711.filter2(c,e,tp,m,f,chkf)
    return c:IsType(TYPE_FUSION) and (not f or f(c))
        and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_FUSION,tp,false,false) and c:CheckFusionMaterial(m,nil,chkf)
end
function c711.target(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then
        local chkf=Duel.GetLocationCount(tp,LOCATION_MZONE)>0 and PLAYER_NONE or tp
        local mg=Duel.GetMatchingGroup(c711.filter1,tp,LOCATION_GRAVE,0,nil,e)
		local mg1=mg:Filter(c711.filter1,nil,e)
        local res=Duel.IsExistingMatchingCard(c711.filter2,tp,LOCATION_EXTRA,0,1,nil,e,tp,mg1,nil,chkf)
        return res
    end
    Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
end
function c711.activate(e,tp,eg,ep,ev,re,r,rp)
    local chkf=Duel.GetLocationCount(tp,LOCATION_MZONE)>0 and PLAYER_NONE or tp
    local sg1=Duel.GetMatchingGroup(c711.filter2,tp,LOCATION_EXTRA,0,nil,e,tp,mg1,nil,chkf)
    if sg1:GetCount()>0 then
        local sg=sg1:Clone()
        Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
        local tg=sg:Select(tp,1,1,nil)
        local tc=tg:GetFirst()
        Duel.SpecialSummon(tc,SUMMON_TYPE_FUSION,tp,tp,false,false,POS_FACEUP)
        tc:CompleteProcedure()
    end
end