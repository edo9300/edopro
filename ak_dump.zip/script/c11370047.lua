--Triangle Evolution
function c11370047.initial_effect(c)
--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetCode(EVENT_FREE_CHAIN)	
	e1:SetTarget(c11370047.target)
	e1:SetOperation(c11370047.activate)
	c:RegisterEffect(e1)
end

function c11370047.filter(c,e,tp)
	return c:IsFaceup() and c:IsLevelAbove(5) 
	  --and Duel.IsExistingMatchingCard(c11370047.filter1,tp,LOCATION_EXTRA,0,1,nil,c:GetLevel(),e,tp,c) 
end
function c11370047.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(tp) and c11370047.filter(chkc,e,tp) end
	if chk==0 then return Duel.IsExistingTarget(c11370047.filter,tp,LOCATION_MZONE,0,1,nil,e,tp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	Duel.SelectTarget(tp,c11370047.filter,tp,LOCATION_MZONE,0,1,1,nil,e,tp)
end
function c11370047.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()
	if tc and tc:IsRelateToEffect(e) and tc:IsFaceup() and not tc:IsImmuneToEffect(e) then
	--xyz
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(511001225) 
	e2:SetValue(2)
	e2:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	tc:RegisterEffect(e2,false,4)
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e3:SetCode(EVENT_BE_MATERIAL)
	e3:SetCondition(c11370047.efcon)
	e3:SetOperation(c11370047.efop)
	e3:SetReset(RESET_PHASE+PHASE_END)
	tc:RegisterEffect(e3)
	end
end
function c11370047.efcon(e,tp,eg,ep,ev,re,r,rp)
	return r==REASON_XYZ
end
function c11370047.efop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local rc=c:GetReasonCard()
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(3606728,1))
	  e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e1:SetCategory(CATEGORY_ATKCHANGE)
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetOperation(c11370047.atkop)
	e1:SetReset(RESET_EVENT+0x1fe0000)
	rc:RegisterEffect(e1,true)
	  e:Reset()
end
function c11370047.atkop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if c:IsFaceup() then
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		e1:SetValue(-1000)
		c:RegisterEffect(e1)
	end
end

function c11370047.filter1(c,lv,e,tp,tc)
	  local tc=e:GetHandler()
	  if not c:IsType(TYPE_XYZ) then return end
	return (tc:IsCanBeXyzMaterial(c) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,false,false) and c.xyz_filter(tc) and c.minxyzct==3)
	  or (tc:IsCanBeXyzMaterial(c) and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,false,false) and c.xyz_filter(tc) 
		  and Duel.IsExistingMatchingCard(c.xyz_filter,tp,LOCATION_MZONE,0,c.minxyzct-3,e:GetHandler()) and c.minxyzct>3)
end
function c11370047.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.IsExistingMatchingCard(c11370047.filter1,tp,LOCATION_EXTRA,0,1,nil,e:GetHandler():GetLevel(),e,tp,e:GetHandler()) end
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_EXTRA)
end
function c11370047.mfilter(c)
	return c:IsType(TYPE_MONSTER) 
end
function c11370047.spop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Duel.GetMatchingGroup(c11370047.mfilter,tp,LOCATION_MZONE,0,nil)
	local xyzg=Duel.GetMatchingGroup(c11370047.filter1,tp,LOCATION_EXTRA,0,nil,e:GetHandler():GetLevel(),e,tp,c)
	if xyzg:GetCount()>0 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
		local xyz=xyzg:Select(tp,1,1,nil):GetFirst()
			if xyz.minxyzct==3 and not xyz.maxxyzct then
			Duel.Overlay(xyz,c)
				  local cg=Group.CreateGroup()
				  cg:AddCard(c)
				  xyz:SetMaterial(cg)
			Duel.SpecialSummon(xyz,SUMMON_TYPE_XYZ,tp,tp,false,false,POS_FACEUP)
			xyz:CompleteProcedure()
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		e1:SetValue(-1000)
		xyz:RegisterEffect(e1)
				else
				  local maxcount=xyz.maxxyzct
				  if not xyz.maxxyzct then maxcount=xyz.minxyzct end
			Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
			local sg3=g:FilterSelect(tp,xyz.xyz_filter,xyz.minxyzct-3,maxcount-3,e:GetHandler())
			if sg3:GetCount()<1 then return false end
			sg3:AddCard(e:GetHandler())
				  local ssc=sg3:GetFirst()
				  while ssc do
				  local ovg=ssc:GetOverlayGroup()
				if ovg:GetCount()>0 then
				  Duel.SendtoGrave(ovg,REASON_RULE)
				end
				  ssc=sg3:GetNext() end
			Duel.Overlay(xyz,sg3)
				  xyz:SetMaterial(sg3)
			Duel.SpecialSummon(xyz,SUMMON_TYPE_XYZ,tp,tp,false,false,POS_FACEUP)
			xyz:CompleteProcedure()
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
			e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE)
		e1:SetCode(EFFECT_UPDATE_ATTACK)
		e1:SetReset(RESET_EVENT+0x1fe0000)
		e1:SetValue(-1000)
		xyz:RegisterEffect(e1)
		end
	end
end
