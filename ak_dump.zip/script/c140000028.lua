--Self Tribute
function c140000028.initial_effect(c)
	--Negate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_NEGATE+CATEGORY_DESTROY)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_CHAINING)
	e1:SetCondition(c140000028.condition)
	e1:SetCost(c140000028.cost)
	e1:SetTarget(c140000028.target)
	e1:SetOperation(c140000028.operation)
	c:RegisterEffect(e1)
end
function c140000028.cfilter(c,e,tp)
	return c:IsOnField() and c:IsType(TYPE_MONSTER) and c:IsControler(e:GetLabel())
end
function c140000028.condition(e,tp,eg,ep,ev,re,r,rp)
	if not re:IsActiveType(TYPE_MONSTER) and not re:IsHasType(EFFECT_TYPE_ACTIVATE) then return false end
        e:SetLabel(tp)
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_DESTROY)
	return ex and tg~=nil and tc+tg:FilterCount(c140000028.cfilter,nil,e,tp)-tg:GetCount()>0
end
function c140000028.cost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.CheckLPCost(tp,1000) end
	Duel.PayLPCost(tp,1000)
end
function c140000028.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
        e:SetLabel(tp)
	local ex,tg,tc=Duel.GetOperationInfo(ev,CATEGORY_DESTROY)
	if ex and tg~=nil and tc+tg:FilterCount(c140000028.cfilter,nil,e,tp)-tg:GetCount()>0 then
            Duel.SetTargetCard(tg:Filter(c140000028.cfilter,nil,e,tp))
        end
end
function c140000028.operation(e,tp,eg,ep,ev,re,r,rp)
        local g=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS)
	local sg=g:Filter(Card.IsRelateToEffect,nil,e)
        local tc=sg:GetFirst()
        while tc do
            local e1=Effect.CreateEffect(e:GetHandler())
            e1:SetType(EFFECT_TYPE_SINGLE)
            e1:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
            e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
            e1:SetValue(1)
            tc:RegisterEffect(e1)
            local e2=e1:Clone()
            e2:SetCode(EFFECT_INDESTRUCTABLE_EFFECT)
            tc:RegisterEffect(e2)
            tc=sg:GetNext()
        end
end
