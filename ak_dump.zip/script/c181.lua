--HRUM
function c181.initial_effect(c) 
	--Special Summon
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	e1:SetTarget(c181.target)
	e1:SetOperation(c181.operation)
	c:RegisterEffect(e1)	
end
--Filter for first targets
function c181.fFilter(c,e,tp)
	local count = Duel.GetMatchingGroup(c181.sFilter,tp,LOCATION_GRAVE,LOCATION_GRAVE,c,e,tp,c:GetLevel()):GetCount()
	return count > 1 and Duel.IsExistingMatchingCard(c181.xyzFilter,tp,LOCATION_EXTRA,0,1,c,e,tp,c:GetLevel(),count+1)
end
--Filter for second or more targets
function c181.sFilter(c)
	return c:IsCode(46986414) or c:IsCode(89943723) or c:IsCode(44508094) 
	or (c:IsCode(84013237) and aux.MustMaterialCheck(c,tp,EFFECT_MUST_BE_XMATERIAL))
end
function c181.sFilter2(c,code1,code2,code3)
	return (c:IsCode(46986414) or c:IsCode(89943723) or c:IsCode(44508094) or c:IsCode(84013237)) 
	  and not c:IsCode(code1) and not c:IsCode(code2) and not c:IsCode(code3)
end
--Filter for XYZ monsters of a certain rank, that require a certain number of XYZ materials or lower
function c181.xyzFilter(c)
	return c:IsCode(211)
end
function c181.aFilter(c)
	return c:GetFlagEffect(181)~=0
end
--Special Summon target
function c181.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetFlagEffect(tp,181)==0 
	  and not Duel.IsPlayerAffectedByEffect(tp,59822133)
	  and Duel.GetLocationCountFromEx(tp)>0 
	  and Duel.IsExistingMatchingCard(c181.sFilter,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,nil) 
	  and Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_MZONE,0,1,nil,159) 
	end  
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,tp,4,LOCATION_DECK+LOCATION_EXTRA) 
	Duel.RegisterFlagEffect(tp,181,0,0,0)
end
--Special Summon operation
function c181.operation(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if Duel.IsPlayerAffectedByEffect(tp,59822133) then return end  
	local ft=Duel.GetLocationCountFromEx(tp)
	if ft<1 then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	if Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,nil,46986414) then
	local g1=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,1,nil,46986414) 
	  local g10=Group.FromCards(Duel.CreateToken(tp,900000020))
	  Duel.Remove(g10,POS_FACEUP,REASON_RULE)   
	  Duel.SpecialSummon(g10,0,tp,tp,true,true,POS_FACEUP) 
	  g10:GetFirst():RegisterFlagEffect(181,RESET_EVENT+0x1fe0000,0,1)
	  g10:RegisterFlagEffect(157,0,0,1) end

	  if Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,nil,89943723) and Duel.GetLocationCountFromEx(tp)>0 then
	local g2=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,1,nil,89943723) 
	  local g20=Group.FromCards(Duel.CreateToken(tp,47))
	  Duel.Remove(g20,POS_FACEUP,REASON_RULE)   
	  Duel.SpecialSummon(g20,0,tp,tp,true,true,POS_FACEUP) 
	  g20:GetFirst():RegisterFlagEffect(181,RESET_EVENT+0x1fe0000,0,1)
	  g20:RegisterFlagEffect(157,0,0,1) end

	  if Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,nil,44508094) and Duel.GetLocationCountFromEx(tp)>0 then
	local g3=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,1,nil,44508094) 
	  local g30=Group.FromCards(Duel.CreateToken(tp,101))
	  Duel.Remove(g30,POS_FACEUP,REASON_RULE)   
	  Duel.SpecialSummon(g30,0,tp,tp,true,true,POS_FACEUP) 
	  g30:GetFirst():RegisterFlagEffect(181,RESET_EVENT+0x1fe0000,0,1)
	  g30:RegisterFlagEffect(157,0,0,1) end

	  if Duel.IsExistingMatchingCard(Card.IsCode,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,nil,84013237) and Duel.GetLocationCountFromEx(tp)>0 then
	local g4=Duel.SelectMatchingCard(tp,Card.IsCode,tp,LOCATION_GRAVE,LOCATION_GRAVE,1,1,nil,84013237) 
	if not aux.MustMaterialCheck(g4,tp,EFFECT_MUST_BE_XMATERIAL) then return end
	  local g40=Group.FromCards(Duel.CreateToken(tp,13719))
	  Duel.Remove(g40,POS_FACEUP,REASON_RULE)   
	Duel.Overlay(g40:GetFirst(),g4) 
	Duel.SpecialSummon(g40:GetFirst(),SUMMON_TYPE_XYZ,tp,tp,true,true,POS_FACEUP) 
	  g40:GetFirst():RegisterFlagEffect(181,RESET_EVENT+0x1fe0000,0,1) 
	  g40:RegisterFlagEffect(157,0,0,1) end

	  local sc=Duel.GetMatchingGroup(Card.IsCode,tp,LOCATION_MZONE,0,nil,159):GetFirst()
	  --Destroy replace
	local e5=Effect.CreateEffect(c)
	e5:SetType(EFFECT_TYPE_CONTINUOUS+EFFECT_TYPE_SINGLE)
	e5:SetCode(EFFECT_DESTROY_REPLACE)
	e5:SetProperty(EFFECT_FLAG_SINGLE_RANGE+EFFECT_FLAG_CARD_TARGET+EFFECT_FLAG_CANNOT_DISABLE)
	e5:SetRange(LOCATION_MZONE)
	e5:SetTarget(c181.desreptg)
	e5:SetOperation(c181.desrepop)
	sc:RegisterEffect(e5)
end

function c181.repfilter(c)
	return not c:IsStatus(STATUS_DESTROY_CONFIRMED+STATUS_BATTLE_DESTROYED)
			 and c:GetFlagEffect(181)~=0
end
function c181.desreptg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return not c:IsReason(REASON_REPLACE) and c:IsOnField() and c:IsFaceup()
		and Duel.IsExistingMatchingCard(c181.repfilter,tp,LOCATION_MZONE,0,1,c) end
	if Duel.SelectYesNo(tp,aux.Stringid(13715,1)) then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_DESREPLACE)
		local g=Duel.SelectMatchingCard(tp,c181.repfilter,tp,LOCATION_MZONE,0,1,1,c)
		e:SetLabelObject(g:GetFirst())
		Duel.HintSelection(g)
		g:GetFirst():SetStatus(STATUS_DESTROY_CONFIRMED,true)
		return true
	else return false end
end
function c181.desrepop(e,tp,eg,ep,ev,re,r,rp)
	local tc=e:GetLabelObject()
	tc:SetStatus(STATUS_DESTROY_CONFIRMED,false)
	Duel.Destroy(tc,REASON_EFFECT+REASON_REPLACE)
end
