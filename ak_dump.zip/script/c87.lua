--寫真融合
function c87.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e1:SetCategory(CATEGORY_SPECIAL_SUMMON+CATEGORY_LVCHANGE)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(c87.target)
	e1:SetOperation(c87.activate)
	c:RegisterEffect(e1)
end

function c87.cfilter(c,e,tp)
	  local lev=c:GetLevel()
	  local lv=0
	  if lev<1 then return false end
	  if lev>0 and lev<5 then lv=4 end
	  if lev>4 and lev<7 then lv=6 end
	  if lev>6 then lv=8 end
	return c:IsFaceup() and not c:IsImmuneToEffect(e)   
	  and aux.MustMaterialCheck(c,tp,EFFECT_MUST_BE_XMATERIAL)
	  and Duel.IsExistingMatchingCard(c87.cfilter2,tp,LOCATION_MZONE,0,1,nil,e,tp,lv,c)
	  and Duel.IsPlayerCanSpecialSummonMonster(tp,87,0,0x0,c:GetAttack(),c:GetDefense(),lv,c:GetRace(),c:GetAttribute())
end
function c87.cfilter2(c,e,tp,lv,tc1)
	return c:IsFaceup() and c:IsCode(51370066) and not c:IsImmuneToEffect(e) 
	  and aux.MustMaterialCheck(c,tp,EFFECT_MUST_BE_XMATERIAL)
	  and Duel.IsExistingMatchingCard(c87.sfilter,tp,LOCATION_EXTRA,0,1,nil,e,tp,lv,tc1,c)
end
function c87.sfilter(c,e,tp,lv,tc1,tc2)
	if not c:IsType(TYPE_XYZ) then return false end
	if c:IsType(TYPE_PENDULUM) and c:IsFaceup() then return false end
	return lv==c:GetRank() 
	  and (c.xyz_filter==nil or (c.xyz_filter and c.xyz_filter(tc1,true,c,tp)))
	  and tc2:IsCanBeXyzMaterial(c) and c.minxyzct and c.minxyzct==2
	  and c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_XYZ,tp,false,false)
end
function c87.target(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then return chkc:IsLocation(LOCATION_MZONE) and chkc:IsControler(1-tp) and c87.cfilter(chkc,e,tp) end
	if chk==0 then return Duel.IsPlayerCanSpecialSummonCount(tp,2) 
	and Duel.GetLocationCount(tp,LOCATION_MZONE)>0 and Duel.GetLocationCountFromEx(tp)>0  and Duel.IsExistingTarget(c87.cfilter,tp,0,LOCATION_MZONE,1,nil,e,tp) end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
	local g=Duel.SelectTarget(tp,c87.cfilter,tp,0,LOCATION_MZONE,1,1,nil,e,tp)
	Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,e:GetHandler(),1,0,0)
end
function c87.activate(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<1 then return end
	  local tc=Duel.GetFirstTarget()
	  if tc:IsFacedown() or not tc:IsRelateToEffect(e) or tc:IsImmuneToEffect(e) then return end
	  local lev=tc:GetLevel()
	  local lv=0
	  if lev<1 then return end
	  if lev>0 and lev<5 then lv=4 end
	  if lev>4 and lev<7 then lv=6 end
	  if lev>6 then lv=8 end
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_CHANGE_LEVEL)
	e1:SetValue(lv)
	e1:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	tc:RegisterEffect(e1)
	if not Duel.IsPlayerCanSpecialSummonMonster(tp,87,0,0x0,tc:GetAttack(),tc:GetDefense(),lv,tc:GetRace(),tc:GetAttribute()) then return end
	c:AddMonsterAttribute(TYPE_EFFECT+tc:GetType(),tc:GetAttribute(),tc:GetRace(),lv,tc:GetAttack(),tc:GetDefense())
	Duel.SpecialSummonStep(c,0,tp,tp,true,false,POS_FACEUP)
	c:AddMonsterAttributeComplete()
	Duel.SpecialSummonComplete()
	local tlv=c:GetLevel()
	Duel.BreakEffect()

	if not Duel.IsExistingMatchingCard(c87.cfilter2,tp,LOCATION_MZONE,0,1,nil,e,tp,tlv,c) then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_XMATERIAL)
	local g=Duel.SelectMatchingCard(tp,c87.cfilter2,tp,LOCATION_MZONE,0,1,1,nil,e,tp,tlv,c) 
	local tc2=g:GetFirst()
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_CHANGE_RACE)
	e2:SetValue(tc:GetRace())
	e2:SetReset(RESET_EVENT+0x1fe0000)
	tc2:RegisterEffect(e2)
	local e5=e2:Clone()
	e5:SetCode(EFFECT_CHANGE_ATTRIBUTE)
	e5:SetValue(tc:GetAttribute())
	tc2:RegisterEffect(e5)
	local e6=e2:Clone()
	e6:SetCode(EFFECT_SET_ATTACK)  
	e6:SetValue(tc:GetAttack())
	tc2:RegisterEffect(e6)
	local e7=e2:Clone()
	e7:SetCode(EFFECT_SET_DEFENSE)  
	e7:SetValue(tc:GetDefense())
	tc2:RegisterEffect(e7)
	local e3=Effect.CreateEffect(c)
	e3:SetType(EFFECT_TYPE_SINGLE)
	e3:SetCode(EFFECT_DISABLE)
	e3:SetReset(RESET_EVENT+0x1fe0000)
	tc2:RegisterEffect(e3)
	local e4=Effect.CreateEffect(c)
	e4:SetType(EFFECT_TYPE_SINGLE)
	e4:SetCode(EFFECT_DISABLE_EFFECT)
	e4:SetReset(RESET_EVENT+0x1fe0000)
	tc2:RegisterEffect(e4)
	g:AddCard(c)
	if not Duel.IsExistingMatchingCard(c87.sfilter,tp,LOCATION_EXTRA,0,1,nil,e,tp,tlv,c,tc2) then return end
	if not aux.MustMaterialCheck(g,tp,EFFECT_MUST_BE_XMATERIAL) or Duel.GetLocationCountFromEx(tp)<1 then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local sg=Duel.SelectMatchingCard(tp,c87.sfilter,tp,LOCATION_EXTRA,0,1,1,nil,e,tp,tlv,c,tc2)
	local sc=sg:GetFirst()
	sc:SetMaterial(g)
	Duel.Overlay(sc,g)
	Duel.SpecialSummon(sc,SUMMON_TYPE_XYZ,tp,tp,false,false,POS_FACEUP)
	sc:CompleteProcedure()
	local de=Effect.CreateEffect(c)
	de:SetProperty(EFFECT_FLAG_IGNORE_IMMUNE)
	de:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
	de:SetRange(LOCATION_MZONE)
	de:SetCode(EVENT_PHASE+PHASE_END)
	de:SetCountLimit(1)
	de:SetOperation(c87.desop)
	de:SetReset(RESET_EVENT+0x1fe0000+RESET_PHASE+PHASE_END)
	sc:RegisterEffect(de,true)
end
function c87.desop(e,tp,eg,ep,ev,re,r,rp)
	Duel.Destroy(e:GetHandler(),REASON_EFFECT)
end